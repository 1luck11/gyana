﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_Sampleresultterm1 : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt = new DataTable();
    public string deflses, classsec;
    protected void Page_Load(object sender, EventArgs e)
    {
        Fetch_to_print();
    }

    private void Fetch_to_print()
    {
        //if (Session["admsnno"] != null)
        //{
        //deflses = Session["sessionss"].ToString();
        //classsec = Session["classsec"].ToString();

        dt = bd.fill_datatable(@"Select * from CLASS_PNC_KG where admissionno='" + Session["admsnno"].ToString() + "' and sessionss='" + Request.QueryString["sessions"].ToString() + "'");
        if (dt.Rows.Count > 0)
        {
            Rptr_rptcards.DataSource = dt;
            Rptr_rptcards.DataBind();
        }
        else
        {
            Response.Write("<script>alert('No Record Available !!!')</script>");
        }
        //}

        //else
        //{
        //    Response.Redirect("~/Adminhome/report_card_print_XI.aspx");
        //}
    }
}