﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_TeacherField_III_V : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblsession.Text = Request.QueryString["session"].ToString();

        if (!IsPostBack)
        {
            //divtotalmarks.Visible = false;
            // divgrade.Visible = false;
            // divattendence.Visible = false;
            //TextBox2.Text = classs + "(" + section + ")";
            englishrow.Visible = true;
            hindirow.Visible = true;
            mathsrow.Visible = true;
            csrow.Visible = true;
            csrow.Visible = true;
              scirow.Visible = true;
            sstrow.Visible = true;
            others.Visible = true;
            gkrow.Visible = true;
            sanskrow.Visible = true;
            //scholarrow.Visible = false;
            // attendance.Visible = false;
            some.Visible = true;
            string subjects = Request.QueryString["subjects"].ToString();

            
            txtclass.Text = Session["classs"].ToString();
            txtsection.Text = Session["Sec"].ToString();

            string[] str = subjects.Split(',');
            foreach (string m in str)
            {
                if (m == "English")
                {
                    englishrow.Visible = true;

                }
                if (m == "General Knowledge")
                {
                   
                    gkrow.Visible = true;

                }
                if (m == "Computer")
                {
                    
                    csrow.Visible = true;

                }
            
                if (m == "Hindi")
                {
                    hindirow.Visible = true;


                }
                if (m == "Mathematics")
                {
                  
                    mathsrow.Visible = true;

                }
                if (m == "Social Studies")
                {

                    sstrow.Visible = true;


                }
                if (m == "Science")
                {

                    scirow.Visible = true;


                }
                if (m == "Sanskrit")
                {

                    sanskrow.Visible = true;


                }
            }

        }
    }
   
    protected void btn_save_click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand(@"Insert into CLASS_III_V(name, class, sec, rollno, admissionno, fname, mname, bloodgrp,dob, address, engPtest, engPtest2, engNbook, engNbook2, engErmnt, engErmnt2, engtheory, engtheory2, hindiPtest, hindiPtest2, hindiNbook, hindiNbook2, hindiErmnt, hindiErmnt2, hinditheory, hinditheory2, mathsPtest, mathsPtest2, mathsNbook, mathsNbook2, mathsErmnt, mathsErmnt2, mathstheory, mathstheory2, sciPtest, sciPtest2, sciNbook, sciNbook2, sciErmnt, sciErmnt2, scitheory, scitheory2, sstPtest, sstPtest2, sstNbook, sstNbook2, sstErmnt, sstErmnt2, ssttheory, ssttheory2, csPtest, csPtest2, csNbook, csNbook2, csErmnt, csErmnt2, cstheory, cstheory2, sanskPtest, sanskPtest2, sanskNbook, sanskNbook2, sanskErmnt, sanskErmnt2, sansktheory, sansktheory2, GKPtest, GKPtest2, GKNbook, GKNbook2, GKErmnt, GKErmnt2, GKtheory, GKtheory2, tothalf, totYearly, totper_half, totper_Yrly, Max_marks, wghthalfy, heighthalfy, wghthalfy2, heighthalfy2, teachr_remrks, promote_class, work_xperience, phe_health, artedu, work_xperience2, phe_health2, artedu2, discipline, discipline2, engtot, engtot2, hinditot, hinditot2, mathstot, mathstot2, scitot, scitot2, ssttot, ssttot2, cstot, cstot2, sansktot, sansktot2, GKtot, GKtot2, drawing, drawing2, games, games2, karate, karate2, dance, dance2,sessionss,enggrndtot,hindigrndtot,sanskgrndtot,mathsgrndtot,scigrndtot,csgrndtot,sstgrndtot,GKgrndtot,Grand_total,Grand_Percnt,attndnce1,attndnce2,conduct,student_pic) 
                  values(@name, @class, @sec, @rollno, @admissionno, @fname, @mname, @bloodgrp,@dob, @address, @engPtest, @engPtest2, @engNbook, @engNbook2, @engErmnt, @engErmnt2, @engtheory, @engtheory2, @hindiPtest, @hindiPtest2, @hindiNbook, @hindiNbook2, @hindiErmnt, @hindiErmnt2, @hinditheory, @hinditheory2, @mathsPtest, @mathsPtest2, @mathsNbook, @mathsNbook2, @mathsErmnt, @mathsErmnt2, @mathstheory, @mathstheory2, @sciPtest, @sciPtest2, @sciNbook, @sciNbook2, @sciErmnt, @sciErmnt2, @scitheory, @scitheory2, @sstPtest, @sstPtest2, @sstNbook, @sstNbook2, @sstErmnt, @sstErmnt2, @ssttheory, @ssttheory2, @csPtest, @csPtest2, @csNbook, @csNbook2, @csErmnt, @csErmnt2, @cstheory, @cstheory2, @sanskPtest, @sanskPtest2, @sanskNbook, @sanskNbook2, @sanskErmnt, @sanskErmnt2, @sansktheory, @sansktheory2, @GKPtest, @GKPtest2, @GKNbook, @GKNbook2, @GKErmnt, @GKErmnt2, @GKtheory, @GKtheory2, @tothalf, @totYearly, @totper_half, @totper_Yrly, @Max_marks, @wghthalfy, @heighthalfy, @wghthalfy2, @heighthalfy2, @teachr_remrks, @promote_class, @work_xperience, @phe_health, @artedu, @work_xperience2, @phe_health2, @artedu2, @discipline, @discipline2, @engtot, @engtot2, @hinditot, @hinditot2, @mathstot, @mathstot2, @scitot, @scitot2, @ssttot, @ssttot2, @cstot, @cstot2, @sansktot, @sansktot2, @GKtot, @GKtot2, @drawing, @drawing2, @games, @games2, @karate, @karate2, @dance, @dance2,@sessionss,@enggrndtot,@hindigrndtot,@sanskgrndtot,@mathsgrndtot,@scigrndtot,@csgrndtot,@sstgrndtot,@GKgrndtot,@Grand_total,@Grand_Percnt,@attndnce1,@attndnce2, @conduct,@student_pic)", cs.connect());

        //cmd = new SqlCommand("Save_reportcard", cs.Connect());
        //cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@name", txtnam.Text.ToUpper());
        cmd.Parameters.AddWithValue("@class", txtclass.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sec", txtsection.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rollno", txtrollno.Text.ToUpper());
        cmd.Parameters.AddWithValue("@admissionno", txtadmsn.Text.ToUpper());
        cmd.Parameters.AddWithValue("@fname", txtfather.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mname", txtmother.Text.ToUpper());
        cmd.Parameters.AddWithValue("@bloodgrp", txtbloodgrp.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dob", txtdob.Text.ToUpper());
        cmd.Parameters.AddWithValue("@student_pic", txtstupic.Text);
        cmd.Parameters.AddWithValue("@address", txtaddrs.Text.ToUpper());

        cmd.Parameters.AddWithValue("@engPtest", engPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engPtest2", engPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engNbook", engNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engNbook2", engNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engErmnt", engErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engErmnt2", engErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtheory", engtheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtheory2", engtheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@enggrndtot", enggrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@hindiPtest", hindiPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiPtest2", hindiPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiNbook", hindiNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiNbook2", hindiNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiErmnt", hindiErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiErmnt2", hindiErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditheory", hinditheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditheory2", hinditheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindigrndtot", hindigrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@mathsPtest", mathsPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsPtest2", mathsPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsNbook", mathsNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsNbook2", mathsNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsErmnt", mathsErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsErmnt2", mathsErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstheory", mathstheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstheory2", mathstheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsgrndtot", mathgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sciPtest", sciPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciPtest2", sciPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciNbook", sciNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciNbook2", sciNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciErmnt", sciErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciErmnt2", sciErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scitheory", scitheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scitheory2", scitheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scigrndtot", scigrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sstPtest", SSTPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstPtest2", SSTPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstNbook", SSTNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstNbook2", SSTNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstErmnt", SSTErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstErmnt2", SSTErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@ssttheory", SSTtheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@ssttheory2", SSTtheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstgrndtot", SSTgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@csPtest", CSPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csPtest2", CSPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csNbook", CSNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csNbook2", CSNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csErmnt", CSErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csErmnt2", CSErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cstheory", CStheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cstheory2", CStheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csgrndtot", csgrndtot.Value.ToUpper());

        if (Sanskgrndtot.Value == "0")
        {
            Sanskgrndtot.Value = "";
        }


        cmd.Parameters.AddWithValue("@sanskPtest", SanskPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskPtest2", SanskPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskNbook", SanskNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskNbook2", SanskNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskErmnt", SanskErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskErmnt2", SanskErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sansktheory", Sansktheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sansktheory2", Sansktheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskgrndtot", Sanskgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@GKPtest", GKPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKPtest2", GKPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKNbook", GKNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKNbook2", GKNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKErmnt", GKErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKErmnt2", GKErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKtheory", GKtheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKtheory2", GKtheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKgrndtot", gkgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@Grand_total", txtGtotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@Grand_Percnt", txtG_Percnt.Value.ToUpper());

        cmd.Parameters.AddWithValue("@attndnce1", attnd1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@attndnce2", attnd2.Value.ToUpper());

        cmd.Parameters.AddWithValue("@tothalf", txttotal_Half.Value.ToUpper());
        cmd.Parameters.AddWithValue("@totYearly", txttotal_Yrly.Value.ToUpper());
        cmd.Parameters.AddWithValue("@totper_half", txtpercnt_Half.Value.ToUpper());
        cmd.Parameters.AddWithValue("@totper_Yrly", txtpercnt_Yrly.Value.ToUpper());
        cmd.Parameters.AddWithValue("@Max_marks", txtMM.Value.ToUpper());
        cmd.Parameters.AddWithValue("@wghthalfy", weight.Value.ToUpper());
        cmd.Parameters.AddWithValue("@heighthalfy", height.Value.ToUpper());
        cmd.Parameters.AddWithValue("@wghthalfy2", weight2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@heighthalfy2", height2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@teachr_remrks", txttea_rmrk.Value.ToUpper());
        cmd.Parameters.AddWithValue("@promote_class", promoteclass.Value.ToUpper());
        cmd.Parameters.AddWithValue("@work_xperience", workexp.Value.ToUpper());
        cmd.Parameters.AddWithValue("@work_xperience2", workexp2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@phe_health", phehealth.Value.ToUpper());
        cmd.Parameters.AddWithValue("@phe_health2", phehealth2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@artedu", artedu.Value.ToUpper());
        cmd.Parameters.AddWithValue("@artedu2", artedu2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@discipline", discipline.Value.ToUpper());
        cmd.Parameters.AddWithValue("@discipline2", discipline2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@drawing", drawing.Value.ToUpper());
        cmd.Parameters.AddWithValue("@drawing2", drawing2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@games", game.Value.ToUpper());
        cmd.Parameters.AddWithValue("@games2", game2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@karate", karate.Value.ToUpper());
        cmd.Parameters.AddWithValue("@karate2", karate2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@dance", dance.Value.ToUpper());
        cmd.Parameters.AddWithValue("@dance2", dance2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtot", engtotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtot2", engtotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditot", hinditotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditot2", hinditotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstot", mathstotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstot2", mathstotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scitot", scitotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scitot2", scitotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@ssttot", SSTtotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@ssttot2", SSTtotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cstot", CStotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cstot2", CStotal2.Value.ToUpper());
        if (Sansktotal.Value == "0")
        {
            Sansktotal.Value = "";
        }

        if (Sansktotal2.Value == "0")
        {
            Sansktotal2.Value = "";
        }

        cmd.Parameters.AddWithValue("@sansktot", Sansktotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sansktot2", Sansktotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKtot", GKtotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKtot2", GKtotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sessionss", lblsession.Text.ToUpper());
        cmd.Parameters.AddWithValue("@conduct", ddlconduct.SelectedItem.Text.ToUpper());
        cmd.ExecuteNonQuery();
        try
        {
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cs.exec_qry("Delete from CLASS_III_V where id not in(select max(id) from CLASS_III_V group by name, class, sec, rollno, admissionno, fname, mname, bloodgrp, sessionss)");//Remove All Duplicates Entries From (this) Table 
                Response.Write("<script>alert('You Have Sucessfully Saved Marks !!! ')</script>");
                clrfld();
            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Something Went Wrong.. " + ex + "')", true);
        }

    }

    protected void clrfld()
    {
        txtnam.Text = "";
        txtfather.Text = "";
        txtmother.Text = "";
        txtaddrs.Text = "";
        txtadmsn.Text = "";
        txtrollno.Text = "";
        //txtsection.Text = dr["sec"].ToString();
        //txtclass.Text = dr["class"].ToString();
        txtbloodgrp.Text = "";
        txtdob.Text = "";
        enggrndtot.Value = "";
        hindigrndtot.Value = "";
        mathgrndtot.Value = "";
        SSTgrndtot.Value = "";
        scigrndtot.Value = "";
        gkgrndtot.Value = "";
        csgrndtot.Value = "";
        Sanskgrndtot.Value = "";
        txtG_Percnt.Value = "";
        txtGtotal.Value = "";
        attnd1.Value = "";
        attnd2.Value = "";
        engNbook.Value = "";
        engNbook2.Value = "";
        engPtest.Value = "";
        engPtest2.Value = "";
        engtheory.Value = "";
        engtheory2.Value = "";
        engErmnt.Value = "";
        engErmnt2.Value = "";
        hindiNbook.Value = "";
        hindiNbook2.Value = "";
        hindiPtest.Value = "";
        hindiPtest2.Value = "";
        hindiErmnt.Value = "";
        hindiErmnt2.Value = "";
        hinditheory.Value = "";
        hinditheory2.Value = "";
        mathsNbook.Value = "";
        mathsNbook2.Value = "";
        mathsPtest.Value = "";
        mathsPtest2.Value = "";
        mathsErmnt.Value = "";
        mathsErmnt2.Value = "";
        mathstheory.Value = "";
        mathstheory2.Value = "";
        sciNbook.Value = "";
        sciNbook2.Value = "";
        sciPtest.Value = "";
        sciPtest2.Value = "";
        scitheory.Value = "";
        scitheory2.Value = "";
        sciErmnt.Value = "";
        sciErmnt2.Value = "";
        CSNbook.Value = "";
        CSNbook2.Value = "";
        CSPtest.Value = "";
        CSPtest2.Value = "";
        CSErmnt.Value = "";
        CSErmnt2.Value = "";
        CStheory.Value = "";
        CStheory2.Value = "";
        GKNbook.Value = "";
        GKNbook2.Value = "";
        GKPtest.Value = "";
        GKPtest2.Value = "";
        GKErmnt.Value = "";
        GKErmnt2.Value = "";
        GKtheory.Value = "";
        GKtheory2.Value = "";
        SSTErmnt.Value = "";
        SSTErmnt2.Value = "";
        SSTPtest.Value = "";
        SSTPtest2.Value = "";

        SSTNbook.Value = "";
        SSTNbook2.Value = "";
        SSTtheory.Value = "";
        SSTtheory2.Value = "";
        SSTtotal.Value = "";
        SSTtotal2.Value = "";

        SanskErmnt.Value = "";
        SanskErmnt2.Value = "";
        SanskNbook.Value = "";
        SanskNbook2.Value = "";
        SanskPtest.Value = "";
        SanskPtest2.Value = "";
        Sansktheory.Value = "";
        Sansktheory2.Value = "";
        Sansktotal.Value = "";
        Sansktotal2.Value = "";

        txttotal_Half.Value = "";
        txttotal_Yrly.Value = "";
        txtpercnt_Half.Value = "";
        txtpercnt_Yrly.Value = "";
        txtMM.Value = "";
        weight.Value = "";
        weight2.Value = "";
        height.Value = "";
        height2.Value = "";
        txttea_rmrk.Value = "";
        promoteclass.Value = "";
        phehealth.Value = "";
        phehealth2.Value = "";
        discipline.Value = "";
        discipline2.Value = "";
        workexp.Value = "";
        workexp2.Value = "";
        drawing.Value = "";
        drawing2.Value = "";
        artedu.Value = "";
        artedu2.Value = "";
        game.Value = "";
        game2.Value = "";
        dance.Value = "";
        dance2.Value = "";
        karate.Value = "";
        karate2.Value = "";
        engtotal.Value = "";
        engtotal2.Value = "";
        hinditotal.Value = "";
        hinditotal2.Value = "";
        mathstotal.Value = "";
        mathstotal2.Value = "";
        GKtotal.Value = "";
        GKtotal2.Value = "";
        scitotal.Value = "";
        scitotal2.Value = "";
        CStotal.Value = "";
        CStotal2.Value = "";
        
        ddlconduct.SelectedIndex = 0;
    }

    protected void txt_rno_TextChanged(object sender, EventArgs e)
    {

        bool temp = false;
        string connStr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from CLASS_III_V where rollno='" + txtrollno.Text.Trim() + "' and class='" + txtclass.Text + "'and sec='" + txtsection.Text + "' and sessionss = '" + lblsession.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            txtnam.Text = dr["name"].ToString();
            txtfather.Text = dr["fname"].ToString();
            txtmother.Text = dr["mname"].ToString();
            txtaddrs.Text = dr["address"].ToString();
            txtadmsn.Text = dr["admissionno"].ToString();
            txtsection.Text = dr["sec"].ToString();
            txtclass.Text = dr["class"].ToString();
            txtbloodgrp.Text = dr["bloodgrp"].ToString();
            txtdob.Text = dr["dob"].ToString();
            txtstupic.Text = dr["student_pic"].ToString();


            mathgrndtot.Value = dr["mathsgrndtot"].ToString();
            hindigrndtot.Value = dr["hindigrndtot"].ToString();
            enggrndtot.Value = dr["enggrndtot"].ToString();
            scigrndtot.Value = dr["scigrndtot"].ToString();
            csgrndtot.Value = dr["csgrndtot"].ToString();
            gkgrndtot.Value = dr["GKgrndtot"].ToString();
            SSTgrndtot.Value = dr["SSTgrndtot"].ToString();
            txtG_Percnt.Value = dr["Grand_Percnt"].ToString();
            txtGtotal.Value = dr["Grand_total"].ToString();

            attnd1.Value = dr["attndnce1"].ToString();
            attnd2.Value = dr["attndnce2"].ToString();


            Sanskgrndtot.Value = dr["sanskgrndtot"].ToString();
            mathstheory2.Value = dr["mathstheory2"].ToString();
            mathstheory.Value = dr["mathstheory"].ToString();
            mathsErmnt2.Value = dr["mathsErmnt2"].ToString();
            mathsErmnt.Value = dr["mathsErmnt"].ToString();
            mathsNbook2.Value = dr["mathsNbook2"].ToString();
            mathsNbook.Value = dr["mathsNbook"].ToString();
            mathsPtest2.Value = dr["mathsPtest2"].ToString();
            mathsPtest.Value = dr["mathsPtest"].ToString();
            hinditheory2.Value = dr["hinditheory2"].ToString();
            hinditheory.Value = dr["hinditheory"].ToString();
            hindiErmnt2.Value = dr["hindiErmnt2"].ToString();
            hindiErmnt.Value = dr["hindiErmnt"].ToString();
            hindiNbook2.Value = dr["hindiNbook2"].ToString();
            hindiNbook.Value = dr["hindiNbook"].ToString();
            hindiPtest2.Value = dr["hindiPtest2"].ToString();
            hindiPtest.Value = dr["hindiPtest"].ToString();
            engtheory2.Value = dr["engtheory2"].ToString();
            engtheory.Value = dr["engtheory"].ToString();
            engErmnt2.Value = dr["engErmnt2"].ToString();
            engErmnt.Value = dr["engErmnt"].ToString();
            engNbook2.Value = dr["engNbook2"].ToString();
            engNbook.Value = dr["engNbook"].ToString();
            engPtest2.Value = dr["engPtest2"].ToString();
            engPtest.Value = dr["engPtest"].ToString();
            GKNbook2.Value = dr["GKNbook2"].ToString();
            GKNbook.Value = dr["GKNbook"].ToString();
            GKPtest2.Value = dr["GKPtest2"].ToString();
            GKPtest.Value = dr["GKPtest"].ToString();
            CStheory2.Value = dr["CStheory2"].ToString();
            CStheory.Value = dr["cstheory"].ToString();
            CSErmnt2.Value = dr["csErmnt2"].ToString();
            CSErmnt.Value = dr["CSErmnt"].ToString();
            CSNbook2.Value = dr["csNbook2"].ToString();
            CSNbook.Value = dr["csNbook"].ToString();
            CSPtest2.Value = dr["csPtest2"].ToString();
            txtpercnt_Yrly.Value = dr["totper_Yrly"].ToString();
            txtpercnt_Half.Value = dr["totper_half"].ToString();
            txttotal_Yrly.Value = dr["totYearly"].ToString();
            txttotal_Half.Value = dr["tothalf"].ToString();
            GKtheory2.Value = dr["GKtheory2"].ToString();
            GKtheory.Value = dr["GKtheory"].ToString();
            GKErmnt2.Value = dr["GKErmnt2"].ToString();
            GKErmnt.Value = dr["GKErmnt"].ToString();
            phehealth.Value = dr["phe_health"].ToString();
            workexp.Value = dr["work_xperience"].ToString();
            workexp2.Value = dr["work_xperience2"].ToString();
            promoteclass.Value = dr["promote_class"].ToString();
            txttea_rmrk.Value = dr["teachr_remrks"].ToString();
            height2.Value = dr["heighthalfy2"].ToString();
            weight2.Value = dr["wghthalfy2"].ToString();
            height.Value = dr["heighthalfy"].ToString();
            weight.Value = dr["wghthalfy"].ToString();
            txtMM.Value = dr["Max_marks"].ToString();
            drawing.Value = dr["drawing"].ToString();
            discipline2.Value = dr["discipline2"].ToString();
            discipline.Value = dr["discipline"].ToString();
            artedu2.Value = dr["artedu2"].ToString();
            artedu.Value = dr["artedu"].ToString();
            phehealth2.Value = dr["phe_health2"].ToString();
            hinditotal.Value = dr["hinditot"].ToString();
            engtotal2.Value = dr["engtot2"].ToString();
            engtotal.Value = dr["engtot"].ToString();
            dance2.Value = dr["dance2"].ToString();
            dance.Value = dr["dance"].ToString();
            karate2.Value = dr["karate2"].ToString();
            karate.Value = dr["karate"].ToString();
            game2.Value = dr["games2"].ToString();
            game.Value = dr["games"].ToString();
            drawing2.Value = dr["drawing2"].ToString();
            ddlconduct.SelectedItem.Text = dr["conduct"].ToString();
            
            GKtotal2.Value = dr["GKtot2"].ToString();
            GKtotal.Value = dr["GKtot"].ToString();
            CStotal2.Value = dr["cstot2"].ToString();
            CStotal.Value = dr["cstot"].ToString();
            CSPtest.Value = dr["csPtest"].ToString();

            scitotal2.Value = dr["scitot2"].ToString();
            scitotal.Value = dr["scitot"].ToString();
            mathstotal2.Value = dr["mathstot2"].ToString();
            mathstotal.Value = dr["mathstot"].ToString();
            hinditotal2.Value = dr["hinditot2"].ToString();
            sciPtest.Value = dr["sciPtest"].ToString();
            sciPtest2.Value = dr["sciPtest2"].ToString();
            sciNbook.Value = dr["sciNbook"].ToString();
            sciNbook2.Value = dr["sciNbook2"].ToString();
            sciErmnt.Value = dr["sciErmnt"].ToString();
            sciErmnt2.Value = dr["sciErmnt2"].ToString();
            scitheory.Value = dr["scitheory"].ToString();
            scitheory2.Value = dr["scitheory2"].ToString();

            SSTPtest.Value = dr["sstPtest"].ToString();
            SSTPtest2.Value = dr["sstPtest2"].ToString();
            SSTNbook.Value = dr["sstNbook"].ToString();
            SSTNbook2.Value = dr["sstNbook2"].ToString();
            SSTErmnt.Value = dr["sstErmnt"].ToString();

            SSTErmnt2.Value = dr["sstErmnt2"].ToString();

            SSTtheory.Value = dr["ssttheory"].ToString();
            SSTtheory2.Value = dr["ssttheory2"].ToString();
            SanskPtest.Value = dr["sanskPtest"].ToString();
            SanskPtest2.Value = dr["sanskPtest2"].ToString();
            SanskNbook.Value = dr["sanskNbook"].ToString();
            SanskNbook2.Value = dr["sanskNbook2"].ToString();
            SanskErmnt.Value = dr["sanskErmnt"].ToString();
            SanskErmnt2.Value = dr["sanskErmnt2"].ToString();
            Sansktheory.Value = dr["sansktheory"].ToString();
            Sansktheory2.Value = dr["sansktheory2"].ToString();

            Sansktotal2.Value = dr["sansktot2"].ToString();

            Sansktotal.Value = dr["sansktot"].ToString();

            SSTtotal2.Value = dr["ssttot2"].ToString();

            SSTtotal.Value = dr["ssttot"].ToString();


            temp = true;
        }
        if (temp == false)
        {
            string connStr1 = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con1 = new SqlConnection(connStr1);
            con1.Open();

            SqlCommand com = new SqlCommand("select * from tbl_sturegister where rollno='" + txtrollno.Text.Trim() + "' and class_nm='" + txtclass.Text + "'  and section='" + txtsection.Text + "'", con1);
            SqlDataReader drr = com.ExecuteReader();
            while (drr.Read())
            {
                
                txtnam.Text = drr["fullname"].ToString();
                txtfather.Text = drr["fname"].ToString();
                txtmother.Text = drr["mname"].ToString();
                txtaddrs.Text = drr["addrss"].ToString();
                txtadmsn.Text = drr["admissionno"].ToString();
                txtbloodgrp.Text = drr["bloodgrp"].ToString();
                txtdob.Text = (drr["dob"]).ToString();
                txtstupic.Text = drr["st_img"].ToString();

                temp = true;
                //con.Close();
            }
            //MessageBox.Show("not found");
            con.Close();

        }
        if (temp == false)
        {
            Response.Write("<script>alert('There Is No Such Kind Of Roll No. Exist !!!')</script>");
            //con.Close();

        }

    }

}