﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
public partial class III_to_V : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt = new DataTable();
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["constring"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            lblsession.Text = Request.QueryString["session"].ToString();
            if (!IsPostBack)
            {
              
                txtclass.Text = Session["classs"].ToString();
                txtsection.Text = Session["Sec"].ToString();

            }
        }
        catch (Exception ae)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alert('" + ae.Message + "',this.open('../index.aspx'))", true);
        }
    }
//    protected void btn_save_click(object sender, EventArgs e)
//    {
//        SqlCommand cmd = new SqlCommand(@"Insert into CLASS_III_V(name, class, sec, rollno, admissionno, fname, mname, bloodgrp,dob, address, engPtest, engPtest2, engNbook, engNbook2, engErmnt, engErmnt2, engtheory, engtheory2, hindiPtest, hindiPtest2, hindiNbook, hindiNbook2, hindiErmnt, hindiErmnt2, hinditheory, hinditheory2, mathsPtest, mathsPtest2, mathsNbook, mathsNbook2, mathsErmnt, mathsErmnt2, mathstheory, mathstheory2, sciPtest, sciPtest2, sciNbook, sciNbook2, sciErmnt, sciErmnt2, scitheory, scitheory2, sstPtest, sstPtest2, sstNbook, sstNbook2, sstErmnt, sstErmnt2, ssttheory, ssttheory2, csPtest, csPtest2, csNbook, csNbook2, csErmnt, csErmnt2, cstheory, cstheory2, sanskPtest, sanskPtest2, sanskNbook, sanskNbook2, sanskErmnt, sanskErmnt2, sansktheory, sansktheory2, GKPtest, GKPtest2, GKNbook, GKNbook2, GKErmnt, GKErmnt2, GKtheory, GKtheory2, tothalf, totYearly, totper_half, totper_Yrly, Max_marks, wghthalfy, heighthalfy, wghthalfy2, heighthalfy2, teachr_remrks, promote_class, work_xperience, phe_health, artedu, work_xperience2, phe_health2, artedu2, discipline, discipline2, engtot, engtot2, hinditot, hinditot2, mathstot, mathstot2, scitot, scitot2, ssttot, ssttot2, cstot, cstot2, sansktot, sansktot2, GKtot, GKtot2, drawing, drawing2, games, games2, karate, karate2, dance, dance2,sessionss,enggrndtot,hindigrndtot,sanskgrndtot,mathsgrndtot,scigrndtot,csgrndtot,sstgrndtot,GKgrndtot,Grand_total,Grand_Percnt,attndnce1,attndnce2,conduct,student_pic) 
//                  values(@name, @class, @sec, @rollno, @admissionno, @fname, @mname, @bloodgrp,@dob, @address, @engPtest, @engPtest2, @engNbook, @engNbook2, @engErmnt, @engErmnt2, @engtheory, @engtheory2, @hindiPtest, @hindiPtest2, @hindiNbook, @hindiNbook2, @hindiErmnt, @hindiErmnt2, @hinditheory, @hinditheory2, @mathsPtest, @mathsPtest2, @mathsNbook, @mathsNbook2, @mathsErmnt, @mathsErmnt2, @mathstheory, @mathstheory2, @sciPtest, @sciPtest2, @sciNbook, @sciNbook2, @sciErmnt, @sciErmnt2, @scitheory, @scitheory2, @sstPtest, @sstPtest2, @sstNbook, @sstNbook2, @sstErmnt, @sstErmnt2, @ssttheory, @ssttheory2, @csPtest, @csPtest2, @csNbook, @csNbook2, @csErmnt, @csErmnt2, @cstheory, @cstheory2, @sanskPtest, @sanskPtest2, @sanskNbook, @sanskNbook2, @sanskErmnt, @sanskErmnt2, @sansktheory, @sansktheory2, @GKPtest, @GKPtest2, @GKNbook, @GKNbook2, @GKErmnt, @GKErmnt2, @GKtheory, @GKtheory2, @tothalf, @totYearly, @totper_half, @totper_Yrly, @Max_marks, @wghthalfy, @heighthalfy, @wghthalfy2, @heighthalfy2, @teachr_remrks, @promote_class, @work_xperience, @phe_health, @artedu, @work_xperience2, @phe_health2, @artedu2, @discipline, @discipline2, @engtot, @engtot2, @hinditot, @hinditot2, @mathstot, @mathstot2, @scitot, @scitot2, @ssttot, @ssttot2, @cstot, @cstot2, @sansktot, @sansktot2, @GKtot, @GKtot2, @drawing, @drawing2, @games, @games2, @karate, @karate2, @dance, @dance2,@sessionss,@enggrndtot,@hindigrndtot,@sanskgrndtot,@mathsgrndtot,@scigrndtot,@csgrndtot,@sstgrndtot,@GKgrndtot,@Grand_total,@Grand_Percnt,@attndnce1,@attndnce2, @conduct,@student_pic)", cs.connect());

//        //cmd = new SqlCommand("Save_reportcard", cs.Connect());
//        //cmd.CommandType = CommandType.StoredProcedure;

//        cmd.Parameters.AddWithValue("@name", txtnam.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@class", txtclass.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@sec", txtsection.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@rollno", txtrollno.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@admissionno", txtadmsn.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@fname", txtfather.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mname", txtmother.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@bloodgrp", txtbloodgrp.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@dob", txtdob.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@student_pic", txtstupic.Text);
//        cmd.Parameters.AddWithValue("@address", txtaddrs.Text.ToUpper());
        
//        cmd.Parameters.AddWithValue("@engPtest", engPtestT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@engPtest2", engPtest2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@engNbook", engNbookT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@engNbook2", engNbook2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@engErmnt", engErmntT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@engErmnt2", engErmnt2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@engtheory", engtheoryT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@engtheory2", engtheory2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@enggrndtot", enggrndtot.Value.ToUpper());

//        cmd.Parameters.AddWithValue("@hindiPtest", hindiPtestT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@hindiPtest2", hindiPtest2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@hindiNbook", hindiNbookT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@hindiNbook2", hindiNbook2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@hindiErmnt", hindiErmntT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@hindiErmnt2", hindiErmnt2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@hinditheory", hinditheoryT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@hinditheory2", hinditheory2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@hindigrndtot", hindigrndtot.Value.ToUpper());

//        cmd.Parameters.AddWithValue("@mathsPtest", mathsPtestT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathsPtest2", mathsPtest2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathsNbook", mathsNbookT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathsNbook2", mathsNbook2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathsErmnt", mathsErmntT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathsErmnt2", mathsErmnt2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathstheory", mathstheoryT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathstheory2", mathstheory2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathsgrndtot", mathgrndtot.Value.ToUpper());

//        cmd.Parameters.AddWithValue("@sciPtest", sciPtestT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sciPtest2", sciPtest2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sciNbook", sciNbookT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sciNbook2", sciNbook2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sciErmnt", sciErmntT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sciErmnt2", sciErmnt2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@scitheory", scitheoryT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@scitheory2", scitheory2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@scigrndtot", scigrndtot.Value.ToUpper());

//        cmd.Parameters.AddWithValue("@sstPtest", SSTPtestT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sstPtest2", SSTPtest2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sstNbook", SSTNbookT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sstNbook2", SSTNbook2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sstErmnt", SSTErmntT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sstErmnt2", SSTErmnt2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@ssttheory", SSTtheoryT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@ssttheory2", SSTtheory2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sstgrndtot", SSTgrndtot.Value.ToUpper());

//        cmd.Parameters.AddWithValue("@csPtest", CSPtestT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@csPtest2", CSPtest2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@csNbook", CSNbookT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@csNbook2", CSNbook2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@csErmnt", CSErmntT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@csErmnt2", CSErmnt2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@cstheory", CStheoryT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@cstheory2", CStheory2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@csgrndtot", csgrndtot.Value.ToUpper());
      
//        if (Sanskgrndtot.Value == "0")
//        {
//            Sanskgrndtot.Value = "";
//        }

//        cmd.Parameters.AddWithValue("@sanskPtest", SanskPtestT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sanskPtest2", SanskPtest2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sanskNbook", SanskNbookT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sanskNbook2", SanskNbook2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sanskErmnt", SanskErmntT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sanskErmnt2", SanskErmnt2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sansktheory", SansktheoryT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sansktheory2", Sansktheory2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sanskgrndtot", Sanskgrndtot.Value.ToUpper());

//        cmd.Parameters.AddWithValue("@GKPtest", GKPtestT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKPtest", GKPtest.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKPtest2", GKPtest2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKNbook", GKNbookT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKNbook", GKNbook.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKNbook2", GKNbook2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKErmnt", GKErmntT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKErmnt", GKErmnt.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKErmnt2", GKErmnt2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKtheory", GKtheoryT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKtheory", GKtheory.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKtheory2", GKtheory2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKgrndtot", gkgrndtot.Value.ToUpper());

//        cmd.Parameters.AddWithValue("@Grand_total", txtGtotal.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@Grand_Percnt", txtG_Percnt.Value.ToUpper());
       
//        cmd.Parameters.AddWithValue("@attndnce1", attnd1T1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@attndnce2", attnd2.Value.ToUpper());

//        cmd.Parameters.AddWithValue("@tothalf", txttotal_HalfT1.Value.ToUpper());      
//       cmd.Parameters.AddWithValue("@tothalf", txttotal_Half.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@totYearly", txttotal_Yrly.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@totper_half", txtpercnt_HalfT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@totper_half", txtpercnt_Half.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@totper_Yrly", txtpercnt_Yrly.Value.ToUpper());       
//        cmd.Parameters.AddWithValue("@wghthalfy", weightT1.Value.ToUpper());       
//        cmd.Parameters.AddWithValue("@heighthalfy", heightT1.Value.ToUpper());      
//        cmd.Parameters.AddWithValue("@wghthalfy2", weight2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@heighthalfy2", height2.Value.ToUpper());      
//        cmd.Parameters.AddWithValue("@teachr_remrks", txttea_rmrk.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@promote_class", promoteclass.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@work_xperience", workexpT1.Value.ToUpper());      
//        cmd.Parameters.AddWithValue("@work_xperience2", workexp2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@phe_health", phehealthT1.Value.ToUpper());       
//        cmd.Parameters.AddWithValue("@phe_health2", phehealth2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@artedu", arteduT1.Value.ToUpper());     
//        cmd.Parameters.AddWithValue("@artedu2", artedu2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@discipline", disciplineT1.Value.ToUpper());       
//        cmd.Parameters.AddWithValue("@discipline2", discipline2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@drawing", drawingT1.Value.ToUpper());      
//        cmd.Parameters.AddWithValue("@drawing2", drawing2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@games", gameT1.Value.ToUpper());       
//        cmd.Parameters.AddWithValue("@games2", game2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@karate", karateT1.Value.ToUpper());       
//        cmd.Parameters.AddWithValue("@karate2", karate2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@dance", danceT1.Value.ToUpper());       
//        cmd.Parameters.AddWithValue("@dance2", dance2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@engtot", engtotalT1.Value.ToUpper());        
//        cmd.Parameters.AddWithValue("@engtot2", engtotal2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@hinditot", hinditotalT1.Value.ToUpper());       
//        cmd.Parameters.AddWithValue("@hinditot2", hinditotal2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathstot", mathstotalT1.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@mathstot2", mathstotal2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@scitot", scitotalT1.Value.ToUpper());       
//        cmd.Parameters.AddWithValue("@scitot2", scitotal2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@ssttot", SSTtotalT1.Value.ToUpper());     
//        cmd.Parameters.AddWithValue("@ssttot2", SSTtotal2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@cstot", CStotalT1.Value.ToUpper());        
//        cmd.Parameters.AddWithValue("@cstot2", CStotal2.Value.ToUpper());

//        if (Sansktotal.Value == "0")
//        {
//            Sansktotal.Value = "";
//        }

//        if (Sansktotal2.Value == "0")
//        {
//            Sansktotal2.Value = "";
//        }
//        cmd.Parameters.AddWithValue("@sansktot", SansktotalT1.Value.ToUpper());        
//        cmd.Parameters.AddWithValue("@sansktot2", Sansktotal2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@GKtot", GKtotalT1.Value.ToUpper());     
//        cmd.Parameters.AddWithValue("@GKtot2", GKtotal2.Value.ToUpper());
//        cmd.Parameters.AddWithValue("@sessionss", lblsession.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@conduct", ddlconduct.SelectedItem.Text.ToUpper());

//        if (DropDownList1.Text == "Term-I")
//        {
//            cmd.Parameters.AddWithValue("@Max_marks", txtMM.Value.ToUpper());
//            cmd.Parameters.AddWithValue("@teachr_remrks", txttea_rmrkT1.Value.ToUpper());
//        }

//        if (DropDownList1.Text == "Term-II")
//        {
//             cmd.Parameters.AddWithValue("@Max_marks", txtMM.Value.ToUpper());
//             cmd.Parameters.AddWithValue("@teachr_remrks", txttea_rmrk.Value.ToUpper());
//        }

      
//        cmd.ExecuteNonQuery();
//        try
//        {
//            int i = cmd.ExecuteNonQuery();
//            if (i > 0)
//            {
//                cs.exec_qry("Delete from CLASS_III_V where id not in(select max(id) from CLASS_III_V group by name, class, sec, rollno, admissionno, fname, mname, bloodgrp, sessionss)");//Remove All Duplicates Entries From (this) Table 
//                Response.Write("<script>alert('You Have Sucessfully Saved Marks !!! ')</script>");
//                Session["admsnno"] = txtadmsn.Text.ToUpper();
//                Session["Term"] = DropDownList1.SelectedItem.Text.ToUpper();
//                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.success('Marks Saved Successfully of " + txtnam.Text.ToUpper() + "')", true);
//                Response.Write("<script>");
//                Response.Write("window.open('sampleresult_III_V.aspx?sessions=" + lblsession.Text + "','_blank')");
//                Response.Write("</script>");
//                clrfld();
//            }
//            else
//            {
//                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Data Inserted Successfuly')", true);
//            }
//        }
//        catch (Exception ex)
//        {
//            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Something Went Wrong.. " + ex + "')", true);
//        }

//    }

    protected void clrfld()
    {
        txtnam.Text = "";
        txtfather.Text = "";
        txtmother.Text = "";
        txtaddrs.Text = "";
        txtadmsn.Text = "";
        txtrollno.Text = "";
        //txtsection.Text = dr["sec"].ToString();
        //txtclass.Text = dr["class"].ToString();
        txtbloodgrp.Text = "";
        txtdob.Text = "";
        enggrndtot.Value = "";       
        hindigrndtot.Value = "";
        mathgrndtot.Value = "";
        SSTgrndtot.Value = "";
        scigrndtot.Value = "";
        gkgrndtot.Value = "";
        csgrndtot.Value = "";
        Sanskgrndtot.Value = "";
        txtG_Percnt.Value = "";
        txtGtotal.Value = "";
        attnd1.Value = "";
        attnd2.Value = "";
        engNbook.Value = "";
        engNbook2.Value = "";
        engPtest.Value = "";
        engPtest2.Value = "";
        engtheory.Value = "";
        engtheory2.Value = "";
        engErmnt.Value = "";
        engErmnt2.Value = "";
        hindiNbook.Value = "";
        hindiNbook2.Value = "";
        hindiPtest.Value = "";
        hindiPtest2.Value = "";
        hindiErmnt.Value = "";
        hindiErmnt2.Value = "";
        hinditheory.Value = "";
        hinditheory2.Value = "";
        mathsNbook.Value = "";
        mathsNbook2.Value = "";
        mathsPtest.Value = "";
        mathsPtest2.Value = "";
        mathsErmnt.Value = "";
        mathsErmnt2.Value = "";
        mathstheory.Value = "";
        mathstheory2.Value = "";
        sciNbook.Value = "";
        sciNbook2.Value = "";
        sciPtest.Value = "";
        sciPtest2.Value = "";
        scitheory.Value = "";
        scitheory2.Value = "";
        sciErmnt.Value = "";
        sciErmnt2.Value = "";
        CSNbook.Value = "";
        CSNbook2.Value = "";
        CSPtest.Value = "";
        CSPtest2.Value = "";
        CSErmnt.Value = "";
        CSErmnt2.Value = "";
        CStheory.Value = "";
        CStheory2.Value = "";
        GKNbook.Value = "";
        GKNbook2.Value = "";
        GKPtest.Value = "";
        GKPtest2.Value = "";
        GKErmnt.Value = "";
        GKErmnt2.Value = "";
        GKtheory.Value = "";
        GKtheory2.Value = "";
        SSTErmnt.Value = "";
        SSTErmnt2.Value = "";
        SSTPtest.Value = "";
        SSTPtest2.Value = "";

        SSTNbook.Value = "";
        SSTNbook2.Value = "";
        SSTtheory.Value = "";
        SSTtheory2.Value = "";
        SSTtotal.Value = "";
        SSTtotal2.Value = "";

        SanskErmnt.Value = "";
        SanskErmnt2.Value = "";
        SanskNbook.Value = "";
        SanskNbook2.Value = "";
        SanskPtest.Value = "";
        SanskPtest2.Value = "";
        Sansktheory.Value = "";
        Sansktheory2.Value = "";
        Sansktotal.Value = "";
        Sansktotal2.Value = "";

        txttotal_Half.Value = "";
        txttotal_Yrly.Value = "";
        txtpercnt_Half.Value = "";
        txtpercnt_Yrly.Value = "";
        txtMM.Value = "";
        weight.Value = "";
        weight2.Value = "";
        height.Value = "";
        height2.Value = "";
        txttea_rmrk.Value = "";
        promoteclass.Value = "";
        phehealth.Value = "";
        phehealth2.Value = "";
        discipline.Value = "";
        discipline2.Value = "";
        workexp.Value = "";
        workexp2.Value = "";
        drawing.Value = "";
        drawing2.Value = "";
        artedu.Value = "";
        artedu2.Value = "";
        game.Value = "";
        game2.Value = "";
        dance.Value = "";
        dance2.Value = "";
        karate.Value = "";
        karate2.Value = "";
        engtotal.Value = "";
        engtotal2.Value = "";
        hinditotal.Value = "";
        hinditotal2.Value = "";
        mathstotal.Value = "";
        mathstotal2.Value = "";
        GKtotal.Value = "";
        GKtotal2.Value = "";
        scitotal.Value = "";
        scitotal2.Value = "";
        CStotal.Value = "";
        CStotal2.Value = "";
         
        ddlconduct.SelectedIndex = 0;
    }
  
    protected void txt_rno_TextChanged(object sender, EventArgs e)
    {

        bool temp = false;
        string connStr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from CLASS_III_V where rollno='" + txtrollno.Text + "' and class='" + txtclass.Text + "'and sec='" + txtsection.Text + "' and sessionss='" + lblsession.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            txtnam.Text = dr["name"].ToString();
            txtfather.Text = dr["fname"].ToString();
            txtmother.Text = dr["mname"].ToString();
            txtaddrs.Text = dr["address"].ToString();
            txtadmsn.Text = dr["admissionno"].ToString();
            txtsection.Text = dr["sec"].ToString();
            txtclass.Text = dr["class"].ToString();
            txtbloodgrp.Text = dr["bloodgrp"].ToString();
            txtdob.Text = dr["dob"].ToString();
            txtstupic.Text = dr["student_pic"].ToString();
            mathgrndtot.Value = dr["mathsgrndtot"].ToString();
            mathgrndtot.Value = dr["mathsgrndtot"].ToString();
            hindigrndtot.Value = dr["hindigrndtot"].ToString();
            enggrndtot.Value = dr["enggrndtot"].ToString();
            scigrndtot.Value = dr["scigrndtot"].ToString();
            csgrndtot.Value = dr["csgrndtot"].ToString();
            gkgrndtot.Value = dr["GKgrndtot"].ToString();
            SSTgrndtot.Value = dr["SSTgrndtot"].ToString();
            txtG_Percnt.Value = dr["Grand_Percnt"].ToString();
            txtGtotal.Value = dr["Grand_total"].ToString();

            attnd1T1.Value = dr["attndnce1"].ToString();
            attnd1.Value = dr["attndnce1"].ToString();
            attnd2.Value = dr["attndnce2"].ToString();
       

            Sanskgrndtot.Value = dr["sanskgrndtot"].ToString();
            mathstheory2.Value = dr["mathstheory2"].ToString();
            mathstheoryT1.Value = dr["mathstheory"].ToString();
            mathstheory.Value = dr["mathstheory"].ToString();
            mathsErmnt2.Value = dr["mathsErmnt2"].ToString();
            mathsErmntT1.Value = dr["mathsErmnt"].ToString();
            mathsErmnt.Value = dr["mathsErmnt"].ToString();
            mathsNbook2.Value = dr["mathsNbook2"].ToString();
            mathsNbookT1.Value = dr["mathsNbook"].ToString();
            mathsNbook.Value = dr["mathsNbook"].ToString();
            mathsPtest2.Value = dr["mathsPtest2"].ToString();
            mathsPtestT1.Value = dr["mathsPtest"].ToString();
            mathsPtest.Value = dr["mathsPtest"].ToString();
            hinditheory2.Value = dr["hinditheory2"].ToString();
            hinditheoryT1.Value = dr["hinditheory"].ToString();
            hinditheory.Value = dr["hinditheory"].ToString();
            hindiErmnt2.Value = dr["hindiErmnt2"].ToString();
            hindiErmntT1.Value = dr["hindiErmnt"].ToString();
            hindiErmnt.Value = dr["hindiErmnt"].ToString();
            hindiNbook2.Value = dr["hindiNbook2"].ToString();
            hindiNbookT1.Value = dr["hindiNbook"].ToString();
            hindiNbook.Value = dr["hindiNbook"].ToString();
            hindiPtest2.Value = dr["hindiPtest2"].ToString();
            hindiPtestT1.Value = dr["hindiPtest"].ToString();
            hindiPtest.Value = dr["hindiPtest"].ToString();
            engtheory2.Value = dr["engtheory2"].ToString();
            engtheoryT1.Value = dr["engtheory"].ToString();
            engtheory.Value = dr["engtheory"].ToString();
            engErmnt2.Value = dr["engErmnt2"].ToString();
            engErmntT1.Value = dr["engErmnt"].ToString();
            engErmnt.Value = dr["engErmnt"].ToString();
            engNbook2.Value = dr["engNbook2"].ToString();
            engNbookT1.Value = dr["engNbook"].ToString();
            engNbook.Value = dr["engNbook"].ToString();
            engPtest2.Value = dr["engPtest2"].ToString();
            engPtestT1.Value = dr["engPtest"].ToString();
            engPtest.Value = dr["engPtest"].ToString();
            GKNbook2.Value = dr["GKNbook2"].ToString();
            GKNbookT1.Value = dr["GKNbook"].ToString();
            GKNbook.Value = dr["GKNbook"].ToString();
            GKPtest2.Value = dr["GKPtest2"].ToString();
            GKPtestT1.Value = dr["GKPtest"].ToString();
            GKPtest.Value = dr["GKPtest"].ToString();
            CStheory2.Value = dr["CStheory2"].ToString();
            CStheoryT1.Value = dr["cstheory"].ToString();
            CStheory.Value = dr["cstheory"].ToString();
            CSErmnt2.Value = dr["csErmnt2"].ToString();
            CSErmntT1.Value = dr["CSErmnt"].ToString();
            CSErmnt.Value = dr["CSErmnt"].ToString();
            CSNbook2.Value = dr["csNbook2"].ToString();
            CSNbookT1.Value = dr["csNbook"].ToString();
            CSNbook.Value = dr["csNbook"].ToString();
            CSPtest2.Value = dr["csPtest2"].ToString();
            txtpercnt_Yrly.Value = dr["totper_Yrly"].ToString();
            txtpercnt_HalfT1.Value = dr["totper_half"].ToString();
            txtpercnt_Half.Value = dr["totper_half"].ToString();
            txttotal_Yrly.Value = dr["totYearly"].ToString();
            txttotal_HalfT1.Value = dr["tothalf"].ToString();
            txttotal_Half.Value = dr["tothalf"].ToString();
            GKtheory2.Value = dr["GKtheory2"].ToString();
            GKtheoryT1.Value = dr["GKtheory"].ToString();
            GKtheory.Value = dr["GKtheory"].ToString();
            GKErmnt2.Value = dr["GKErmnt2"].ToString();
            GKErmntT1.Value = dr["GKErmnt"].ToString();
            GKErmnt.Value = dr["GKErmnt"].ToString();
            phehealth.Value = dr["phe_health"].ToString();
            phehealthT1.Value = dr["phe_health"].ToString();
            workexpT1.Value = dr["work_xperience"].ToString();
            workexp.Value = dr["work_xperience"].ToString();
            workexp2.Value = dr["work_xperience2"].ToString();
            promoteclass.Value = dr["promote_class"].ToString();
            txttea_rmrkT1.Value = dr["teachr_remrks"].ToString();
            txttea_rmrk.Value = dr["teachr_remrks"].ToString();
            heightT1.Value = dr["heighthalfy"].ToString();
            weightT1.Value = dr["wghthalfy"].ToString();
            height2.Value = dr["heighthalfy2"].ToString();
            weight2.Value = dr["wghthalfy2"].ToString();
            height.Value = dr["heighthalfy"].ToString();
            weight.Value = dr["wghthalfy"].ToString();
            txtMMT1.Value = dr["Max_marks"].ToString();
            txtMM.Value = dr["Max_marks"].ToString();
            drawingT1.Value = dr["drawing"].ToString();
            drawing.Value = dr["drawing"].ToString();
            discipline2.Value = dr["discipline2"].ToString();
            discipline.Value = dr["discipline"].ToString();
            disciplineT1.Value = dr["discipline"].ToString();
            artedu2.Value = dr["artedu2"].ToString();
            artedu.Value = dr["artedu"].ToString();
            arteduT1.Value = dr["artedu"].ToString();
            phehealthT1.Value = dr["phe_health"].ToString();
            phehealth2.Value = dr["phe_health2"].ToString();
            hinditotalT1.Value = dr["hinditot"].ToString();
            hinditotal.Value = dr["hinditot"].ToString();
            engtotal2.Value = dr["engtot2"].ToString();
            engtotalT1.Value = dr["engtot"].ToString();
            engtotal.Value = dr["engtot"].ToString();
            dance2.Value = dr["dance2"].ToString();
            dance.Value = dr["dance"].ToString();
            danceT1.Value = dr["dance"].ToString();
            karate2.Value = dr["karate2"].ToString();
            karate.Value = dr["karate"].ToString();
            karateT1.Value = dr["karate"].ToString();
            game2.Value = dr["games2"].ToString();
            game.Value = dr["games"].ToString();
            gameT1.Value = dr["games"].ToString();
           
            drawing2.Value = dr["drawing2"].ToString();
            ddlconduct.SelectedItem.Text = dr["conduct"].ToString();
            lblsession.Text = dr["sessionss"].ToString();
            GKtotal2.Value = dr["GKtot2"].ToString();
            GKtotal.Value = dr["GKtot"].ToString();
            GKtotalT1.Value = dr["GKtot"].ToString();
            CStotal2.Value = dr["cstot2"].ToString();
            CStotalT1.Value = dr["cstot"].ToString();
            CStotal.Value = dr["cstot"].ToString();
            CSPtest.Value = dr["csPtest"].ToString();
            CSPtestT1.Value = dr["csPtest"].ToString();
            
            scitotal2.Value = dr["scitot2"].ToString();
            scitotal.Value = dr["scitot"].ToString();
            scitotalT1.Value = dr["scitot"].ToString();
            mathstotal2.Value = dr["mathstot2"].ToString();
            mathstotal.Value = dr["mathstot"].ToString();
            mathstotalT1.Value = dr["mathstot"].ToString();
            hinditotal2.Value = dr["hinditot2"].ToString();
            sciPtest.Value = dr["sciPtest"].ToString();
            sciPtestT1.Value = dr["sciPtest"].ToString();
            sciPtest2.Value = dr["sciPtest2"].ToString();
            sciNbook.Value = dr["sciNbook"].ToString();
            sciNbookT1.Value = dr["sciNbook"].ToString();
            sciNbook2.Value = dr["sciNbook2"].ToString();
            sciErmntT1.Value = dr["sciErmnt"].ToString();
            sciErmnt.Value = dr["sciErmnt"].ToString();
            sciErmnt2.Value = dr["sciErmnt2"].ToString();
            scitheory.Value = dr["scitheory"].ToString();
            scitheoryT1.Value = dr["scitheory"].ToString();
            scitheory2.Value = dr["scitheory2"].ToString();
            SSTPtest.Value = dr["sstPtest"].ToString();
            SSTPtestT1.Value = dr["sstPtest"].ToString();
            SSTPtest2.Value = dr["sstPtest2"].ToString();
            SSTNbook.Value = dr["sstNbook"].ToString();
            SSTNbookT1.Value = dr["sstNbook"].ToString();
            SSTNbook2.Value = dr["sstNbook2"].ToString();
            SSTErmnt.Value = dr["sstErmnt"].ToString();
            SSTErmntT1.Value = dr["sstErmnt"].ToString();
            SSTErmnt2.Value = dr["sstErmnt2"].ToString();
            SSTtheoryT1.Value = dr["ssttheory"].ToString();
            SSTtheory.Value = dr["ssttheory"].ToString();
            SSTtheory2.Value = dr["ssttheory2"].ToString();
            SanskPtest.Value = dr["sanskPtest"].ToString();
            SanskPtestT1.Value = dr["sanskPtest"].ToString();
            SanskPtest2.Value = dr["sanskPtest2"].ToString();
            SanskNbookT1.Value = dr["sanskNbook"].ToString();
            SanskNbook.Value = dr["sanskNbook"].ToString();
            SanskNbook2.Value = dr["sanskNbook2"].ToString();
            SanskErmnt.Value = dr["sanskErmnt"].ToString();
            SanskErmntT1.Value = dr["sanskErmnt"].ToString();
            SanskErmnt2.Value = dr["sanskErmnt2"].ToString();
            Sansktheory.Value = dr["sansktheory"].ToString();
            SansktheoryT1.Value = dr["sansktheory"].ToString();
            Sansktheory2.Value = dr["sansktheory2"].ToString();
          
            Sansktotal2.Value = dr["sansktot2"].ToString();

            Sansktotal.Value = dr["sansktot"].ToString();
            SansktotalT1.Value = dr["sansktot"].ToString();

            SSTtotal2.Value = dr["ssttot2"].ToString();

            SSTtotal.Value = dr["ssttot"].ToString();
            SSTtotalT1.Value = dr["ssttot"].ToString();



            temp = true;
        }
        if (temp == false)
        {
            string connStr1 = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con1 = new SqlConnection(connStr1);
            con1.Open();

            SqlCommand com = new SqlCommand("select * from tbl_sturegister where rollno='" + txtrollno.Text.Trim() + "' and class_nm='" + txtclass.Text + "'  and section='" + txtsection.Text + "' and sesnm='" + lblsession.Text + "'", con1);
            SqlDataReader drr = com.ExecuteReader();
            while (drr.Read())
            {
                
                txtnam.Text = drr["fullname"].ToString();
                txtfather.Text = drr["fname"].ToString();
                txtmother.Text = drr["mname"].ToString();
                txtaddrs.Text = drr["addrss"].ToString();
                txtadmsn.Text = drr["admissionno"].ToString();
                txtbloodgrp.Text = drr["bloodgrp"].ToString();
                txtdob.Text = (drr["dob"]).ToString();
                txtstupic.Text = drr["st_img"].ToString();
               
                temp = true;
                //con.Close();
            }
            //MessageBox.Show("not found");
            con.Close();

        }
        if (temp == false)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(),
"alert",
"alert('There Is No Such Kind Of Roll No. Exist !!!');",
true); clrfld();
            //con.Close();

        }

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.Text == "Term-I")
        {
            wrapperOne.Visible = true;
            wrapperTwo.Visible = false;
             engPtest2.Disabled = true;
             engNbook2.Disabled = true;
             engErmnt2.Disabled = true;
            engtheory2.Disabled = true;
           hindiPtest2.Disabled = true;
           hindiNbook2.Disabled = true;
           hindiErmnt2.Disabled = true;
          hinditheory2.Disabled = true;
           SanskPtest2.Disabled = true;
           SanskNbook2.Disabled = true;
           SanskErmnt2.Disabled = true;
          Sansktheory2.Disabled = true;
           mathsPtest2.Disabled = true;
           mathsNbook2.Disabled = true;
           mathsErmnt2.Disabled = true;
          mathstheory2.Disabled = true;
             sciPtest2.Disabled = true;
             sciNbook2.Disabled = true;
             sciErmnt2.Disabled = true;
            scitheory2.Disabled = true;
             SSTPtest2.Disabled = true;
             SSTNbook2.Disabled = true;
             SSTErmnt2.Disabled = true;
            SSTtheory2.Disabled = true;
              CSPtest2.Disabled = true;
              CSNbook2.Disabled = true;
              CSErmnt2.Disabled = true;
             CStheory2.Disabled = true;
              GKPtest2.Disabled = true;
              GKNbook2.Disabled = true;
              GKErmnt2.Disabled = true;
             GKtheory2.Disabled = true;
         txttotal_Yrly.Disabled = true;
         txtpercnt_Yrly.Disabled = true;
              workexp2.Disabled = true;
               artedu2.Disabled = true;
            phehealth2.Disabled = true;
              drawing2.Disabled = true;
                dance2.Disabled = true;
                 game2.Disabled = true;
               karate2.Disabled = true;
           discipline2.Disabled = true;
                attnd2.Disabled = true;
               height2.Disabled = true;
               weight2.Disabled = true;


               engPtest.Disabled = false;
               engNbook.Disabled = false;
               engErmnt.Disabled = false;
               engtheory.Disabled = false;
               hindiPtest.Disabled = false;
               hindiNbook.Disabled = false;
               hindiErmnt.Disabled = false;
               hinditheory.Disabled = false;
               SanskPtest.Disabled = false;
               SanskNbook.Disabled = false;
               SanskErmnt.Disabled = false;
               Sansktheory.Disabled = false;
               mathsPtest.Disabled = false;
               mathsNbook.Disabled = false;
               mathsErmnt.Disabled = false;
               mathstheory.Disabled = false;
               sciPtest.Disabled = false;
               sciNbook.Disabled = false;
               sciErmnt.Disabled = false;
               scitheory.Disabled = false;
               SSTPtest.Disabled = false;
               SSTNbook.Disabled = false;
               SSTErmnt.Disabled = false;
               SSTtheory.Disabled = false;
               CSPtest.Disabled = false;
               CSNbook.Disabled = false;
               CSErmnt.Disabled = false;
               CStheory.Disabled = false;
               GKPtest.Disabled = false;
               GKNbook.Disabled = false;
               GKErmnt.Disabled = false;
               GKtheory.Disabled = false;
               txttotal_Half.Disabled = false;
               txtpercnt_Half.Disabled = false;
               workexp.Disabled = false;
               artedu.Disabled = false;
               phehealth.Disabled = false;
               drawing.Disabled = false;
               dance.Disabled = false;
               game.Disabled = false;
               karate.Disabled = false;
               discipline.Disabled = false;
               attnd1.Disabled = false;
               height.Disabled = false;
               weight.Disabled = false;


             
        }

        if (DropDownList1.Text == "Term-II")
        {
            wrapperTwo.Visible = true;
            wrapperOne.Visible = false;
            engPtest.Disabled = true;
            engNbook.Disabled = true;
            engErmnt.Disabled = true;
            engtheory.Disabled = true;
            hindiPtest.Disabled = true;
            hindiNbook.Disabled = true;
            hindiErmnt.Disabled = true;
            hinditheory.Disabled = true;
            SanskPtest.Disabled = true;
            SanskNbook.Disabled = true;
            SanskErmnt.Disabled = true;
            Sansktheory.Disabled = true;
            mathsPtest.Disabled = true;
            mathsNbook.Disabled = true;
            mathsErmnt.Disabled = true;
            mathstheory.Disabled = true;
            sciPtest.Disabled = true;
            sciNbook.Disabled = true;
            sciErmnt.Disabled = true;
            scitheory.Disabled = true;
            SSTPtest.Disabled = true;
            SSTNbook.Disabled = true;
            SSTErmnt.Disabled = true;
            SSTtheory.Disabled = true;
            CSPtest.Disabled = true;
            CSNbook.Disabled = true;
            CSErmnt.Disabled = true;
            CStheory.Disabled = true;
            GKPtest.Disabled = true;
            GKNbook.Disabled = true;
            GKErmnt.Disabled = true;
            GKtheory.Disabled = true;
            workexp.Disabled = true;
            artedu.Disabled = true;
            phehealth.Disabled = true;
            drawing.Disabled = true;
            dance.Disabled = true;
            game.Disabled = true;
            karate.Disabled = true;
            discipline.Disabled = true;
            attnd1.Disabled = true;
            height.Disabled = true;
            weight.Disabled = true;



            engPtest2.Disabled = false;
            engNbook2.Disabled = false;
            engErmnt2.Disabled = false;
            engtheory2.Disabled = false;
            hindiPtest2.Disabled = false;
            hindiNbook2.Disabled = false;
            hindiErmnt2.Disabled = false;
            hinditheory2.Disabled = false;
            SanskPtest2.Disabled = false;
            SanskNbook2.Disabled = false;
            SanskErmnt2.Disabled = false;
            Sansktheory2.Disabled = false;
            mathsPtest2.Disabled = false;
            mathsNbook2.Disabled = false;
            mathsErmnt2.Disabled = false;
            mathstheory2.Disabled = false;
            sciPtest2.Disabled = false;
            sciNbook2.Disabled = false;
            sciErmnt2.Disabled = false;
            scitheory2.Disabled = false;
            SSTPtest2.Disabled = false;
            SSTNbook2.Disabled = false;
            SSTErmnt2.Disabled = false;
            SSTtheory2.Disabled = false;
            CSPtest2.Disabled = false;
            CSNbook2.Disabled = false;
            CSErmnt2.Disabled = false;
            CStheory2.Disabled = false;
            GKPtest2.Disabled = false;
            GKNbook2.Disabled = false;
            GKErmnt2.Disabled = false;
            GKtheory2.Disabled = false;
            txttotal_Yrly.Disabled = false;
            txtpercnt_Yrly.Disabled = false;
            workexp2.Disabled = false;
            artedu2.Disabled = false;
            phehealth2.Disabled = false;
            drawing2.Disabled = false;
            dance2.Disabled = false;
            game2.Disabled = false;
            karate2.Disabled = false;
            discipline2.Disabled = false;
            attnd2.Disabled = false;
            height2.Disabled = false;
            weight2.Disabled = false;

            
        }

    }

    protected void btn_save_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("Update Class_III_V set engPtest2 = @engPtest2,engPtest = @engPtest,engNbook2 = @engNbook2,engNbook = @engNbook, engErmnt2 = @engErmnt2,engErmnt = @engErmnt,engtheory2=@engtheory2,engtheory=@engtheory,engmta2=@engmta2,engmta=@engmta,hindiPtest2=@hindiPtest2,hindiPtest=@hindiPtest,hindiNbook2=@hindiNbook2,hindiNbook=@hindiNbook,hindiErmnt2=@hindiErmnt2,hindiErmnt=@hindiErmnt,hinditheory2=@hinditheory2,hinditheory=@hinditheory,hindimta2=@hindimta2,hindimta=@hindimta,mathsPtest2=@mathsPtest2,mathsPtest=@mathsPtest,mathsNbook2=@mathsNbook2,mathsNbook=@mathsNbook,mathsErmnt2=@mathsErmnt2,mathsErmnt=@mathsErmnt,mathstheory2=@mathstheory2,mathstheory=@mathstheory,mathsmta2=@mathsmta2,mathsmta=@mathsmta,sciPtest2=@sciPtest2,sciPtest=@sciPtest,sciNbook2=@sciNbook2,sciNbook=@sciNbook,sciErmnt2=@sciErmnt2,sciErmnt=@sciErmnt,scitheory2=@scitheory2,scitheory=@scitheory,scimta2=@scimta2,scimta=@scimta,sstPtest2=@sstPtest2,sstPtest=@sstPtest,sstNbook2=@sstNbook2,sstNbook=@sstNbook,sstErmnt2=@sstErmnt2,sstErmnt=@sstErmnt,ssttheory2=@ssttheory2,ssttheory=@ssttheory,sstmta2=@sstmta2,sstmta=@sstmta,csPtest2=@csPtest2,csPtest=@csPtest,csNbook2=@csNbook2,csNbook=@csNbook,csErmnt2=@csErmnt2,csErmnt=@csErmnt,cstheory2=@cstheory2,cstheory=@cstheory,csmta2=@csmta2,csmta=@csmta,sanskPtest2=@sanskPtest2,sanskPtest=@sanskPtest,sanskNbook2=@sanskNbook2,sanskNbook=@sanskNbook,sanskErmnt2=@sanskErmnt2,sanskErmnt=@sanskErmnt,sansktheory2=@sansktheory2,sansktheory=@sansktheory,GKPtest2=@GKPtest2,GKPtest=@GKPtest,GKNbook2=@GKNbook2,GKNbook=@GKNbook,GKErmnt2=@GKErmnt2,GKErmnt=@GKErmnt,GKtheory2=@GKtheory2,GKtheory=@GKtheory,totYearly=@totYearly,tothalf=@tothalf,totper_Yrly=@totper_Yrly,totper_half=@totper_half,Max_marks=@Max_marks,wghthalfy2=@wghthalfy2,heighthalfy2=@heighthalfy2,teachr_remrks=@teachr_remrks,promote_class=@promote_class,work_xperience2=@work_xperience2,phe_health2=@phe_health2,artedu2=@artedu2,discipline2=@discipline2,engtot=@engtot,engtot2=@engtot2,hinditot2=@hinditot2,hinditot=@hinditot,mathstot2=@mathstot2,mathstot=@mathstot,scitot2=@scitot2,scitot=@scitot,ssttot2=@ssttot2,ssttot=@ssttot,cstot2=@cstot2,cstot=@cstot,sansktot2=@sansktot2,sansktot=@sansktot,GKtot2=@GKtot2,GKtot=@GKtot,drawing2=@drawing2,games2=@games2,karate2=@karate2,dance2=@dance2,enggrndtot=@enggrndtot,hindigrndtot=@hindigrndtot,sanskgrndtot=@sanskgrndtot,mathsgrndtot=@mathsgrndtot,scigrndtot=@scigrndtot,csgrndtot=@csgrndtot,sstgrndtot=@sstgrndtot,GKgrndtot=@GKgrndtot,Grand_total=@Grand_total,Grand_Percnt=@Grand_Percnt,attndnce2=@attndnce2, Conduct =@status  where sessionss =@sessionss and rollno = @rollno and sec = @sec and class=@class", con);
        cmd.Parameters.AddWithValue("@class", txtclass.Text.ToUpper());
        cmd.Parameters.AddWithValue("@status", ddlconduct.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@sessionss", lblsession.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sec", txtsection.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rollno", txtrollno.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engPtest2", engPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engNbook2", engNbook2.Value.ToUpper());     
        cmd.Parameters.AddWithValue("@engErmnt2", engErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtheory2", engtheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engmta2", engtotal2.Value);
        cmd.Parameters.AddWithValue("@enggrndtot", enggrndtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiPtest2", hindiPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiNbook2", hindiNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiErmnt2", hindiErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditheory2", hinditheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindimta2", hinditotal2.Value);
        cmd.Parameters.AddWithValue("@hindigrndtot", hindigrndtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsPtest2", mathsPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsNbook2", mathsNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsErmnt2", mathsErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstheory2", mathstheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsmta2", mathstotal2.Value);
        cmd.Parameters.AddWithValue("@mathsgrndtot", mathgrndtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciPtest2", sciPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciNbook2", sciNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciErmnt2", sciErmnt2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@scitheory2", scitheory2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@scimta2", scitotal2.Value);
        cmd.Parameters.AddWithValue("@scigrndtot", scigrndtot.Value.ToUpper());

        
        cmd.Parameters.AddWithValue("@sstPtest2", SSTPtest2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@sstNbook2", SSTNbook2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@sstErmnt2", SSTErmnt2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@ssttheory2", SSTtheory2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@sstmta2", SSTtotal2.Value);
        cmd.Parameters.AddWithValue("@sstgrndtot", SSTgrndtot.Value.ToUpper());

        
        cmd.Parameters.AddWithValue("@csPtest2", CSPtest2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@csNbook2", CSNbook2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@csErmnt2", CSErmnt2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@cstheory2", CStheory2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@csmta2", CStotal2.Value);
        cmd.Parameters.AddWithValue("@csgrndtot", csgrndtot.Value.ToUpper());

        if (Sanskgrndtot.Value == "0")
        {
            Sanskgrndtot.Value = "";
        }

        
        cmd.Parameters.AddWithValue("@sanskPtest2", SanskPtest2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@sanskNbook2", SanskNbook2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@sanskErmnt2", SanskErmnt2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@sansktheory2", Sansktheory2.Value.ToUpper());

        
        //cmd.Parameters.AddWithValue("@sanskmta2", Sansktotal2.Value);
        cmd.Parameters.AddWithValue("@sanskgrndtot", Sanskgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@GKPtest2", GKPtest2.Value.ToUpper());
        

        cmd.Parameters.AddWithValue("@GKNbook2", GKNbook2.Value.ToUpper());
        

        cmd.Parameters.AddWithValue("@GKErmnt2", GKErmnt2.Value.ToUpper());
        

        cmd.Parameters.AddWithValue("@GKtheory2", GKtheory2.Value.ToUpper());

        
        //cmd.Parameters.AddWithValue("@Gkmta2", GKtotal2.Value);
        cmd.Parameters.AddWithValue("@GKgrndtot", gkgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@Grand_total", txtGtotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@Grand_Percnt", txtG_Percnt.Value.ToUpper());

        cmd.Parameters.AddWithValue("@attndnce1", attnd1T1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@attndnce2", attnd2.Value.ToUpper());

        cmd.Parameters.AddWithValue("@totYearly", txttotal_Yrly.Value.ToUpper());
        

        cmd.Parameters.AddWithValue("@totper_Yrly", txtpercnt_Yrly.Value.ToUpper());



        cmd.Parameters.AddWithValue("@engPtest", engPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engNbook", engNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engErmnt", engErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtheory", engtheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engmta", engtotal.Value);
        cmd.Parameters.AddWithValue("@engtot", engtotal.Value);
        
        cmd.Parameters.AddWithValue("@hindiPtest", hindiPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiNbook", hindiNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiErmnt", hindiErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditheory", hinditheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditot", hinditotal.Value);
        cmd.Parameters.AddWithValue("@hindimta", hinditotal.Value);
        
        cmd.Parameters.AddWithValue("@mathsPtest", mathsPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsNbook", mathsNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsErmnt", mathsErmnt.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstheory", mathstheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstot", mathstotal.Value);
        cmd.Parameters.AddWithValue("@mathsmta", mathstotal.Value);
        cmd.Parameters.AddWithValue("@sciPtest", sciPtest.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciNbook", sciNbook.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciErmnt", sciErmnt.Value.ToUpper());

        cmd.Parameters.AddWithValue("@scitheory", scitheory.Value.ToUpper());

        cmd.Parameters.AddWithValue("@scimta", scitotal.Value);
        cmd.Parameters.AddWithValue("@scitot", scitotal.Value);
        


        cmd.Parameters.AddWithValue("@sstPtest", SSTPtest.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sstNbook", SSTNbook.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sstErmnt", SSTErmnt.Value.ToUpper());

        cmd.Parameters.AddWithValue("@ssttheory", SSTtheory.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sstmta", SSTtotal.Value);
        cmd.Parameters.AddWithValue("@ssttot", SSTtotal.Value);


        cmd.Parameters.AddWithValue("@csPtest", CSPtest.Value.ToUpper());

        cmd.Parameters.AddWithValue("@csNbook", CSNbook.Value.ToUpper());

        cmd.Parameters.AddWithValue("@csErmnt", CSErmnt.Value.ToUpper());

        cmd.Parameters.AddWithValue("@cstheory", CStheory.Value.ToUpper());

        cmd.Parameters.AddWithValue("@csmta", CStotal.Value);

        cmd.Parameters.AddWithValue("@cstot", CStotal.Value);

        cmd.Parameters.AddWithValue("@sanskPtest", SanskPtest.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sanskNbook", SanskNbook.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sanskErmnt", SanskErmnt.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sansktheory", Sansktheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sansktot", Sansktotal.Value);


        
        cmd.Parameters.AddWithValue("@GKPtest", GKPtest.Value.ToUpper());


        cmd.Parameters.AddWithValue("@GKNbook", GKNbook.Value.ToUpper());


        cmd.Parameters.AddWithValue("@GKErmnt", GKErmnt.Value.ToUpper());


        cmd.Parameters.AddWithValue("@GKtheory", GKtheory.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKtot", GKtotal.Value.ToUpper());



        cmd.Parameters.AddWithValue("@tothalf", txttotal_Half.Value.ToUpper());


        cmd.Parameters.AddWithValue("@totper_half", txtpercnt_Half.Value.ToUpper());
        

        
        cmd.Parameters.AddWithValue("@wghthalfy2", weight2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@heighthalfy2", height2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@teachr_remrks", txttea_rmrkT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@promote_class", promoteclass.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@work_xperience2", workexp2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@phe_health2", phehealth2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@artedu2", artedu2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@discipline2", discipline2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@drawing2", drawing2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@games2", game2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@karate2", karate2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@dance2", dance2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@engtot2", engtotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditot2", hinditotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstot2", mathstotal2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@scitot2", scitotal2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@ssttot2", SSTtotal2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@cstot2", CStotal2.Value.ToUpper());

        if (Sansktotal.Value == "0")
        {
            Sansktotal.Value = "";
        }

        if (Sansktotal2.Value == "0")
        {
            Sansktotal2.Value = "";
        }
        
        cmd.Parameters.AddWithValue("@sansktot2", Sansktotal2.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@GKtot2", GKtotal2.Value.ToUpper());
        

        cmd.Parameters.AddWithValue("@Max_marks", txtMMT1.Value.ToUpper());

        con.Open();
        cmd.ExecuteNonQuery();
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Data Updated Successfuly')", true);
        try
        {
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cs.exec_qry("Delete from CLASS_III_V where id not in(select max(id) from CLASS_III_V group by name, class, sec, rollno, admissionno, fname, mname, bloodgrp, sessionss)");//Remove All Duplicates Entries From (this) Table 
                Response.Write("<script>alert('You Have Successfully Saved Marks !!!')</script>");
                Session["admsnno"] = txtadmsn.Text.ToUpper();
                Session["Term"] = DropDownList1.SelectedItem.Text.ToUpper();
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.success('Marks Saved Successfully of " + txtnam.Text.ToUpper() + "')", true);

                if (DropDownList1.Text == "Term-I")
                {
                    Response.Write("<script>");
                    Response.Write("window.open('class3 term1.aspx?sessions=" + lblsession.Text + "','_blank')");
                    Response.Write("</script>");
                    clrfld();
                }

                if (DropDownList1.Text == "Term-II")
                {

                    Response.Write("<script>");
                    Response.Write("window.open('SampleResult_III_V.aspx?sessions=" + lblsession.Text + "','_blank')");
                    Response.Write("</script>");
                    clrfld();
                }

            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Something Went Wrong.. " + ex + "')", true);
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
    protected void Button3_Click1(object sender, EventArgs e)
    {
         SqlCommand cmd = new SqlCommand(@"Insert into CLASS_III_V(name, class, sec, rollno, admissionno, fname, mname, bloodgrp,dob, address, engPtest, engPtest2, engNbook, engNbook2, engErmnt, engErmnt2, engtheory, engtheory2, engmta,engmta2,hindiPtest, hindiPtest2, hindiNbook, hindiNbook2, hindiErmnt, hindiErmnt2, hinditheory, hinditheory2,hindimta,hindimta2, mathsPtest, mathsPtest2, mathsNbook, mathsNbook2, mathsErmnt, mathsErmnt2, mathstheory, mathstheory2,mathsmta,mathsmta2, sciPtest, sciPtest2, sciNbook, sciNbook2, sciErmnt, sciErmnt2, scitheory, scitheory2,scimta,scimta2, sstPtest, sstPtest2, sstNbook, sstNbook2, sstErmnt, sstErmnt2, ssttheory, ssttheory2,sstmta,sstmta2, csPtest, csPtest2, csNbook, csNbook2, csErmnt, csErmnt2, cstheory, cstheory2,csmta,csmta2, sanskPtest, sanskPtest2, sanskNbook, sanskNbook2, sanskErmnt, sanskErmnt2, sansktheory, sansktheory2, GKPtest, GKPtest2, GKNbook, GKNbook2, GKErmnt, GKErmnt2, GKtheory, GKtheory2,  tothalf, totYearly, totper_half, totper_Yrly, Max_marks, wghthalfy, heighthalfy, wghthalfy2, heighthalfy2, teachr_remrks, promote_class, work_xperience, phe_health, artedu, work_xperience2, phe_health2, artedu2, discipline, discipline2, engtot, engtot2, hinditot, hinditot2, mathstot, mathstot2, scitot, scitot2, ssttot, ssttot2, cstot, cstot2, sansktot, sansktot2, GKtot, GKtot2, drawing, drawing2, games, games2, karate, karate2, dance, dance2,sessionss,enggrndtot,hindigrndtot,sanskgrndtot,mathsgrndtot,scigrndtot,csgrndtot,sstgrndtot,GKgrndtot,Grand_total,Grand_Percnt,attndnce1,attndnce2,conduct,student_pic) 
                  values(@name, @class, @sec, @rollno, @admissionno, @fname, @mname, @bloodgrp,@dob, @address, @engPtest, @engPtest2, @engNbook, @engNbook2, @engErmnt, @engErmnt2, @engtheory, @engtheory2,@engmta,@engmta, @hindiPtest, @hindiPtest2, @hindiNbook, @hindiNbook2, @hindiErmnt, @hindiErmnt2, @hinditheory, @hinditheory2,@hindimta,@hindimta2, @mathsPtest, @mathsPtest2, @mathsNbook, @mathsNbook2, @mathsErmnt, @mathsErmnt2, @mathstheory, @mathstheory2,@mathsmta,@mathsmta2, @sciPtest, @sciPtest2, @sciNbook, @sciNbook2, @sciErmnt, @sciErmnt2, @scitheory, @scitheory2, @scimta,@scimta2,@sstPtest, @sstPtest2, @sstNbook, @sstNbook2, @sstErmnt, @sstErmnt2, @ssttheory, @ssttheory2,@sstmta,@sstmta2, @csPtest, @csPtest2, @csNbook, @csNbook2, @csErmnt, @csErmnt2, @cstheory, @cstheory2,@csmta,@csmta2, @sanskPtest, @sanskPtest2, @sanskNbook, @sanskNbook2, @sanskErmnt, @sanskErmnt2, @sansktheory, @sansktheory2, @GKPtest, @GKPtest2, @GKNbook, @GKNbook2, @GKErmnt, @GKErmnt2, @GKtheory, @GKtheory2, @tothalf, @totYearly, @totper_half, @totper_Yrly, @Max_marks, @wghthalfy, @heighthalfy, @wghthalfy2, @heighthalfy2, @teachr_remrks, @promote_class, @work_xperience, @phe_health, @artedu, @work_xperience2, @phe_health2, @artedu2, @discipline, @discipline2, @engtot, @engtot2, @hinditot, @hinditot2, @mathstot, @mathstot2, @scitot, @scitot2, @ssttot, @ssttot2, @cstot, @cstot2, @sansktot, @sansktot2, @GKtot, @GKtot2, @drawing, @drawing2, @games, @games2, @karate, @karate2, @dance, @dance2,@sessionss,@enggrndtot,@hindigrndtot,@sanskgrndtot,@mathsgrndtot,@scigrndtot,@csgrndtot,@sstgrndtot,@GKgrndtot,@Grand_total,@Grand_Percnt,@attndnce1,@attndnce2, @conduct,@student_pic)", cs.connect());

        //cmd = new SqlCommand("Save_reportcard", cs.Connect());
        //cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@name", txtnam.Text.ToUpper());
        cmd.Parameters.AddWithValue("@class", txtclass.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sec", txtsection.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rollno", txtrollno.Text.ToUpper());
        cmd.Parameters.AddWithValue("@admissionno", txtadmsn.Text.ToUpper());
        cmd.Parameters.AddWithValue("@fname", txtfather.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mname", txtmother.Text.ToUpper());
        cmd.Parameters.AddWithValue("@bloodgrp", txtbloodgrp.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dob", txtdob.Text.ToUpper());
        cmd.Parameters.AddWithValue("@student_pic", txtstupic.Text);
        cmd.Parameters.AddWithValue("@address", txtaddrs.Text.ToUpper());

        cmd.Parameters.AddWithValue("@engPtest", engPtestT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engPtest2", engPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engNbook", engNbookT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engNbook2", engNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engErmnt", engErmntT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engErmnt2", engErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtheory", engtheoryT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtheory2", engtheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engmta", engtotalT1.Value);
        cmd.Parameters.AddWithValue("@engmta2", engtotal2.Value);
        cmd.Parameters.AddWithValue("@enggrndtot", enggrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@hindiPtest", hindiPtestT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiPtest2", hindiPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiNbook", hindiNbookT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiNbook2", hindiNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiErmnt", hindiErmntT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiErmnt2", hindiErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditheory", hinditheoryT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditheory2", hinditheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindimta", hinditotalT1.Value);
        cmd.Parameters.AddWithValue("@hindimta2", hinditotal2.Value);
        cmd.Parameters.AddWithValue("@hindigrndtot", hindigrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@mathsPtest", mathsPtestT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsPtest2", mathsPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsNbook", mathsNbookT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsNbook2", mathsNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsErmnt", mathsErmntT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsErmnt2", mathsErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstheory", mathstheoryT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstheory2", mathstheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathsmta", mathstotalT1.Value);
        cmd.Parameters.AddWithValue("@mathsmta2", mathstotal2.Value);
        cmd.Parameters.AddWithValue("@mathsgrndtot", mathgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sciPtest", sciPtestT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciPtest2", sciPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciNbook", sciNbookT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciNbook2", sciNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciErmnt", sciErmntT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sciErmnt2", sciErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scitheory", scitheoryT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scitheory2", scitheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scimta", scitotalT1.Value);
        cmd.Parameters.AddWithValue("@scimta2", scitotal2.Value);
        cmd.Parameters.AddWithValue("@scigrndtot", scigrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@sstPtest", SSTPtestT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstPtest2", SSTPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstNbook", SSTNbookT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstNbook2", SSTNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstErmnt", SSTErmntT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstErmnt2", SSTErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@ssttheory", SSTtheoryT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@ssttheory2", SSTtheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sstmta", SSTtotalT1.Value);
        cmd.Parameters.AddWithValue("@sstmta2", SSTtotal2.Value);
        cmd.Parameters.AddWithValue("@sstgrndtot", SSTgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@csPtest", CSPtestT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csPtest2", CSPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csNbook", CSNbookT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csNbook2", CSNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csErmnt", CSErmntT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csErmnt2", CSErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cstheory", CStheoryT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cstheory2", CStheory2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csmta", CStotalT1.Value);
        cmd.Parameters.AddWithValue("@csmta2", CStotal2.Value);
        cmd.Parameters.AddWithValue("@csgrndtot", csgrndtot.Value.ToUpper());

        if (Sanskgrndtot.Value == "0")
        {
            Sanskgrndtot.Value = "";
        }

        cmd.Parameters.AddWithValue("@sanskPtest", SanskPtestT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskPtest2", SanskPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskNbook", SanskNbookT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskNbook2", SanskNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskErmnt", SanskErmntT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sanskErmnt2", SanskErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sansktheory", SansktheoryT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sansktheory2", Sansktheory2.Value.ToUpper());

        //cmd.Parameters.AddWithValue("@sanskmta", SansktotalT1.Value);
        //cmd.Parameters.AddWithValue("@sanskmta2", Sansktotal2.Value);
        cmd.Parameters.AddWithValue("@sanskgrndtot", Sanskgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@GKPtest", GKPtestT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKPtest2", GKPtest2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKNbook", GKNbookT1.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@GKNbook2", GKNbook2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKErmnt", GKErmntT1.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@GKErmnt2", GKErmnt2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKtheory", GKtheoryT1.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@GKtheory2", GKtheory2.Value.ToUpper());

        //cmd.Parameters.AddWithValue("@GKmta", GKtotalT1.Value);
        //cmd.Parameters.AddWithValue("@Gkmta2", GKtotal2.Value);
        cmd.Parameters.AddWithValue("@GKgrndtot", gkgrndtot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@Grand_total", txtGtotal.Value.ToUpper());
        cmd.Parameters.AddWithValue("@Grand_Percnt", txtG_Percnt.Value.ToUpper());

        cmd.Parameters.AddWithValue("@attndnce1", attnd1T1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@attndnce2", attnd2.Value.ToUpper());

        cmd.Parameters.AddWithValue("@tothalf", txttotal_HalfT1.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@totYearly", txttotal_Yrly.Value.ToUpper());
        cmd.Parameters.AddWithValue("@totper_half", txtpercnt_HalfT1.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@totper_Yrly", txtpercnt_Yrly.Value.ToUpper());
        cmd.Parameters.AddWithValue("@wghthalfy", weightT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@heighthalfy", heightT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@wghthalfy2", weight2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@heighthalfy2", height2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@teachr_remrks", txttea_rmrkT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@promote_class", promoteclass.Value.ToUpper());
        cmd.Parameters.AddWithValue("@work_xperience", workexpT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@work_xperience2", workexp2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@phe_health", phehealthT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@phe_health2", phehealth2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@artedu", arteduT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@artedu2", artedu2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@discipline", disciplineT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@discipline2", discipline2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@drawing", drawingT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@drawing2", drawing2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@games", gameT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@games2", game2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@karate", karateT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@karate2", karate2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@dance", danceT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@dance2", dance2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtot", engtotalT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engtot2", engtotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditot", hinditotalT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hinditot2", hinditotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstot", mathstotalT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathstot2", mathstotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scitot", scitotalT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@scitot2", scitotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@ssttot", SSTtotalT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@ssttot2", SSTtotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cstot", CStotalT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cstot2", CStotal2.Value.ToUpper());

        if (Sansktotal.Value == "0")
        {
            Sansktotal.Value = "";
        }

        if (Sansktotal2.Value == "0")
        {
            Sansktotal2.Value = "";
        }
        cmd.Parameters.AddWithValue("@sansktot", SansktotalT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sansktot2", Sansktotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKtot", GKtotalT1.Value.ToUpper());
        cmd.Parameters.AddWithValue("@GKtot2", GKtotal2.Value.ToUpper());
        cmd.Parameters.AddWithValue("@sessionss", lblsession.Text.ToUpper());
        cmd.Parameters.AddWithValue("@conduct", ddlconduct.SelectedItem.Text.ToUpper());

        
            cmd.Parameters.AddWithValue("@Max_marks", txtMMT1.Value.ToUpper());
        


        cmd.ExecuteNonQuery();
        try
        {
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cs.exec_qry("Delete from CLASS_III_V where id not in(select max(id) from CLASS_III_V group by name, class, sec, rollno, admissionno, fname, mname, bloodgrp, sessionss)");//Remove All Duplicates Entries From (this) Table 
                Response.Write("<script>alert('You Have Sucessfully Saved Marks !!! ')</script>");
                Session["admsnno"] = txtadmsn.Text.ToUpper();
                Session["Term"] = DropDownList1.SelectedItem.Text.ToUpper();
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.success('Marks Saved Successfully of " + txtnam.Text.ToUpper() + "')", true);


                if (DropDownList1.Text == "Term-I")
                {


                    Response.Write("<script>");
                    Response.Write("window.open('class-3 term1.aspx?sessions=" + lblsession.Text + "','_blank')");
                    Response.Write("</script>");
                    clrfld();
                }


                if (DropDownList1.Text == "Term-II")
                {
                     Response.Write("<script>");
                    Response.Write("window.open('sampleresult_III_V.aspx?sessions=" + lblsession.Text + "','_blank')");
                    Response.Write("</script>");
                    clrfld();
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Data Inserted Successfuly')", true);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Something Went Wrong.. " + ex + "')", true);
        }
        clrfld();
    }
    protected void TextBox11_TextChanged(object sender, EventArgs e)
    {

    }
}