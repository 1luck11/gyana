﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_left_student : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            getdata();
        }

    }
    protected void grd_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        grd.PageIndex = e.NewPageIndex;
        bd.bind_grid(grd, "select * from tb_leftstudent order by 1 desc");


    }
 
    public void getdata()
    {
        bd.bind_grid(grd, "select * from tb_leftstudent order by 1 desc");
        bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");


    }

    protected void search_Click(object sender, EventArgs e)
    {

        //Response.Write("<script>alert('" + ddlsession.SelectedItem.Text + "')</script>");
        //bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
        bd.bind_grid(grd, "select * from tb_leftstudent where Session='" + ddlsession.SelectedItem.Text + "' AND (Student_name LIKE '%" + TextBox1.Text + "%'  OR Section LIKE '%" + TextBox1.Text + "%' OR Class LIKE'%" + TextBox1.Text + "%' OR Rollno LIKE'%" + TextBox1.Text + "%' )");


    }
}