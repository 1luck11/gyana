﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_SearchStudent : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
         
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


            bd.bind_dropdown(DropDownList1, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");

            bd.bind_dropdown(DropDownList2, "select * from tbl_class  order by class_value asc", "class_nm", "class_value");


            bd.bind_dropdown(DropDownList3, "select * from tbl_section order by section_value asc", "section_nm", "id");
          
            getdata();
        }

    }
    protected void grd_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        grd.PageIndex = e.NewPageIndex;
        if (DropDownList1.SelectedItem.Text != "Select" && DropDownList2.SelectedItem.Text != "Select" && DropDownList3.SelectedItem.Text != "Select")
            bd.bind_grid(grd, "select * from tbl_sturegister where sesnm='" + DropDownList1.SelectedItem.Text + "' AND class_nm='" + DropDownList2.SelectedItem.Text + "' AND section='" + DropDownList3.SelectedItem.Text + "'");
        else
        {

            bd.bind_grid(grd, "select * from tbl_sturegister");
        }
        


    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "edit")
        {

            SqlCommand cmd = new SqlCommand("select * from tbl_sturegister where id='" + e.CommandArgument + "'", cs.connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                //    //Label1.Visible = false;
                //    // Label7.Visible = false;
                //    stupic.Visible = false;
                //    txtadmsn.ReadOnly = true;
                //    //txtdob.Visible = false;
                //    txtnam.Text = dt.Rows[0]["fullname"].ToString();
                //    ddlsession.SelectedItem.Text = dt.Rows[0]["sesnm"].ToString();
                //    ddlclass.SelectedItem.Text = dt.Rows[0]["class_nm"].ToString();
                //    ddlsection.SelectedItem.Text = dt.Rows[0]["section"].ToString();
                //    txtfather.Text = dt.Rows[0]["fname"].ToString();
                //    txtmother.Text = dt.Rows[0]["mname"].ToString();
                //    txtdob.Text = ((DateTime)dt.Rows[0]["dob"]).ToString("dd/MM/yyyy");
                //    txtrollno.Text = dt.Rows[0]["rollno"].ToString();
                //    txtbloodgrp.Text = dt.Rows[0]["bloodgrp"].ToString();
                //    txtmob.Text = dt.Rows[0]["smobile"].ToString();
                //    txtdob.Text = dt.Rows[0]["dob"].ToString();
                //    txtadmsn.Text = dt.Rows[0]["admissionno"].ToString();

                //    //txtadhar.Text = dt.Rows[0]["adharno"].ToString();
                //    txtaddrs.Text = dt.Rows[0]["addrss"].ToString();

                //}
                //ViewState["eid"] = e.CommandArgument;
                //bd.bind_grid(grd, "select * from tbl_sturegister");
                //Button5.Text = "Update";
            }

        }
        else if (e.CommandName == "delete")
        {
            cs.exec_qry("delete from tbl_sturegister where id='" + e.CommandArgument + "'");

            bd.bind_grid(grd, "select * from tbl_sturegister");

        }
        else
        {





        }
    }
    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //  bd.bind_grid(grd, "select * from tbl_sturegister");
    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    public void getdata()
    {
        bd.bind_grid(grd, "select * from tbl_sturegister");
        

        
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
       
        if (DropDownList1.SelectedItem.Text != "Select" && DropDownList2.SelectedItem.Text!="Select"&& DropDownList3.SelectedItem.Text != "Select")
            bd.bind_grid(grd, "select * from tbl_sturegister where sesnm='" + DropDownList1.SelectedItem.Text + "' AND class_nm='" + DropDownList2.SelectedItem.Text + "' AND section='" + DropDownList3.SelectedItem.Text + "'");
        else
        {
            
            Response.Write("<script>alert('Please Select All The Fields')</script>");
        }



        //if (DropDownList1.SelectedItem.Text == "Select" && DropDownList2.SelectedItem.Text == "Select" && DropDownList3.SelectedItem.Text == "Select")
        //bd.bind_grid(GridView1, "select * from CLASS_PNC_KG ,CLASS_I_II , CLASS_III_V ");
        //bd.bind_grid(GridView1, "select (select * from CLASS_PNC_KG where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct='" + DropDownList4.SelectedItem.Text + "'),(select * from CLASS_I_II where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct='" + DropDownList4.SelectedItem.Text + "'),(select * from CLASS_III_V where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct='" + DropDownList4.SelectedItem.Text + "')");

    }
}