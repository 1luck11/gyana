﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_chnagepwd : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    protected void Page_Load(object sender, EventArgs e)
    {
         
    }
   
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        SqlCommand com = new SqlCommand("select * from tbl_adminlogin where paswrd = '" + TextBox1.Text + "' and userid = 'admin'", cs.connect());
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            //Response.Write("<script>alert('U Can Insert New Password !!!')</script>");
            TextBox2.Visible = true;
            TextBox4.Visible = true;
            Label3.Visible = true;
            Label4.Visible = true;
            Button5.Visible = true;
            Label11.Visible = true;
            Label12.Visible = true;
        

        }
        else
        {

            Response.Write("<script>alert('You Have Entered Wrong Old Password!!!')</script>");
            Response.Write("<script>window.open('welcomeAdminpage.aspx','_parent')</script>");
            TextBox2.Visible = false;
            TextBox4.Visible = false;
            Label3.Visible = false;
            Label4.Visible = false;

            Button5.Visible = false;
            Label11.Visible = false;
            Label12.Visible = false;
        }
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text == TextBox4.Text)
        {

            cs.exec_qry("update tbl_adminlogin set paswrd = '" + TextBox2.Text + "' where userid = 'admin' and paswrd='" + TextBox1.Text + "'");

            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            //lblmsg.Text = "";
            Response.Write("<script>alert('You Have Successfully Changed Your Password !!!')</script>");

        }
        else
        {

            Response.Write("<script>alert('New Password And Confirm Password Does Not Match!!!')</script>");

        }

    }
}