﻿
Partial Class login1_prenursery2
    Inherits System.Web.UI.Page

End Class
