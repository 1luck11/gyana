﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class PreNursery : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt = new DataTable();
    SqlCommand cmd = new SqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            lblsession.Text = Request.QueryString["session"].ToString();
            if (!IsPostBack)
            {

                txtClass.Text = Session["classs"].ToString();
                txtSection.Text = Session["Sec"].ToString();

            }
        }
        catch (Exception ae)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alert('" + ae.Message + "',this.open('../index.aspx'))", true);
        }
    }
//    public string Save_Rpt_card()
//    {
//        return "";
//    }
    protected void clrfld()
    {
//        txtnam.Text = "";
//        txtfather.Text = "";
//        txtmother.Text = "";
//        txtaddrs.Text = "";
//        txtadmsn.Text = "";
//        txtrollno.Text = "";
//        //txtsection.Text = dr["sec"].ToString();
//        //txtclass.Text = dr["class"].ToString();
//        txtbloodgrp.Text = "";
//        txtdob.Text = "";

//        engread1.Text = "";
//        engread2.Text = "";
//        engrecit1.Text = "";
//        engrecit2.Text = "";
//        engcomp1.Text = "";
//        engcomp2.Text = "";
//        engexp1.Text = "";
//        engexp2.Text = "";
//        engrcz1.Text = "";
//        engrcz2.Text = "";
//        engprwrt1.Text = "";
//        engprwrt2.Text = "";
//        engcrtfmt1.Text = "";
//        engcrtfmt2.Text = "";
//        engrldex1.Text = "";
//        engrldex2.Text = "";

//        hinread1.Text = "";
//        hinread2.Text = "";
//        hinrecit1.Text = "";
//        hinrecit2.Text = "";
//        hincrtfmt1.Text = "";
//        hincrtfmt2.Text = "";
//        hinex1.Text = "";
//        hinex2.Text = "";


//        mathcount1.Text = "";
//        mathcount2.Text = "";
//        mathrcz1.Text = "";
//        mathrcz2.Text = "";
//        mathval1.Text = "";
//        mathval2.Text = "";
//        mathprno1.Text = "";
//        mathprno2.Text = "";
//        mathcrtfmt1.Text = "";
//        mathcrtfmt2.Text = "";
//        mathex1.Text = "";
//        mathex2.Text = "";


//        gkrcz1.Text = "";
//        gkrcz2.Text = "";
//        gkans1.Text = "";
//        gkans2.Text = "";
//        drawdw1.Text = "";
//        drawdw2.Text = "";
//        drawclr1.Text = "";
//        drawclr2.Text = "";
//        drawcrf1.Text = "";
//        drawcrf2.Text = "";


//        foloinst1.Text = "";
//        foloinst2.Text = "";
//        obsrt1.Text = "";
//        obsrt2.Text = "";
//        behav1.Text = "";
//        behav2.Text = "";
//        creatvy1.Text = "";
//        creatvy2.Text = "";
//        neat1.Text = "";
//        neat2.Text = "";
//        confdnc1.Text = "";
//        confdnc2.Text = "";
//        apptsng1.Text = "";
//        apptsng2.Text = "";
//        apptdnc1.Text = "";
//        attnd1.Text = "";
//        attnd2.Text = "";

//        apptdnc2.Text = "";
//        apptphycl1.Text = "";
//        apptphycl2.Text = "";
//        guidcon1.Text = "";
//        guidcon2.Text = "";
//        vocab1.Text = "";
//        vocab2.Text = "";
//        allrund1.Text = "";
//        allrund2.Text = "";

//        remak.Text = "";
//        attnd1.Text = "";
//        attnd2.Text = "";
//        wt1.Text = "";
//        wt2.Text = "";
//        hyt1.Text = "";
//        hyt2.Text = "";
//        //lblsession.Text = dr["sessionss"].ToString();
//        ddlconduct.SelectedIndex= -1;
//        promoteclass.Value = "";
           
       
//        //lblsession.Text = "";
//        ddlconduct.SelectedIndex = -1;
//    }
  
//    protected void btn_save_click(object sender, EventArgs e)
//    {
//        if (dropDown.Text=="Select")
//        {
//            Response.Write("<script>alert('Please Select The Term !!!')</script>");
//                return;
//        }

//        SqlCommand cmd = new SqlCommand(@"Insert into CLASS_PNC_KG(name, class, sec, rollno, admissionno, fname, mname, bloodgrp, address, engread1, engread2, engrecit1, engrecit2, engcomp1, engcomp2, engexp1, engexp2, engrcz1, engrcz2, engprwt1,engprwt2, engcrtfmt1,engcrtfmt2, engrldex1,engrldex2, hindiread1, hindiread2, hindirecit1, hindirecit2, hindicrtfmt1, hindicrtfmt2, hindiex1, hindiex2, mathcount1, mathcount2, mathrcz1, mathrcz2, mathval1, mathval2, mathprno1, mathprno2,mathcrtfmt1, mathcrtfmt2,mathex1, mathex2, gkrcz1, gkrcz2, gkans1 , gkans2,drawdr1,drawdr2,drawclr1,drawclr2,drawcrf1,drawcrf2, wt1, wt2, hyt1,hyt2,foloinst1,foloinst2,obsrvt1,obsrvt2,behav1,behav2,creatvy1,creatvy2,neat1,neat2,confdc1,confdc2,apptsng1,apptsng2,apptdnc1,apptdnc2,apptphycl1,apptphycl2,guidcon1,guidcon2,vocab1 ,vocab2,allround1,allround2, sessionss,conduct,promoteclass,dob,student_pic,tearemrk,attndnce1,attndnce2) 
//                  values(@name, @class, @sec, @rollno, @admissionno, @fname, @mname, @bloodgrp, @address, @engread1, @engread2, @engrecit1, @engrecit2, @engcomp1, @engcomp2, @engexp1, @engexp2, @engrcz1, @engrcz2, @engprwt1,@engprwt2, @engcrtfmt1,@engcrtfmt2, @engrldex1,@engrldex2,@hindiread1, @hindiread2, @hindirecit1, @hindirecit2, @hindicrtfmt1, @hindicrtfmt2, @hindiex1, @hindiex2, @mathcount1, @mathcount2, @mathrcz1, @mathrcz2, @mathval1, @mathval2, @mathprno1, @mathprno2,@mathcrtfmt1, @mathcrtfmt2,@mathex1, @mathex2, @gkrcz1, @gkrcz2, @gkans1 , @gkans2,@drawdr1,@drawdr2,@drawclr1,@drawclr2,@drawcrf1,@drawcrf2, @wt1, @wt2, @hyt1,@hyt2,@foloinst1,@foloinst2,@obsrvt1,@obsrvt2,@behav1,@behav2,@creatvy1,@creatvy2,@neat1,@neat2,@confdc1,@confdc2,@apptsng1,@apptsng2,@apptdnc1,@apptdnc2,@apptphycl1,@apptphycl2,@guidcon1,@guidcon2,@vocab1 ,@vocab2,@allround1,@allround2,@sessionss,@conduct,@promoteclass,@dob,@student_pic,@tearemrk,@attndnce1,@attndnce2)", cs.connect());

//        //cmd = new SqlCommand("Save_reportcard", cs.Connect());
//        //cmd.CommandType = CommandType.StoredProcedure;        

//        cmd.Parameters.AddWithValue("@name", txtnam.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@class", txtclass.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@sec", txtsection.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@rollno", txtrollno.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@admissionno", txtadmsn.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@fname", txtfather.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mname", txtmother.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@bloodgrp", txtbloodgrp.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@dob", txtdob.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@student_pic", txtstupic.Text);
//        cmd.Parameters.AddWithValue("@address", txtaddrs.Text.ToUpper());        
//        cmd.Parameters.AddWithValue("@engread1", engreadT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engread2", engread2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engrecit1", engrecitT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engrecit2", engrecit2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engcomp1", engcompT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engcomp2", engcomp2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engexp1", engexpT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engexp2", engexp2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engrcz1", engrczT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engrcz2", engrcz2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engprwt1", engprwrtT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engprwt2", engprwrt2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engcrtfmt1", engcrtfmtT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engcrtfmt2", engcrtfmt2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engrldex1", engrldexT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@engrldex2", engrldex2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hindiread1", hinreadT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hindiread2", hinread2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hindirecit1", hinrecitT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hindirecit2", hinrecit2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hindicrtfmt1", hincrtfmtT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hindicrtfmt2", hincrtfmt2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hindiex1", hinexT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hindiex2", hinex2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathcount1", mathcountT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathcount2", mathcount2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathrcz1", mathrczT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathrcz2", mathrcz2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathval1", mathvalT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathval2", mathval2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathprno1", mathprnoT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathprno2", mathprno2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathcrtfmt1", mathcrtfmtT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathcrtfmt2", mathcrtfmt2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathex1", mathexT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@mathex2", mathex2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@gkrcz1", gkrczT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@gkrcz2", gkrcz2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@gkans1", gkansT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@gkans2", gkans2.Text.ToUpper());        
//        cmd.Parameters.AddWithValue("@drawdr1", drawdwT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@drawdr2", drawdw2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@drawclr1", drawclrT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@drawclr2", drawclr2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@drawcrf1", drawcrfT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@drawcrf2", drawcrf2.Text.ToUpper());      
//        cmd.Parameters.AddWithValue("@foloinst1", foloinstT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@foloinst2", foloinst2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@obsrvt1", obsrtT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@obsrvt2", obsrt2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@behav1", behavT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@behav2", behav2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@creatvy1", creatvyT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@creatvy2", creatvy2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@neat1", neatT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@neat2", neat2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@confdc1", confdncT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@confdc2", confdnc2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@apptsng1", apptsngT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@apptsng2", apptsng2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@apptdnc1", apptdncT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@apptdnc2", apptdnc2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@apptphycl1", apptphyclT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@apptphycl2", apptphycl2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@guidcon1", guidconT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@guidcon2", guidcon2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@vocab1", vocabT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@vocab2", vocab2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@allround1", allrundT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@allround2", allrund2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@attndnce1", attndT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@attndnce2", attnd2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@wt1", wtT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@wt2", wt2.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hyt1", hytT1.Text.ToUpper());
//        cmd.Parameters.AddWithValue("@hyt2", hyt2.Text.ToUpper());

//        if (dropDown.Text == "Term-I")
//        {
//            cmd.Parameters.AddWithValue("@tearemrk", remakT1.Text.ToUpper());
//            cmd.Parameters.AddWithValue("@conduct", ddlconductT1.SelectedItem.Text.ToUpper());            
//        }


//        if (dropDown.Text == "Term-II")
//        {
//            cmd.Parameters.AddWithValue("@tearemrk", remak.Text.ToUpper());
//            cmd.Parameters.AddWithValue("@conduct", ddlconduct.SelectedItem.Text.ToUpper());
//        }
        


//        cmd.Parameters.AddWithValue("@sessionss", lblsession.Text);      

//        cmd.Parameters.AddWithValue("@promoteclass", promoteclass.Value.ToUpper());

//        cmd.ExecuteNonQuery();

//        //Response.Write("<script>alert('You Have Successfully Saved Marks !!!')</script>");
               


//        try
//        {
//            int i = cmd.ExecuteNonQuery();
//            if (i > 0)
//            {
//                cs.exec_qry("Delete from CLASS_PNC_KG where id not in(select max(id) from CLASS_PNC_KG group by name, class, sec, rollno, admissionno, fname, mname, bloodgrp, sessionss)");//Remove All Duplicates Entries From (this) Table 
//               // Response.Write("<script>alert('You Have Successfully Saved Marks !!!')</script>");
//                Session["admsnno"] = txtadmsn.Text.ToUpper();
//                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.success('Marks Saved Successfully of " + txtnam.Text.ToUpper() + "')", true);

//                if (dropDown.Text == "Term-I")
//                {
//                    Response.Write("<script>");
//                    Response.Write("window.open('Classprencterm1.aspx?sessions=" + lblsession.Text + "','_blank')");
//                    Response.Write("</script>");
//                    clrfld();
//                }

//                if (dropDown.Text == "Term-II")
//                {
//                    Response.Write("<script>");
//                    Response.Write("window.open('sampleresult_PreNursery.aspx?sessions=" + lblsession.Text + "','_blank')");
//                    Response.Write("</script>");
//                    clrfld();
//                }

                
               
//            }
//            else
//            {

//            }
//        }
//        catch (Exception ex)
//        {
//            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Something Went Wrong.. " + ex + "')", true);
//        }
//        clrfld();
//    }

    protected void txt_rno_TextChanged(object sender, EventArgs e)
    {

        bool temp = false;
        string connStr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        con.Open();
        SqlCommand cmd = new SqlCommand("select * from CLASS_PNC_KG where rollno='" + txtRoll.Text.Trim() + "' and class='" + txtClass.Text + "'and sec='" + txtSection.Text + "' and sessionss='"+lblsession.Text+"'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            txtName.Text = dr["name"].ToString();
            txtFather.Text = dr["fname"].ToString();
            txtMother.Text = dr["mname"].ToString();
            txtAddress.Text = dr["address"].ToString();
            txtAdNo.Text = dr["admissionno"].ToString();
            txtSection.Text = dr["sec"].ToString();
            txtClass.Text = dr["class"].ToString();
            txtBlood.Text = dr["bloodgrp"].ToString();
            txtDob.Text = dr["dob"].ToString();
            txtstupic.Text = dr["student_pic"].ToString();
//            engreadT1.Text = dr["engread1"].ToString();
//            engread1.Text = dr["engread1"].ToString();
//            engread2.Text = dr["engread2"].ToString();
//            engrecitT1.Text = dr["engrecit1"].ToString();
//            engrecit1.Text = dr["engrecit1"].ToString();
//            engrecit2.Text = dr["engrecit2"].ToString();
//            engcompT1.Text = dr["engcomp1"].ToString();
//            engcomp1.Text = dr["engcomp1"].ToString();
//            engcomp2.Text = dr["engcomp2"].ToString();
//            engexpT1.Text = dr["engexp1"].ToString();
//            engexp1.Text = dr["engexp1"].ToString();
//            engexp2.Text = dr["engexp2"].ToString();
//            engrczT1.Text = dr["engrcz1"].ToString();
//            engrcz1.Text = dr["engrcz1"].ToString();
//            engrcz2.Text = dr["engrcz2"].ToString();
//            engprwrtT1.Text = dr["engprwt1"].ToString();
//            engprwrt1.Text = dr["engprwt1"].ToString();
//            engprwrt2.Text = dr["engprwt2"].ToString();
//            engcrtfmtT1.Text = dr["engcrtfmt1"].ToString();
//            engcrtfmt1.Text = dr["engcrtfmt1"].ToString();
//            engcrtfmt2.Text = dr["engcrtfmt2"].ToString();
//            engrldexT1.Text = dr["engrldex1"].ToString();
//            engrldex1.Text = dr["engrldex1"].ToString();
//            engrldex2.Text = dr["engrldex2"].ToString();
//            hinreadT1.Text = dr["hindiread1"].ToString();
//            hinread1.Text = dr["hindiread1"].ToString();
//            hinread2.Text = dr["hindiread2"].ToString();
//            hinrecitT1.Text = dr["hindirecit1"].ToString();
//            hinrecit1.Text = dr["hindirecit1"].ToString();
//            hinrecit2.Text = dr["hindirecit2"].ToString();
//            hincrtfmtT1.Text = dr["hindicrtfmt1"].ToString();
//            hincrtfmt1.Text = dr["hindicrtfmt1"].ToString();
//            hincrtfmt2.Text = dr["hindicrtfmt2"].ToString();
//            hinexT1.Text = dr["hindiex1"].ToString();
//            hinex1.Text = dr["hindiex1"].ToString();
//            hinex2.Text = dr["hindiex2"].ToString();
//            mathcountT1.Text = dr["mathcount1"].ToString();
//            mathcount1.Text = dr["mathcount1"].ToString();
//            mathcount2.Text = dr["mathcount2"].ToString();
//            mathrczT1.Text = dr["mathrcz1"].ToString();
//            mathrcz1.Text = dr["mathrcz1"].ToString();
//            mathrcz2.Text = dr["mathrcz2"].ToString();
//            mathvalT1.Text = dr["mathval1"].ToString();
//            mathval1.Text = dr["mathval1"].ToString();
//            mathval2.Text = dr["mathval2"].ToString();
//            mathprnoT1.Text = dr["mathprno1"].ToString();
//            mathprno1.Text = dr["mathprno1"].ToString();
//            mathprno2.Text = dr["mathprno2"].ToString();
//            mathcrtfmtT1.Text = dr["mathcrtfmt1"].ToString();
//            mathcrtfmt1.Text = dr["mathcrtfmt1"].ToString();
//            mathcrtfmt2.Text = dr["mathcrtfmt2"].ToString();
//            mathexT1.Text = dr["mathex1"].ToString();
//            mathex1.Text = dr["mathex1"].ToString();
//            mathex2.Text = dr["mathex2"].ToString();
//            gkrczT1.Text = dr["gkrcz1"].ToString();
//            gkrcz1.Text = dr["gkrcz1"].ToString();
//            gkrcz2.Text = dr["gkrcz2"].ToString();
//            gkansT1.Text = dr["gkans1"].ToString();
//            gkans1.Text = dr["gkans1"].ToString();
//            gkans2.Text = dr["gkans2"].ToString();
//            drawdwT1.Text = dr["drawdr1"].ToString();
//            drawdw1.Text = dr["drawdr1"].ToString();
//            drawdw2.Text = dr["drawdr2"].ToString();
//            drawclrT1.Text = dr["drawclr1"].ToString();
//            drawclr1.Text = dr["drawclr1"].ToString();
//            drawclr2.Text = dr["drawclr2"].ToString();
//            drawcrfT1.Text = dr["drawcrf1"].ToString();
//            drawcrf1.Text = dr["drawcrf1"].ToString();
//            drawcrf2.Text = dr["drawcrf2"].ToString();
//            foloinstT1.Text = dr["foloinst1"].ToString();
//            foloinst1.Text = dr["foloinst1"].ToString();
//            foloinst2.Text = dr["foloinst2"].ToString();
//            obsrtT1.Text = dr["obsrvt1"].ToString();
//            obsrt1.Text = dr["obsrvt1"].ToString();
//            obsrt2.Text = dr["obsrvt2"].ToString();
//            behavT1.Text = dr["behav1"].ToString();
//            behav1.Text = dr["behav1"].ToString();
//            behav2.Text = dr["behav2"].ToString();
//            creatvyT1.Text = dr["creatvy1"].ToString();
//            creatvy1.Text = dr["creatvy1"].ToString();
//            creatvy2.Text = dr["creatvy2"].ToString();
//            neatT1.Text = dr["neat1"].ToString();
//            neat1.Text = dr["neat1"].ToString();
//            neat2.Text = dr["neat2"].ToString();
//            confdncT1.Text = dr["confdc1"].ToString();
//            confdnc1.Text = dr["confdc1"].ToString();
//            confdnc2.Text = dr["confdc2"].ToString();
//            apptsngT1.Text = dr["apptsng1"].ToString();
//            apptsng1.Text = dr["apptsng1"].ToString();
//            apptsng2.Text = dr["apptsng2"].ToString();
//            apptdncT1.Text = dr["apptdnc1"].ToString();
//            apptdnc1.Text = dr["apptdnc1"].ToString();           
//            apptdnc2.Text = dr["apptdnc2"].ToString();
//            attndT1.Text = dr["attndnce1"].ToString();
//            attnd1.Text = dr["attndnce1"].ToString();
//            attnd2.Text = dr["attndnce2"].ToString();
//            apptphyclT1.Text = dr["apptphycl1"].ToString();
//            apptphycl1.Text = dr["apptphycl1"].ToString();
//            apptphycl2.Text = dr["apptphycl2"].ToString();
//            guidconT1.Text = dr["guidcon1"].ToString();
//            guidcon1.Text = dr["guidcon1"].ToString();
//            guidcon2.Text = dr["guidcon2"].ToString();
//            vocabT1.Text = dr["vocab1"].ToString();
//            vocab1.Text = dr["vocab1"].ToString();
//            vocab2.Text = dr["vocab2"].ToString();
//            allrundT1.Text = dr["allround1"].ToString();
//            allrund1.Text = dr["allround1"].ToString();
//            allrund2.Text = dr["allround2"].ToString();
//            remakT1.Text = dr["tearemrk"].ToString();
//            remak.Text = dr["tearemrk"].ToString();           
//            attnd1.Text = dr["attndnce1"].ToString();
//            attnd2.Text = dr["attndnce2"].ToString();
//            wtT1.Text = dr["wt1"].ToString();
//            wt1.Text = dr["wt1"].ToString();
//            wt2.Text = dr["wt2"].ToString();
//            hytT1.Text = dr["hyt1"].ToString();
//            hyt1.Text = dr["hyt1"].ToString();
//            hyt2.Text = dr["hyt2"].ToString();
            
//            ddlconduct.SelectedItem.Text = dr["conduct"].ToString();
//            ddlconductT1.SelectedItem.Text = dr["conduct"].ToString();
//             promoteclass.Value = dr["promoteclass"].ToString();
           
//            temp = true;
//        }
        if (temp == false)
        {
            string connStr1 = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con1 = new SqlConnection(connStr1);
            con1.Open();
            SqlCommand com = new SqlCommand("select * from tbl_sturegister where rollno='" + txtRoll.Text.Trim() + "' and class_nm='" + txtClass.Text + "'  and section='" + txtSection.Text + "' and sesnm='" + lblsession.Text + "' ", con1);
            SqlDataReader drr = com.ExecuteReader();
            while (drr.Read())
            {
                
                txtName.Text = drr["fullname"].ToString();
                txtFather.Text = drr["fname"].ToString();
                txtMother.Text = drr["mname"].ToString();
                txtAddress.Text = drr["addrss"].ToString();
                txtAdNo.Text = drr["admissionno"].ToString();
                txtBlood.Text = drr["bloodgrp"].ToString();
                txtDob.Text= (drr["dob"]).ToString();
                txtstupic.Text = drr["st_img"].ToString();
                temp = true;
                //con.Close();
            }
            //MessageBox.Show("not found");
            con.Close();

        }
        if (temp == false)
        {
            Response.Write("<script>alert('There Is No Such Kind Of Roll No. Exist !!!')</script>");
            //con.Close();
            clrfld();
        }
        

    }


//    protected void dropDown_SelectedIndexChanged(object sender, EventArgs e)
//    {
//        if (dropDown.Text == "Term-I")
//        {

//            wrapperOne.Visible = true;
//            wrapperTwo.Visible = false;
//             engread2.Enabled = false;
//            engrecit2.Enabled = false;
//             engcomp2.Enabled = false;
//              engexp2.Enabled = false;
//              engrcz2.Enabled = false;
//            engprwrt2.Enabled = false;
//           engcrtfmt2.Enabled = false;
//            engrldex2.Enabled = false;
//             hinread2.Enabled = false;
//            hinrecit2.Enabled = false;
//           hincrtfmt2.Enabled = false;
//               hinex2.Enabled = false;
//           mathcount2.Enabled = false;
//             mathrcz2.Enabled = false;
//             mathval2.Enabled = false;
//            mathprno2.Enabled = false;
//          mathcrtfmt2.Enabled = false;
//              mathex2.Enabled = false;
//               gkrcz2.Enabled = false;
//               gkans2.Enabled = false;
//              drawdw2.Enabled = false;
//             drawclr2.Enabled = false;
//             drawcrf2.Enabled = false;
//            foloinst2.Enabled = false;
//               obsrt2.Enabled = false;
//               behav2.Enabled = false;
//             creatvy2.Enabled = false;
//                neat2.Enabled = false;
//             apptsng2.Enabled = false;
//             apptdnc2.Enabled = false;
//             confdnc2.Enabled = false;
//           apptphycl2.Enabled = false;
//             guidcon2.Enabled = false;
//               vocab2.Enabled = false;
//             allrund2.Enabled = false;
//               attnd2.Enabled = false;
//                 hyt2.Enabled = false;
//                  wt2.Enabled = false;
//                   engread1.Enabled = true;
//                  engrecit1.Enabled = true;
//                   engcomp1.Enabled = true;
//                    engexp1.Enabled = true;
//                    engrcz1.Enabled = true;
//                  engprwrt1.Enabled = true;
//                 engcrtfmt1.Enabled = true;
//                  engrldex1.Enabled = true;
//                   hinread1.Enabled = true;
//                  hinrecit1.Enabled = true;
//                 hincrtfmt1.Enabled = true;
//                     hinex1.Enabled = true;
//                 mathcount1.Enabled = true;
//                   mathrcz1.Enabled = true;
//                   mathval1.Enabled = true;
//                  mathprno1.Enabled = true;
//                mathcrtfmt1.Enabled = true;
//                    mathex1.Enabled = true;
//                     gkrcz1.Enabled = true;
//                     gkans1.Enabled = true;
//                    drawdw1.Enabled = true;
//                   drawclr1.Enabled = true;
//                   drawcrf1.Enabled = true;
//                  foloinst1.Enabled = true;
//                     obsrt1.Enabled = true;
//                     behav1.Enabled = true;
//                   creatvy1.Enabled = true;
//                      neat1.Enabled = true;
//                   apptsng1.Enabled = true;
//                   apptdnc1.Enabled = true;
//                   confdnc1.Enabled = true;
//                 apptphycl1.Enabled = true;
//                   guidcon1.Enabled = true;
//                     vocab1.Enabled = true;
//                   allrund1.Enabled = true;
//                     attnd1.Enabled = true;
//                       hyt1.Enabled = true;
//                        wt1.Enabled = true;
//        }

//        if (dropDown.Text == "Term-II")
//        {
//            wrapperTwo.Visible = true;
//            wrapperOne.Visible = false;
//            engread1.Enabled = false;
//            engrecit1.Enabled = false;
//            engcomp1.Enabled = false;
//            engexp1.Enabled = false;
//            engrcz1.Enabled = false;
//            engprwrt1.Enabled = false;
//            engcrtfmt1.Enabled = false;
//            engrldex1.Enabled = false;
//            hinread1.Enabled = false;
//            hinrecit1.Enabled = false;
//            hincrtfmt1.Enabled = false;
//            hinex1.Enabled = false;
//            mathcount1.Enabled = false;
//            mathrcz1.Enabled = false;
//            mathval1.Enabled = false;
//            mathprno1.Enabled = false;
//            mathcrtfmt1.Enabled = false;
//            mathex1.Enabled = false;
//            gkrcz1.Enabled = false;
//            gkans1.Enabled = false;
//            drawdw1.Enabled = false;
//            drawclr1.Enabled = false;
//            drawcrf1.Enabled = false;
//            foloinst1.Enabled = false;
//            obsrt1.Enabled = false;
//            behav1.Enabled = false;
//            creatvy1.Enabled = false;
//            neat1.Enabled = false;
//            apptsng1.Enabled = false;
//            apptdnc1.Enabled = false;
//            confdnc1.Enabled = false;
//            apptphycl1.Enabled = false;
//            guidcon1.Enabled = false;
//            vocab1.Enabled = false;
//            allrund1.Enabled = false;
//            attnd1.Enabled = false;
//            hyt1.Enabled = false;
//            wt1.Enabled = false;
//             engread2.Enabled = true;
//            engrecit2.Enabled = true;
//             engcomp2.Enabled = true;
//              engexp2.Enabled = true;
//              engrcz2.Enabled = true;
//            engprwrt2.Enabled = true;
//           engcrtfmt2.Enabled = true;
//            engrldex2.Enabled = true;
//             hinread2.Enabled = true;
//            hinrecit2.Enabled = true;
//           hincrtfmt2.Enabled = true;
//               hinex2.Enabled = true;
//           mathcount2.Enabled = true;
//             mathrcz2.Enabled = true;
//             mathval2.Enabled = true;
//            mathprno2.Enabled = true;
//          mathcrtfmt2.Enabled = true;
//              mathex2.Enabled = true;
//               gkrcz2.Enabled = true;
//               gkans2.Enabled = true;
//              drawdw2.Enabled = true;
//             drawclr2.Enabled = true;
//             drawcrf2.Enabled = true;
//            foloinst2.Enabled = true;
//               obsrt2.Enabled = true;
//               behav2.Enabled = true;
//             creatvy2.Enabled = true;
//                neat2.Enabled = true;
//             apptsng2.Enabled = true;
//             apptdnc2.Enabled = true;
//             confdnc2.Enabled = true;
//           apptphycl2.Enabled = true;
//             guidcon2.Enabled = true;
//               vocab2.Enabled = true;
//             allrund2.Enabled = true;
//               attnd2.Enabled = true;
//                 hyt2.Enabled = true;
//                  wt2.Enabled = true;
//        }
        
//    }
}