﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_TeacherAssign : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["alogin"] != null)
        {

            if (!IsPostBack)
            {
                bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
                bd.bind_dropdown(ddlteacher, "select * from tbl_regteacher", "fullname", "id");
                // bd.bind_dropdown(ddlclass, "select * from tbl_class  order by class_value asc", "class_nm", "class_value");
                bd.bind_dropdown(ddlsection, "select * from tbl_section order by section_value asc", "section_nm", "section_value");

                bd.bind_grid(grd, "select *,(select class_nm from tbl_class where tbl_class.class_value = tbl_asnteacher.clsid) as class_nm,(select session_nm from tbl_session where tbl_session.id = tbl_asnteacher.sess_id) as sess_nm from tbl_asnteacher");
            }

        }
        else
        {

            Response.Redirect("~/index.aspx");

        }



    }
   

    protected void ddlteacher_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("sp_class", cs.connect());
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@teacherid", ddlteacher.SelectedValue);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {

            ddlclass.DataSource = dt;
            ddlclass.DataTextField = "class_nm";
            ddlclass.DataValueField = "class_value";
            ddlclass.DataBind();
            ddlclass.Items.Insert(0, new ListItem("Select", "-1"));



        }
    }

    protected void ddlclass_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("select * from tbl_submaster where clasid = '" + ddlclass.SelectedValue + "'", cs.connect());
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            DropDownCheckBoxes1.DataSource = dt;
            DropDownCheckBoxes1.DataTextField = "subject_nm";
            DropDownCheckBoxes1.DataValueField = "id";
            DropDownCheckBoxes1.DataBind();
            // DropDownCheckBoxes1.Items.Insert(0, new ListItem("Select", "-1"));


        }
    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "edit")
        {

            SqlCommand cmd = new SqlCommand("select * from tbl_asnteacher where id ='" + e.CommandArgument + "'", cs.connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                ddlsession.SelectedValue = dt.Rows[0]["sess_id"].ToString();
                ddlteacher.SelectedItem.Text = dt.Rows[0]["facultynm"].ToString();
                ddlsection.SelectedItem.Text = dt.Rows[0]["section"].ToString();
            }
            Button7.Text = "Update";
            // Response.Redirect("assignteacher.aspx");




        }
        else if (e.CommandName == "delete")
        {
            cs.exec_qry("delete from tbl_asnteacher where id='" + e.CommandArgument + "'");
            bd.bind_grid(grd, "select *,(select class_nm from tbl_class where tbl_class.id = tbl_asnteacher.clsid) as class_nm,(select session_nm from tbl_session where tbl_session.id = tbl_asnteacher.sess_id) as sess_nm from tbl_asnteacher");

        }
        else
        {




        }
    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void grd_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        string tsubject = "";
        for (int i = 0; i < DropDownCheckBoxes1.Items.Count; i++)
        {

            if (DropDownCheckBoxes1.Items[i].Selected)
            {

                tsubject += DropDownCheckBoxes1.Items[i].Text + ",";

            }

        }
        if (Button7.Text == "Submit")
        {

            tsubject = tsubject.TrimEnd(',');
            cs.exec_qry("insert into tbl_asnteacher values('" + ddlsession.SelectedValue + "','" + ddlteacher.SelectedValue + "','" + ddlteacher.SelectedItem.Text + "','" + ddlclass.SelectedValue + "','" + ddlsection.SelectedItem.Text + "','" + tsubject + "','true',getdate())");
            Response.Redirect("TeacherAssign.aspx");

            //bd.bind_grid(grd, "select *,(select class_nm from tbl_class where tbl_class.class_value = tbl_asnteacher.clsid) as class_nm,(select session_nm from tbl_session where tbl_session.id = tbl_asnteacher.sess_id) as sess_nm from tbl_asnteacher");

        }
        else
        {
            tsubject = tsubject.TrimEnd(',');
            cs.exec_qry("update tbl_asnteacher set sess_id ='" + ddlsession.SelectedValue + "',tid='" + ddlteacher.SelectedValue + "', facultynm='" + ddlteacher.SelectedItem.Text + "',clsid='" + ddlclass.SelectedValue + "',section='" + ddlsection.SelectedItem.Text + "',asnsubject='" + tsubject + "',isactive='true',asndt=getdate()");
            Response.Redirect("TeacherAssign.aspx");

            //bd.bind_grid(grd, "select *,(select class_nm from tbl_class where tbl_class.class_value = tbl_asnteacher.clsid) as class_nm,(select session_nm from tbl_session where tbl_session.id = tbl_asnteacher.sess_id) as sess_nm from tbl_asnteacher");

        }
    }
}