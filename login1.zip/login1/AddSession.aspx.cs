﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_AddSession : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["alogin"] != null)
        {



        }
        else
        {

            Response.Redirect("~/index.aspx");

        }

        getdata();
    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {

            cs.exec_qry("delete from tbl_session where id='" + e.CommandArgument + "'");
            Response.Write("<script>alert('Session Has Been Deleted Successfully !!!')</script>");
            getdata();//Response.Redirect("Addsession.aspx");
        }

    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        int sessionval = Convert.ToInt32(DropDownList1.SelectedValue);
        string sessionno = DropDownList1.SelectedItem.Text;

        SqlCommand cmd = new SqlCommand("insert into tbl_session (session_nm,session_val,isactive) values('" + sessionno + "','" + sessionval + "','True')", cs.connect());
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Session Has Been Added Successfully !!!')</script>");
        getdata();
    }

    protected void getdata()
    {
        SqlCommand com = new SqlCommand("select * from tbl_session order by session_val asc", cs.connect());
        SqlDataAdapter daa = new SqlDataAdapter(com);
        DataTable dtt = new DataTable();
        daa.Fill(dtt);
        if (dtt.Rows.Count > 0)
        {

            grd.DataSource = dtt;
            grd.DataBind();

            // TextBox4.Text = "";

        }
    }
}