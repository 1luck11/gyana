﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class index : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void Button1_Click1(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "Admin")
        {
            SqlCommand cmd = new SqlCommand("sp_login", cs.connect());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@usertype", DropDownList1.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@userid", TextBox1.Text);
            cmd.Parameters.AddWithValue("@paswrd", TextBox3.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Session["alogin"] = TextBox1.Text;

                Response.Redirect("login1/welcomeAdminPage.aspx");


            }
            else
            {
                Response.Write("<script>alert('You Have Entered Wrong Credentials !!!')</script>");

            }
        }
        else if (DropDownList1.SelectedItem.Text == "Teacher")
        {

            SqlCommand cmd = new SqlCommand("sp_teacherlogin", cs.connect());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userid", TextBox1.Text);
            cmd.Parameters.AddWithValue("@paswrd", TextBox3.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                SqlCommand cmds = new SqlCommand("select * from tbl_regteacher where userid = '" + TextBox1.Text + "'", cs.connect());
                SqlDataAdapter das = new SqlDataAdapter(cmd);
                DataTable dts = new DataTable();
                das.Fill(dts);
                if (dts.Rows.Count > 0)
                {
                    Session["tid"] = dt.Rows[0]["id"].ToString();
                    Session["tname"] = dt.Rows[0]["fullname"].ToString();


                }
                else
                {
                    Response.Write("<script>alert('You Have Entered Wrong Credentials !!!')</script>");
                }
                Session["tlogin"] = TextBox1.Text;

                Response.Redirect("~/login1/welcomepage.aspx");


            }

        }
        else
        {

            Response.Redirect("~/index.aspx");

        }

    }
}