﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_welcomepage : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["tlogin"] != null)
        {
            if (!IsPostBack)
            {


                bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "session_val");
                getclass();
                bd.bind_dropdown(ddlsection, "select * from tbl_section order by section_value asc", "section_nm", "id");

                Session["session"] = ddlsession.SelectedItem;
                string sec = ddlsection.SelectedItem.Value.ToString();

            }
        }
        else
        {

            Response.Redirect("~/index.aspx");


        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("welcomepage.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("print.aspx");
    }
    
    public void getclass()
    {
        SqlCommand cmd = new SqlCommand("sp_class", cs.connect());
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@teacherid", Convert.ToInt32(Session["tid"].ToString()));
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            ddlclass.DataSource = dt;
            ddlclass.DataTextField = "class_nm";
            ddlclass.DataValueField = "class_value";
            ddlclass.DataBind();
            ddlclass.Items.Insert(0, new ListItem("Select", "-1"));

        }

    }

    protected void ddlsection_SelectedIndexChanged(object sender, EventArgs e)
    {

        //  List<string> str = new List<string>();
        SqlCommand cmd = new SqlCommand("sp_checksubjects", cs.connect());
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@teachernm", Session["tname"].ToString());
        cmd.Parameters.AddWithValue("@clasid", ddlclass.SelectedValue);
        cmd.Parameters.AddWithValue("@section", ddlsection.SelectedItem.Text);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {

            //   str.Add(dt.Rows[0]["subject_nm"].ToString());
            DropDownCheckBoxes1.DataSource = dt;
            DropDownCheckBoxes1.DataTextField = "subject_nm";
            DropDownCheckBoxes1.DataValueField = "subject_nm";
            DropDownCheckBoxes1.DataBind();
            // DropDownCheckBoxes1.Items.Insert(0, new ListItem("Select", "-1"));




        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {

        Session.Abandon();
        Session.Clear();
        Session.Remove("tid");
        Session.Remove("tname");
        Response.Redirect("~/index.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("teacher1.aspx");
    }
    protected void Button5_Click1(object sender, EventArgs e)
    {
        Session["cid"] = ddlclass.SelectedValue;
        string tsubject = "";
        for (int i = 0; i < DropDownCheckBoxes1.Items.Count; i++)
        {

            if (DropDownCheckBoxes1.Items[i].Selected)
            {

                tsubject += DropDownCheckBoxes1.Items[i].Text + ",";

            }

        }
        tsubject = tsubject.TrimEnd(',');
        string classs = ddlclass.SelectedItem.Text;

        if (ddlclass.SelectedItem.Text == "Pre Nursery")
        {
            Session["classs"] = ddlclass.SelectedItem.Text;
            Session["Sec"] = ddlsection.SelectedItem.Text.ToString();

            Response.Redirect("~/login1/TeacherField_PNC.aspx?session=" + ddlsession.SelectedItem.Text + "&subjects=" + tsubject + "");

            //Response.Redirect("../webpage4.aspx?class=" + classs + "&section=" + section + "&subjects=" + tsubject);

        }
        else if (ddlclass.SelectedItem.Text == "Nursery" || ddlclass.SelectedItem.Text == "K.G.")
        {
            Session["classs"] = ddlclass.SelectedItem.Text;
            Session["Sec"] = ddlsection.SelectedItem.Text;

            Response.Redirect("~/login1/TeacherField_NC_KG.aspx?session=" + ddlsession.SelectedItem.Text + "&subjects=" + tsubject + "");

        }
        else if (ddlclass.SelectedItem.Text == "I" || ddlclass.SelectedItem.Text == "II")
        {

            Session["classs"] = ddlclass.SelectedItem.Text;
            Session["Sec"] = ddlsection.SelectedItem.Text;

            Response.Redirect("~/login1/TeacherField_I_II.aspx?session=" + ddlsession.SelectedItem.Text + "&subjects=" + tsubject + "");

        }
        else if (ddlclass.SelectedItem.Text == "III" || ddlclass.SelectedItem.Text == "IV" ||ddlclass.SelectedItem.Text == "V")
        {

            Session["classs"] = ddlclass.SelectedItem.Text;
            Session["Sec"] = ddlsection.SelectedItem.Text;

            Response.Redirect("~/login1/TeacherField_III_V.aspx?session=" + ddlsession.SelectedItem.Text + "&subjects=" + tsubject + "");

        }
      
       
        else
        {
            Response.Write("<script>alert('You Have Entered Wrong Informations')</script>");
        }

    }
    protected void Button4_Click1(object sender, EventArgs e)
    {
        Session.Abandon();
        Session.Remove("tlogin");
        Session.Clear();
        Response.Redirect("~/index.aspx");
    }
}