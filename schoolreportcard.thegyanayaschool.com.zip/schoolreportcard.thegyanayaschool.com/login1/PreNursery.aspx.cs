﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class PreNursery : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt = new DataTable();
    SqlCommand cmd = new SqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            lblsession.Text = Request.QueryString["session"].ToString();
            if (!IsPostBack)
            {

                txtClass.Text = Session["classs"].ToString();
                txtSection.Text = Session["Sec"].ToString();

            }
        }
        catch (Exception ae)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alert('" + ae.Message + "',this.open('../index.aspx'))", true);
        }
    }
    //    public string Save_Rpt_card()
    //    {
    //        return "";
    //    }
    protected void clrfld()
    {
        txtName.Text = "";
        txtFather.Text = "";
        txtMother.Text = "";
        txtAddress.Text = "";
        txtAdNo.Text = "";
        txtRoll.Text = "";
        //txtsection.Text = dr["sec"].ToString();
        //txtclass.Text = dr["class"].ToString();
        txtBlood.Text = "";
        txtDob.Text = "";


        
        txtstupic.Text = "";
        hindiPt1.Text = "";
        hindiNB1.Text = "";
        hindiHY1.Text = "";
        hindiTotal1.Text = "";
        hindiGrade1.Text = "";

        englishPt1.Text = "";
        englishNB1.Text = "";
        englishHY1.Text = "";
        englishTotal1.Text = "";
        englishGrade1.Text = "";

        mathPt1.Text = "";
        mathNB1.Text = "";
        mathHY1.Text = "";
        mathTotal1.Text = "";
        mathGrade1.Text = "";

        gkPt1.Text = "";
        gkNB1.Text = "";
        gkHY1.Text = "";
        gkTotal1.Text = "";
        gkGrade1.Text = "";

        lbltotal1.Text = "";
        lblpercentage1.Text = "";
        attendance1.Text = "";
        height1.Text = "";
        weight1.Text = "";
        txtRemark1.Text = "";
        txtresult.SelectedIndex = -1;

        artEdu.SelectedIndex = -1;
        conversation.SelectedIndex = -1;
        Personality.SelectedIndex = -1;
        PhysicalEducation.SelectedIndex = -1;
        Music.SelectedIndex = -1;
        Dance.SelectedIndex = -1;
        Discipline.SelectedIndex = -1;
    }

    

    protected void txt_rno_TextChanged(object sender, EventArgs e)
    {

        bool temp = false;
        string connStr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        con.Open();
        SqlCommand cmd = new SqlCommand("select * from new_Result_PNC where rollno='" + txtRoll.Text.Trim() + "' and class='" + txtClass.Text + "'and sec='" + txtSection.Text + "' and sessionss='" + lblsession.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            txtName.Text = dr["name"].ToString();
            txtFather.Text = dr["fname"].ToString();
            txtMother.Text = dr["mname"].ToString();
            txtAddress.Text = dr["address"].ToString();
            txtAdNo.Text = dr["admissionno"].ToString();
            txtSection.Text = dr["sec"].ToString();
            txtClass.Text = dr["class"].ToString();
            txtBlood.Text = dr["bloodgrp"].ToString();
            txtDob.Text = dr["dob"].ToString();
            txtstupic.Text = dr["student_pic"].ToString();
            hindiPt1.Text = dr["hindipt1"].ToString();
            hindiNB1.Text = dr["hindiNB1"].ToString();
            hindiHY1.Text = dr["hindiHy1"].ToString();
            hindiTotal1.Text = dr["hinditotal1"].ToString();
            hindiGrade1.Text = dr["hindiGrade1"].ToString();

            englishPt1.Text = dr["englishpt1"].ToString();
            englishNB1.Text = dr["englishNB1"].ToString();
            englishHY1.Text = dr["englishHy1"].ToString();
            englishTotal1.Text = dr["englishtotal1"].ToString();
            englishGrade1.Text = dr["englishGrade1"].ToString();

            mathPt1.Text = dr["mathpt1"].ToString();
            mathNB1.Text = dr["mathNB1"].ToString();
            mathHY1.Text = dr["mathHy1"].ToString();
            mathTotal1.Text = dr["mathtotal1"].ToString();
            mathGrade1.Text = dr["mathGrade1"].ToString();

            gkPt1.Text = dr["gkpt1"].ToString();
            gkNB1.Text = dr["gkNB1"].ToString();
            gkHY1.Text = dr["gkHy1"].ToString();
            gkTotal1.Text = dr["gktotal1"].ToString();
            gkGrade1.Text = dr["gkGrade1"].ToString();

            lbltotal1.Text = dr["toatl1"].ToString();
            lblpercentage1.Text = dr["percentage1"].ToString();
            attendance1.Text = dr["attendence1"].ToString();
            height1.Text = dr["height1"].ToString();
            weight1.Text = dr["weight1"].ToString();
            txtRemark1.Text = dr["tearemrk"].ToString();
            txtresult.SelectedIndex = txtresult.Items.IndexOf(new ListItem(dr["result1"].ToString()));

            artEdu.SelectedIndex = artEdu.Items.IndexOf(new ListItem(dr["art_edu"].ToString()));
            conversation.SelectedIndex = conversation.Items.IndexOf(new ListItem(dr["conversation"].ToString()));
            Personality.SelectedIndex = Personality.Items.IndexOf(new ListItem(dr["personality"].ToString()));
            PhysicalEducation.SelectedIndex = PhysicalEducation.Items.IndexOf(new ListItem(dr["health"].ToString()));
            Music.SelectedIndex = Music.Items.IndexOf(new ListItem(dr["music"].ToString()));
            Dance.SelectedIndex = Dance.Items.IndexOf(new ListItem(dr["dance"].ToString()));
            Discipline.SelectedIndex = Discipline.Items.IndexOf(new ListItem(dr["discipline"].ToString()));


            temp = true;
        }
        if (temp == false)
        {
            string connStr1 = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con1 = new SqlConnection(connStr1);
            con1.Open();
            SqlCommand com = new SqlCommand("select * from tbl_sturegister where rollno='" + txtRoll.Text.Trim() + "' and class_nm='" + txtClass.Text + "'  and section='" + txtSection.Text + "' and sesnm='" + lblsession.Text + "' ", con1);
            SqlDataReader drr = com.ExecuteReader();
            while (drr.Read())
            {

                txtName.Text = drr["fullname"].ToString();
                txtFather.Text = drr["fname"].ToString();
                txtMother.Text = drr["mname"].ToString();
                txtAddress.Text = drr["addrss"].ToString();
                txtAdNo.Text = drr["admissionno"].ToString();
                txtBlood.Text = drr["bloodgrp"].ToString();
                txtDob.Text = (drr["dob"]).ToString();
                txtstupic.Text = drr["st_img"].ToString();
                temp = true;
                //con.Close();
            }
            //MessageBox.Show("not found");
            con.Close();

        }
        if (temp == false)
        {
            Response.Write("<script>alert('There Is No Such Kind Of Roll No. Exist !!!')</script>");
            //con.Close();
            clrfld();
        }


    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //if (dropDown.Text=="Select")
        //{
        //    Response.Write("<script>alert('Please Select The Term !!!')</script>");
        //    return;
        //}

        SqlCommand cmd = new SqlCommand(@"delete from new_Result_PNC
                                        Insert Into new_Result_PNC (
name
,class
,sec
,rollNo
,admissionno
,regdate
,fname
,mname
,bloodgrp
,address
,hindipt1
,hindiNB1
,HindiHY1
,hindiTotal1
,hindiGrade1
,hindipt2
,hindiNB2
,HindiHY2
,hindiTotal2
,hindiGrade2
,englishpt1
,englishNB1
,englishHY1
,englishTotal1
,englishGrade1
,englishpt2
,englishNB2
,englishHY2
,englishTotal2
,englishGrade2
,mathpt1
,mathNB1
,mathHY1
,mathTotal1
,mathGrade1
,mathpt2
,mathNB2
,mathHY2
,mathTotal2
,mathGrade2
,gkpt1
,gkNB1
,gkHY1
,gkTotal1
,gkGrade1
,gkpt2
,gkNB2
,gkHY2
,gkTotal2
,gkGrade2
,toatl1
,percentage1
,total2
,percentage2
,attendence1
,attendence2
,height1
,height2
,weight1
,weight2
,sessionss
,tearemrk
,propmoteclass
,crtd_date
,result1
,result2
,dob
,student_pic
,art_edu
,conversation
,personality
,health
,music
,dance
,discipline)
                                        values(
@name
,@class
,@sec
,@rollNo
,@admissionno
,@regdate
,@fname
,@mname
,@bloodgrp
,@address
,@hindipt1
,@hindiNB1
,@HindiHY1
,@hindiTotal1
,@hindiGrade1
,@hindipt2
,@hindiNB2
,@HindiHY2
,@hindiTotal2
,@hindiGrade2
,@englishpt1
,@englishNB1
,@englishHY1
,@englishTotal1
,@englishGrade1
,@englishpt2
,@englishNB2
,@englishHY2
,@englishTotal2
,@englishGrade2
,@mathpt1
,@mathNB1
,@mathHY1
,@mathTotal1
,@mathGrade1
,@mathpt2
,@mathNB2
,@mathHY2
,@mathTotal2
,@mathGrade2
,@gkpt1
,@gkNB1
,@gkHY1
,@gkTotal1
,@gkGrade1
,@gkpt2
,@gkNB2
,@gkHY2
,@gkTotal2
,@gkGrade2
,@toatl1
,@percentage1
,@total2
,@percentage2
,@attendence1
,@attendence2
,@height1
,@height2
,@weight1
,@weight2
,@sessionss
,@tearemrk
,@propmoteclass
,@crtd_date
,@result1
,@result2
,@dob
,@student_pic
,@art_edu
,@conversation
,@personality
,@health
,@music
,@dance
,@discipline)", cs.connect());

        //cmd = new SqlCommand("Save_reportcard", cs.Connect());
        //cmd.CommandType = CommandType.StoredProcedure;        

        cmd.Parameters.AddWithValue("@name", txtName.Text.ToUpper());
        cmd.Parameters.AddWithValue("@class", txtClass.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sec", txtSection.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rollNo", txtRoll.Text.ToUpper());
        cmd.Parameters.AddWithValue("@admissionno", txtAdNo.Text.ToUpper());
        cmd.Parameters.AddWithValue("@fname", txtFather.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mname", txtMother.Text.ToUpper());
        cmd.Parameters.AddWithValue("@bloodgrp", txtBlood.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dob", txtDob.Text.ToUpper());
        cmd.Parameters.AddWithValue("@student_pic", txtstupic.Text);
        cmd.Parameters.AddWithValue("@address", txtAddress.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiPt1", hindiPt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiNB1", hindiNB1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiHY1", hindiHY1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiTotal1", hindiTotal1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiGrade1", hindiGrade1.Text.ToUpper());

        cmd.Parameters.AddWithValue("@hindiPt2", "");
        cmd.Parameters.AddWithValue("@hindiNB2", "");
        cmd.Parameters.AddWithValue("@hindiHY2", "");
        cmd.Parameters.AddWithValue("@hindiTotal2", "");
        cmd.Parameters.AddWithValue("@hindiGrade2", "");

        cmd.Parameters.AddWithValue("@englishPt1", englishPt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@englishNB1", englishNB1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@englishHY1", englishHY1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@englishTotal1", englishTotal1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@englishGrade1", englishGrade1.Text.ToUpper());

        cmd.Parameters.AddWithValue("@englishPt2", "");
        cmd.Parameters.AddWithValue("@englishNB2", "");
        cmd.Parameters.AddWithValue("@englishHY2", "");
        cmd.Parameters.AddWithValue("@englishTotal2", "");
        cmd.Parameters.AddWithValue("@englishGrade2", "");

        cmd.Parameters.AddWithValue("@mathPt1", mathPt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathNB1", mathNB1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathHY1", mathHY1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathTotal1", mathTotal1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathGrade1", mathGrade1.Text.ToUpper());

        cmd.Parameters.AddWithValue("@mathPt2", "");
        cmd.Parameters.AddWithValue("@mathNB2", "");
        cmd.Parameters.AddWithValue("@mathHY2", "");
        cmd.Parameters.AddWithValue("@mathTotal2", "");
        cmd.Parameters.AddWithValue("@mathGrade2", "");

        cmd.Parameters.AddWithValue("@gkPt1", gkPt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkNB1", gkNB1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkHY1", gkHY1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkTotal1", gkTotal1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkGrade1", gkGrade1.Text.ToUpper());

        cmd.Parameters.AddWithValue("@gkPt2", "");
        cmd.Parameters.AddWithValue("@gkNB2", "");
        cmd.Parameters.AddWithValue("@gkHY2", "");
        cmd.Parameters.AddWithValue("@gkTotal2", "");
        cmd.Parameters.AddWithValue("@gkGrade2", "");

        cmd.Parameters.AddWithValue("@toatl1", lbltotal1.Text);
        cmd.Parameters.AddWithValue("@percentage1", lblpercentage1.Text);
        cmd.Parameters.AddWithValue("@total2", "");
        cmd.Parameters.AddWithValue("@percentage2", "");

        cmd.Parameters.AddWithValue("@attendence1", attendance1.Text);
        cmd.Parameters.AddWithValue("@attendence2", "");
        cmd.Parameters.AddWithValue("@height1", height1.Text);
        cmd.Parameters.AddWithValue("@height2", "");
        cmd.Parameters.AddWithValue("@weight1", weight1.Text);
        cmd.Parameters.AddWithValue("@weight2", "");
        cmd.Parameters.AddWithValue("@tearemrk", txtRemark1.Text);
        cmd.Parameters.AddWithValue("@crtd_date", DateTime.Now);
        cmd.Parameters.AddWithValue("@result1", txtresult.Text);
        cmd.Parameters.AddWithValue("@result2", "");
        cmd.Parameters.AddWithValue("@art_edu", artEdu.Text);
        cmd.Parameters.AddWithValue("@conversation", conversation.Text);
        cmd.Parameters.AddWithValue("@personality", Personality.Text);
        cmd.Parameters.AddWithValue("@health", PhysicalEducation.Text);
        cmd.Parameters.AddWithValue("@music", Music.Text);
        cmd.Parameters.AddWithValue("@Dance", Dance.Text);
        cmd.Parameters.AddWithValue("@discipline", Discipline.Text);





        cmd.Parameters.AddWithValue("@regDate", DateTime.Now);
        cmd.Parameters.AddWithValue("@sessionss", lblsession.Text);
        cmd.Parameters.AddWithValue("@propmoteclass", "");

        cmd.ExecuteNonQuery();
        cs.exec_qry("Delete from CLASS_III_V where id not in(select max(id) from CLASS_III_V group by name, class, sec, rollno, admissionno, fname, mname, bloodgrp, sessionss)");//Remove All Duplicates Entries From (this) Table 
        Response.Write("<script>alert('You Have Sucessfully Saved Marks !!! ')</script>");
        Session["admsnno"] = txtAdNo.Text.ToUpper();
        //Session["Term"] = DropDownList1.SelectedItem.Text.ToUpper();
        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.success('Marks Saved Successfully of " + txtnam.Text.ToUpper() + "')", true);
        Response.Write("<script>");
        Response.Write("window.open('New_Pre-nursery-term-1.aspx?sessions=" + lblsession.Text + "','_blank')");
        Response.Write("</script>");
        clrfld();

        


        
        clrfld();
    }
}