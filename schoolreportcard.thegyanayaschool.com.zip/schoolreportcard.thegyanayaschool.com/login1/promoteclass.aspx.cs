﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class login1_StudentReg : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
    SqlCommand com;
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["alogin"] != null)
        {

            if (!IsPostBack)
            {



                bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
                bd.bind_dropdown(ddlsessionnew, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
                bd.bind_dropdown(ddlses, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
                bd.bind_dropdown(ddlclass, "select * from tbl_class  order by class_value asc", "class_nm", "class_value");
                bd.bind_dropdown(ddlclassnew, "select * from tbl_class  order by class_value asc", "class_nm", "class_value");
                bd.bind_dropdown(ddlsection, "select * from tbl_section order by section_value asc", "section_nm", "id");
                bd.bind_dropdown(ddlsectionnew, "select * from tbl_section order by section_value asc", "section_nm", "id");

                Session["session"] = ddlsession.SelectedItem;
                string sec = ddlsection.SelectedItem.Value.ToString();
                bd.bind_grid(grd, "select * from tbl_sturegister");



            }
            else
            {
            }
        }

        else
        {

            Response.Redirect("~/index.aspx");

        }

    }

    protected void search_Click(object sender, EventArgs e)
    {

        //Response.Write("<script>alert('" + ddlsession.SelectedItem.Text + "')</script>");
        //bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
        bd.bind_grid(grd, "select * from tbl_sturegister where sesnm='" + ddlses.SelectedItem.Text + "' AND (rollno LIKE '%" + TextBox1.Text + "%'  OR admissionno LIKE '%" + TextBox1.Text + "%' OR section LIKE'%" + TextBox1.Text + "%' OR class_nm LIKE'%" + TextBox1.Text + "%' OR fullname LIKE'%" + TextBox1.Text + "%')");


    }

    public void clear()
    {

        txtadmsn.Text = "";

        txtrollno.Text = "";

        txtnam.Text = "";
        ddlclass.SelectedValue = "-1";

        ddlsection.SelectedValue = "-1";
        ddlsession.SelectedValue = "-1";

    }
    protected void grd_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        grd.PageIndex = e.NewPageIndex;
        bd.bind_grid(grd, "select * from tbl_sturegister");


    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "edit")
        {

            SqlCommand cmd = new SqlCommand("select * from tbl_sturegister where id='" + e.CommandArgument + "'", cs.connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                //Label1.Visible = false;
                // Label7.Visible = false;
                stupic.Visible = false;
                txtadmsn.ReadOnly = true;
                //txtdob.Visible = false;
                txtnam.Text = dt.Rows[0]["fullname"].ToString();
                ddlsession.SelectedItem.Text = dt.Rows[0]["sesnm"].ToString();
                ddlclass.SelectedItem.Text = dt.Rows[0]["class_nm"].ToString();
                ddlsection.SelectedItem.Text = dt.Rows[0]["section"].ToString();

                //txtdob.Text = ((DateTime)dt.Rows[0]["dob"]).ToString("dd/MM/yyyy");
                txtrollno.Text = dt.Rows[0]["rollno"].ToString();

                txtadmsn.Text = dt.Rows[0]["admissionno"].ToString();

                //txtadhar.Text = dt.Rows[0]["adharno"].ToString();


            }
            ViewState["eid"] = e.CommandArgument;
            bd.bind_grid(grd, "select * from tbl_sturegister");
            Button5.Text = "Update";

        }
        else if (e.CommandName == "delete")
        {
            cs.exec_qry("delete from tbl_sturegister where id='" + e.CommandArgument + "'");

            bd.bind_grid(grd, "select * from tbl_sturegister");

        }
        else
        {





        }
    }
    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //  bd.bind_grid(grd, "select * from tbl_sturegister");
    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void Button5_Click1(object sender, EventArgs e)
    {
        string img = "";
        if (Button5.Text == "Submit")
        {
            dt = bd.fill_datatable("select * from tbl_sturegister where fullname='" + txtnam.Text + "' and sesnm='" + ddlsessionnew.SelectedItem.Text + "' and section='" + ddlsectionnew.SelectedItem.Text + "' and class_nm='" + ddlclassnew.SelectedItem.Text + "'  order by id desc");
            if (dt.Rows.Count > 0)
            {
                Response.Write("<script>alert('This Student is Allready Promote')</script>");
                return;
            }

            SqlCommand cmd = new SqlCommand("sp_sturegister", cs.connect());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@fullname", txtnam.Text);
            cmd.Parameters.AddWithValue("@sesnm", ddlsessionnew.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@class_nm", ddlclassnew.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@section", ddlsectionnew.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@fname", txtfather.Text);
            cmd.Parameters.AddWithValue("@mname", txtmother.Text);
            cmd.Parameters.AddWithValue("@admissionno", txtadmsn.Text);
            cmd.Parameters.AddWithValue("@rollno", txtrollnonew.Text);
            cmd.Parameters.AddWithValue("@smobile", txtmob.Text);
            cmd.Parameters.AddWithValue("@fmobileno", txtmob.Text);
            cmd.Parameters.AddWithValue("@bloodgrp", txtbloodgrp.Text);
            //  cmd.Parameters.AddWithValue("@st_img", img);
            //cmd.Parameters.AddWithValue("@adharno", txtadhar.Text);
            cmd.Parameters.AddWithValue("@stream", string.Empty);
            cmd.Parameters.AddWithValue("@dob", txtdob.Text);
            cmd.Parameters.AddWithValue("@addrss", txtaddrs.Text);
            cmd.ExecuteNonQuery();
            clear();
            bd.bind_grid(grd, "select * from tbl_sturegister");
            bd.clear_controls(this);
        }
        else
        {

            //dt = bd.fill_datatable("select * from tbl_sturegister where admissionno='" + txtadmsn.Text + "' order by id desc");
            //if (dt.Rows.Count > 0)
            //{
            //    Response.Write("<script>alert('This Admissionno is Allready Exict')</script>");
            //    return;
            //}  


            cs.exec_qry("update tbl_sturegister set fullname='" + txtnam.Text + "',sesnm='" + ddlsession.SelectedItem.Text + "',class_nm='" + ddlclass.SelectedItem.Text + "',section='" + ddlsection.SelectedItem.Text + "',rollno='" + txtrollno.Text + "'where id = '" + ViewState["eid"] + "'");
            Button5.Text = "Submit";
            bd.bind_grid(grd, "select * from tbl_sturegister");

            Response.Redirect("../login1/StudentReg.aspx");


        }
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Student Promoted Successfully')", true);
    }
    protected void txt_admno_TextChanged(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("select * from tbl_sturegister where admissionno='" + txtadmsn.Text + "' order by id desc", cs.connect());
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            txtnam.Text = dt.Rows[0]["fullname"].ToString();
            ddlsession.SelectedItem.Text = dt.Rows[0]["sesnm"].ToString();
            ddlsessionnew.SelectedItem.Text = dt.Rows[0]["sesnm"].ToString();
            ddlsection.SelectedItem.Text = dt.Rows[0]["section"].ToString();
            ddlsectionnew.SelectedItem.Text = dt.Rows[0]["section"].ToString();
            ddlclass.SelectedItem.Text = dt.Rows[0]["class_nm"].ToString();
            ddlclassnew.SelectedItem.Text = dt.Rows[0]["class_nm"].ToString();
            txtrollno.Text = dt.Rows[0]["rollno"].ToString();
            txtrollnonew.Text = dt.Rows[0]["rollno"].ToString();



            txtfather.Text = dt.Rows[0]["fname"].ToString();
            txtmother.Text = dt.Rows[0]["mname"].ToString();


            txtbloodgrp.Text = dt.Rows[0]["bloodgrp"].ToString();
            txtmob.Text = dt.Rows[0]["smobile"].ToString();
            txtdob.Text = dt.Rows[0]["dob"].ToString();
            txtadmsn.Text = dt.Rows[0]["admissionno"].ToString();

            //txtadhar.Text = dt.Rows[0]["adharno"].ToString();
            txtaddrs.Text = dt.Rows[0]["addrss"].ToString();
        }
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox1.Checked)
        {
            btnleft.Visible = true;
            Button5.Visible = false;
        }
        else
        {
            btnleft.Visible = false;
            Button5.Visible = true;
        }
    }
    protected void btnleft_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert_leftstudent", cs.connect());
        cmd.CommandType = CommandType.StoredProcedure;
       // cmd.Parameters.AddWithValue("@student_id",  ViewState["eid"] );
        cmd.Parameters.AddWithValue("@student_name", txtnam.Text);
        cmd.Parameters.AddWithValue("@session", ddlsession.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@class", ddlclass.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@section", ddlsection.SelectedItem.Text);

        cmd.Parameters.AddWithValue("@rollno", txtrollno.Text);
       
        cmd.ExecuteNonQuery();

        Response.Redirect("../login1/StudentReg.aspx");
      
    }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox2.Checked)
        {
         
            btnleft.Visible = false;
            Button5.Visible = false;
            btnbulk.Visible = true;
            bd.bind_grid(GridView1, "select * from tbl_sturegister where sesnm='" + ddlsession.SelectedItem.Text + "' and class_nm='" + ddlclass.SelectedItem.Text + "' and section='"+ddlsection.SelectedItem.Text+"'");
            GridView1.Visible = true;
            grd.Visible = false;
        }
        else
        {
            btnbulk.Visible = false;
            btnleft.Visible = false;
            Button5.Visible = true;
            GridView1.Visible = false;
            grd.Visible = true;
        }
    }
    protected void btnbulk_Click(object sender, EventArgs e)
    {
        //SqlCommand cmd = new SqlCommand("insert_bulk_promote", cs.connect());
        //cmd.CommandType = CommandType.StoredProcedure;


        //cmd.Parameters.AddWithValue("@sesnm", ddlsessionnew.SelectedItem.Text);
        //cmd.Parameters.AddWithValue("@class_nm", ddlclassnew.SelectedItem.Text);
        //cmd.Parameters.AddWithValue("@section", ddlsectionnew.SelectedItem.Text);

       

        //cmd.ExecuteNonQuery();

        //Response.Redirect("../login1/StudentReg.aspx");

        foreach (GridViewRow g1 in GridView1.Rows)
        {
            SqlConnection con = new SqlConnection(connStr);
            com = new SqlCommand("insert into tbl_sturegister(fullname,fname,mname,admissionno,rollno,smobile,fmobileno,bloodgrp,stream,regdate,isactive,dob,addrss,sesnm,class_nm,section) values ('" + g1.Cells[0].Text + "','" + g1.Cells[1].Text + "','" + g1.Cells[2].Text + "','" + g1.Cells[3].Text + "','" + g1.Cells[4].Text + "','" + g1.Cells[5].Text + "','" + g1.Cells[7].Text + "','" + g1.Cells[8].Text + "','" + g1.Cells[9].Text + "','" + g1.Cells[10].Text + "','" + g1.Cells[11].Text + "','" + g1.Cells[12].Text + "','" + g1.Cells[13].Text + "','" + ddlsessionnew.SelectedItem.Text + "','" + ddlclassnew.SelectedItem.Text + "','" + ddlsectionnew.SelectedItem.Text + "')", con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
        }
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Students Promoted Successfully')", true);
    }
}