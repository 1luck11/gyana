﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class webpage3 : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt = new DataTable();
    SqlCommand cmd = new SqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            lblsession.Text = Request.QueryString["session"].ToString();
            if (!IsPostBack)
            {
                
                txtclass.Text = Session["classs"].ToString();
                txtsection.Text = Session["Sec"].ToString();

            }
        }
        catch (Exception ae)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alert('" + ae.Message + "',this.open('../index.aspx'))", true);
        }
    }
    protected void clrfld()
    {
        txtnam.Text = "";
        txtfather.Text = "";
        txtmother.Text = "";
        txtaddrs.Text = "";
        txtadmsn.Text = "";
        txtrollno.Text = "";
        //txtsection.Text = dr["sec"].ToString();
        //txtclass.Text = dr["class"].ToString();
        txtbloodgrp.Text = "";
        txtdob.Text = "";
        engrdT1.Text = "";
        engrd1.Text = "";
        engrd2.Text = "";
        engrdtot.Value ="";
        engwtT1.Text = "";
        engwt1.Text = "";
        engwt2.Text ="";
        engrdtot.Value = "";
        engdicT1.Text = "";
        engdic1.Text = "";
        engdic2.Text = "";
        engdictot.Value ="";
        enghndwtT1.Text = "";
        enghndwt1.Text = "";
        enghndwt2.Text = "";
        enghndtot.Value = "";
        engltnT1.Text = "";
        engltn1.Text = "";
        engltn2.Text = "";
        engltntot.Value = "";
        engspkT1.Text = "";
        engspk1.Text = "";
        engspk2.Text = "";
        engspktot.Value = "";
        engwtstT1.Text = "";
        engwtst1.Text = "";
        engwtst2.Text = "";
        engwtsttot.Value ="";
        hinrdT1.Text = "";
        hinrd1.Text = "";
        hinrd2.Text = "";
        hinrdtot.Value ="";
        hinwtT1.Text = "";
        hinwt1.Text = "";
        hinwt2.Text = "";
        hinwttot.Value ="";
        hindicT1.Text = "";
        hindic1.Text = "";
        hindic2.Text = "";
        hindictot.Value ="";
        hinhndwtT1.Text = "";
        hinhndwt1.Text ="";
        hinhndwt2.Text = "";
        hinhndtot.Value = "";
        hinltnT1.Text = "";
        hinltn1.Text = "";
        hinltn2.Text = "";
        hinltntot.Value = "";
        hinspkT1.Text = "";
        hinspk1.Text = "";
        hinspk2.Text = "";
        hinspktot.Value = "";
        hinwtstT1.Text = "";
        hinwtst1.Text = "";
        hinwtst2.Text = "";
        hinwtsttot.Value = "";
        mathconT1.Text = "";
        mathcon1.Text = "";
        mathcon2.Text = "";
        mathcontot.Value = "";
        mathactT1.Text = "";
        mathact1.Text ="";
        mathact2.Text = "";
        mathacttot.Value = "";
        mathtabT1.Text = "";
        mathtab1.Text = "";
        mathtab2.Text = "";
        mathtabtot.Value = "";
        mathmabT1.Text = "";
        mathmab1.Text = "";
        mathmab2.Text = "";
        mathmabtot.Value = "";
        mathwtstT1.Text = "";
        mathwtst1.Text = "";
        mathwtst2.Text = "";
        mathwtsttot.Value = "";
        csaptT1.Text = "";
        csapt1.Text = "";
        csapt2.Text = "";
        csaptot.Value = "";
        cswtstT1.Text = "";
        cswtst1.Text = "";
        cswtst2.Text = "";
        cswtsttot.Value = "";
        essenT1.Text = "";

        essen1.Text = "";
        essen2.Text ="";
        essentot.Value = "";
        esprojT1.Text = "";
        esproj1.Text = "";
        esproj2.Text = "";
        esprojtot.Value = "";
        esgdT1.Text = "";
        esgd1.Text = "";
        esgd2.Text = "";
        esgdtot.Value = "";
        eswtstT1.Text = "";
        eswtst1.Text = "";
        eswtst2.Text ="";
        eswtsttot.Value = "";
        gkwtstT1.Text = "";
        gkwtst1.Text = "";
        gkwtst2.Text = "";
        gkwtsttot.Value = "";
        courtT1.Text = "";
        court1.Text = "";
        court2.Text = "";
        confT1.Text = "";
        conf1.Text = "";
        conf2.Text = "";
        carofT1.Text = "";
        carof1.Text = "";
        carof2.Text = "";
        neatT1.Text = "";
        neat1.Text = "";
        neat2.Text = "";
        rulT1.Text = "";
        rul1.Text = "";
        rul2.Text = "";
        initT1.Text = "";
        init1.Text = "";
        init2.Text = "";
        shrT1.Text = "";
        shr1.Text = "";
        shr2.Text ="";
        respT1.Text = "";
        resp1.Text ="";
        resp2.Text = "";
        sclrespT1.Text = "";
        sclresp1.Text = "";
        sclresp2.Text = "";
        slfconT1.Text = "";
        slfcon1.Text = "";
        slfcon2.Text = "";
        attndT1.Text = "";
        attnd1.Text ="";
        attnd2.Text = "";
        remark1.Text = "";
        remark.Text = "";
        attndT1.Text = "";
        attnd1.Text = "";
        attnd2.Text = "";
        weduT1.Text = "";
        wedu1.Text = "";
        wedu2.Text = "";
        artT1.Text = "";
        art1.Text = "";
        art2.Text = "";
        cftT1.Text = "";
        cft1.Text = "";
        cft2.Text = "";
        dncT1.Text = "";
        dnc1.Text = "";
        dnc2.Text = "";
        musicT1.Text = "";
        music1.Text = "";
        music2.Text = "";
        gamT1.Text = "";
        gam1.Text = "";
        gam2.Text = "";
        neatT1.Text = "";
        

         neat1.Text = "";
        neat2.Text = "";
        confT1.Text = "";
        conf1.Text = "";
        conf2.Text = "";
    
        remark.Text = "";
        attndT1.Text = "";
        attnd1.Text = "";
        attnd2.Text = "";
        wtT1.Text = "";
        wt1.Text = "";
        wt2.Text = "";
        hytT1.Text = "";
        hyt1.Text = "";
        hyt2.Text = "";
        //lblsession.Text = dr["sessionss"].ToString();
        ddlconduct.SelectedIndex = -1;
        promoteclass.Value = "";


        //lblsession.Text = "";
        ddlconduct.SelectedIndex = -1;
    }

   
    protected void btn_save_click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand(@"Insert into CLASS_I_II(name, class, sec, rollno, admissionno, fname, mname, bloodgrp, address, engrd1, engrd2, engrdtot,engwt1, engwt2, engwttot, engdic1, engdic2, engdictot,enghnd1, enghnd2, enghndtot,engltn1, engltn2,engltntot, engspk1,engspk2, engspktot,engwtst1,engwtst2,engwtsttot ,  hindird1, hindird2, hindirdtot,hindiwt1, hindiwt2, hindiwttot, hindidic1, hindidic2, hindidictot,hindihnd1, hindihnd2, hindihndtot,hindiltn1, hindiltn2,hindiltntot, hindispk1,hindispk2, hindispktot,hindiwtst1,hindiwtst2,hindiwtsttot , mathcon1, mathcon2, mathcontot,mathact1, mathact2,mathacttot, mathtab1, mathtab2,mathtabtot, mathmab1, mathmab2,mathmabtot, mathwtst1,mathwtst2, mathwtsttot, essen1,essen2,essentot,esproj1,esproj2,esprojtot,esgd1,esgd2,esgdtot,eswtst1,eswtst2,eswtsttot,gkwtst1, gkwtst2, gkwtsttot ,csapt1,csapt2,csaptot,cswtst1,cswtst2,cswtsttot, wt1, wt2, hyt1,hyt2,art1,art2,wrkedu1,wrkedu2,craft1,craft2,dnc1,dnc2,music1,music2,gam1,gam2,court1,court2,carof1,carof2,neat1,neat2,confdc1,confdc2, rul1,rul2,init1,init2,shr1,shr2,resp1,resp2,schresp1,schresp2,slfcon1,slfcon2,sessionss,conduct,promoteclass,dob,student_pic,tearemrk,attndnce1,attndnce2) 
                  values(@name, @class, @sec, @rollno, @admissionno, @fname, @mname, @bloodgrp, @address,  @engrd1, @engrd2, @engrdtot,@engwt1, @engwt2, @engwttot, @engdic1, @engdic2, @engdictot,@enghnd1, @enghnd2, @enghndtot,@engltn1, @engltn2,@engltntot, @engspk1,@engspk2, @engspktot,@engwtst1,@engwtst2,@engwtsttot , @hindird1, @hindird2, @hindirdtot,@hindiwt1, @hindiwt2, @hindiwttot, @hindidic1, @hindidic2, @hindidictot,@hindihnd1, @hindihnd2, @hindihndtot,@hindiltn1, @hindiltn2,@hindiltntot, @hindispk1,@hindispk2, @hindispktot,@hindiwtst1,@hindiwtst2,@hindiwtsttot , @mathcon1, @mathcon2, @mathcontot,@mathact1, @mathact2,@mathacttot, @mathtab1, @mathtab2,@mathtabtot, @mathmab1, @mathmab2,@mathmabtot, @mathwtst1,@mathwtst2, @mathwtsttot,@essen1,@essen2,@essentot,@esproj1,@esproj2,@esprojtot,@esgd1,@esgd2,@esgdtot,@eswtst1,@eswtst2,@eswtsttot,@gkwtst1, @gkwtst2, @gkwtsttot ,@csapt1,@csapt2,@csaptot,@cswtst1,@cswtst2,@cswtsttot, @wt1, @wt2, @hyt1,@hyt2,@art1,@art2,@wrkedu1,@wrkedu2,@craft1,@craft2,@dnc1,@dnc2,@music1,@music2,@gam1,@gam2,@court1,@court2,@carof1,@carof2,@neat1,@neat2,@confdc1,@confdc2, @rul1,@rul2,@init1,@init2,@shr1,@shr2,@resp1,@resp2,@sclresp1,@sclresp2,@slfcon1,@slfcon2,@sessionss,@conduct,@promoteclass,@dob,@student_pic,@tearemrk,@attndnce1,@attndnce2)", cs.connect());

        //cmd = new SqlCommand("Save_reportcard", cs.Connect());
        //cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@name", txtnam.Text.ToUpper());
        cmd.Parameters.AddWithValue("@class", txtclass.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sec", txtsection.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rollno", txtrollno.Text.ToUpper());
        cmd.Parameters.AddWithValue("@admissionno", txtadmsn.Text.ToUpper());
        cmd.Parameters.AddWithValue("@fname", txtfather.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mname", txtmother.Text.ToUpper());
        cmd.Parameters.AddWithValue("@bloodgrp", txtbloodgrp.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dob", txtdob.Text.ToUpper());
        cmd.Parameters.AddWithValue("@student_pic", txtstupic.Text);
        cmd.Parameters.AddWithValue("@address", txtaddrs.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrd1", engrdT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrd2", engrd2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrdtot", engrdtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engwt1", engwtT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engwt2", engwt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engwttot", engwttot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engdic1", engdicT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engdic2", engdic2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engdictot", engdictot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@enghnd1", enghndwtT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@enghnd2", enghndwt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@enghndtot", enghndtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engltn1", engltnT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engltn2", engltn2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engltntot", engltntot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engspk1", engspkT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engspk2", engspk2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engspktot", engspktot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engwtst1", engwtstT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engwtst2", engwtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engwtsttot", engwtsttot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindird1", hinrdT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindird2", hinrd2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindirdtot", hinrdtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwt1", hinwtT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwt2", hinwt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwttot", hinwttot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindidic1", hindicT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindidic2", hindic2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindidictot", hindictot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindihnd1", hinhndwtT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindihnd2", hinhndwt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindihndtot", hinhndtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiltn1", hinltnT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiltn2", hinltn2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiltntot", hinltntot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindispk1", hinspkT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindispk2", hinspk2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindispktot", hinspktot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwtst1", hinwtstT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwtst2", hinwtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwtsttot", hinwtsttot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathcon1", mathconT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathcon2", mathcon2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathcontot", mathcontot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathact1", mathactT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathact2", mathact2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathacttot", mathacttot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathtab1", mathtabT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathtab2", mathtab2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathtabtot", mathtabtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathmab1", mathmabT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathmab2", mathmab2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathmabtot", mathmabtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathwtst1", mathwtstT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathwtst2", mathwtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathwtsttot", mathwtsttot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@csapt1", csaptT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@csapt2", csapt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@csaptot", csaptot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cswtst1", cswtstT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@cswtst2", cswtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@cswtsttot", cswtsttot.Value.ToUpper());
        
        cmd.Parameters.AddWithValue("@gkwtst1", gkwtstT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkwtst2", gkwtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkwtsttot", gkwtsttot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@essen1", essenT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@essen2", essen2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@essentot", essentot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@esproj1", esprojT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esproj2", esproj2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esprojtot", esprojtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@esgd1", esgdT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esgd2", esgd2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esgdtot", esgdtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@eswtst1", eswtstT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@eswtst2", eswtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@eswtsttot", eswtsttot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@wrkedu1", weduT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@wrkedu2", wedu2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@art1", artT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@art2", art2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@craft1", cftT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@craft2", cft2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dnc1", dncT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dnc2", dnc2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@music1", musicT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@music2", music2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gam1", gamT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gam2", gam2.Text.ToUpper());


        cmd.Parameters.AddWithValue("@court1", courtT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@court2", court2.Text.ToUpper());        
        cmd.Parameters.AddWithValue("@confdc1", confT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@confdc2", conf2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@carof1", carofT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@carof2", carof2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@neat1", neatT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@neat2", neat2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rul1", rulT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rul2", rul2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@init1", initT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@init2", init2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@shr1", shrT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@shr2", shr2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@resp1", respT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@resp2", resp2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sclresp1", sclrespT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sclresp2", sclresp2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@slfcon1", slfconT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@slfcon2", slfcon2.Text.ToUpper());

      
        cmd.Parameters.AddWithValue("@attndnce1", attndT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@attndnce2", attnd2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@wt1", wtT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@wt2", wt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hyt1", hytT1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hyt2", hyt2.Text.ToUpper());

        if (DropDownList1.Text == "Term-I")
        {
            cmd.Parameters.AddWithValue("@tearemrk", remark1.Text.ToUpper());
            cmd.Parameters.AddWithValue("@conduct", ddlconductT1.SelectedItem.Text.ToUpper());

        }


        else
        {
            cmd.Parameters.AddWithValue("@tearemrk", remark.Text.ToUpper());
            cmd.Parameters.AddWithValue("@conduct", ddlconduct.SelectedItem.Text.ToUpper());

        }


        //cmd.Parameters.AddWithValue("@tearemrk", remark.Text.ToUpper());


        cmd.Parameters.AddWithValue("@sessionss", lblsession.Text);
        //cmd.Parameters.AddWithValue("@conduct", ddlconduct.SelectedItem.Text.ToUpper());

        cmd.Parameters.AddWithValue("@promoteclass", promoteclass.Value.ToUpper());

        cmd.ExecuteNonQuery();

        //Response.Write("<script>alert('You Have Successfully Saved Marks !!!')</script>");



        try
        {
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cs.exec_qry("Delete from CLASS_I_II where id not in(select max(id) from CLASS_I_II group by name, class, sec, rollno, admissionno, fname, mname, bloodgrp, sessionss)");//Remove All Duplicates Entries From (this) Table 
                Response.Write("<script>alert('You Have Successfully Saved Marks !!!')</script>");
               Session["admsnno"] = txtadmsn.Text.ToUpper();
               Session["Term"] = DropDownList1.SelectedItem.Text.ToUpper();
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.success('Marks Saved Successfully of " + txtnam.Text.ToUpper() + "')", true);

               if (DropDownList1.Text == "Term-I")
               {
                   Response.Write("<script>");
                   Response.Write("window.open('class1-2 term1result.aspx?sessions=" + lblsession.Text + "','_blank')");
                   Response.Write("</script>");
                   clrfld();
               }

               if (DropDownList1.Text == "Term-II")                                                                                                                                                                                                                                                                                                                                                         
               {

                   Response.Write("<script>");
                   Response.Write("window.open('SampleResult_I_II.aspx?sessions=" + lblsession.Text + "','_blank')");
                   Response.Write("</script>");
                   clrfld();
               }

            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Something Went Wrong.. " + ex + "')", true);
        }

    }

    protected void txt_rno_TextChanged(object sender, EventArgs e)
    {

        bool temp = false;
        string connStr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        con.Open();
        SqlCommand cmd = new SqlCommand("select * from CLASS_I_II where rollno='" + txtrollno.Text.Trim() + "' and class='" + txtclass.Text + "'and sec='" + txtsection.Text + "'and sessionss='" + lblsession.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            txtnam.Text = dr["name"].ToString();
            txtfather.Text = dr["fname"].ToString();
            txtmother.Text = dr["mname"].ToString();
            txtaddrs.Text = dr["address"].ToString();
            txtadmsn.Text = dr["admissionno"].ToString();
            txtsection.Text = dr["sec"].ToString();
            txtclass.Text = dr["class"].ToString();
            txtbloodgrp.Text = dr["bloodgrp"].ToString();
            txtdob.Text = dr["dob"].ToString();
            txtstupic.Text = dr["student_pic"].ToString();
            engrdT1.Text = dr["engrd1"].ToString();        
            engrd1.Text = dr["engrd1"].ToString();
            engrd2.Text = dr["engrd2"].ToString();
            engrdtot.Value = dr["engrdtot"].ToString();
            engwtT1.Text = dr["engwt1"].ToString();
            engwt1.Text = dr["engwt1"].ToString();
            engwt2.Text = dr["engwt2"].ToString();
            engwttot.Value = dr["engwttot"].ToString();
           // engrdtot.Value = dr["engrdtot"].ToString();
            engdicT1.Text = dr["engdic1"].ToString();
            engdic1.Text = dr["engdic1"].ToString();
            engdic2.Text = dr["engdic2"].ToString();
            engdictot.Value = dr["engdictot"].ToString();
            enghndwtT1.Text = dr["enghnd1"].ToString();
            enghndwt1.Text = dr["enghnd1"].ToString();
            enghndwt2.Text = dr["enghnd2"].ToString();
            enghndtot.Value = dr["enghndtot"].ToString();
            engltnT1.Text = dr["engltn1"].ToString();
            engltn1.Text = dr["engltn1"].ToString();
            engltn2.Text = dr["engltn2"].ToString();
            engltntot.Value = dr["engltntot"].ToString();
            engspkT1.Text = dr["engspk1"].ToString();
            engspk1.Text = dr["engspk1"].ToString();
            engspk2.Text = dr["engspk2"].ToString();
            engspktot.Value = dr["engspktot"].ToString();
            engwtstT1.Text = dr["engwtst1"].ToString();
            engwtst1.Text = dr["engwtst1"].ToString();
            engwtst2.Text = dr["engwtst2"].ToString();
            engwtsttot.Value = dr["engwtsttot"].ToString();
            hinrdT1.Text = dr["hindird1"].ToString();
            hinrd1.Text = dr["hindird1"].ToString();
            hinrd2.Text = dr["hindird2"].ToString();
            hinrdtot.Value = dr["hindirdtot"].ToString();
            hinwtT1.Text = dr["hindiwt1"].ToString();
            hinwt1.Text = dr["hindiwt1"].ToString();
            hinwt2.Text = dr["hindiwt2"].ToString();
            hinwttot.Value = dr["hindiwttot"].ToString();
            hindicT1.Text = dr["hindidic1"].ToString();
            hindic1.Text = dr["hindidic1"].ToString();
            hindic2.Text = dr["hindidic2"].ToString();
            hindictot.Value = dr["hindidictot"].ToString();
            hinhndwtT1.Text = dr["hindihnd1"].ToString();
            hinhndwt1.Text = dr["hindihnd1"].ToString();
            hinhndwt2.Text = dr["hindihnd2"].ToString();
            hinhndtot.Value = dr["hindihndtot"].ToString();
            hinltnT1.Text = dr["hindiltn1"].ToString();
            hinltn1.Text = dr["hindiltn1"].ToString();
            hinltn2.Text = dr["hindiltn2"].ToString();
            hinltntot.Value = dr["hindiltntot"].ToString();
            hinspkT1.Text = dr["hindispk1"].ToString();
            hinspk1.Text = dr["hindispk1"].ToString();
            hinspk2.Text = dr["hindispk2"].ToString();
            hinspktot.Value = dr["hindispktot"].ToString();
            hinwtstT1.Text = dr["hindiwtst1"].ToString();
            hinwtst1.Text = dr["hindiwtst1"].ToString();
            hinwtst2.Text = dr["hindiwtst2"].ToString();
            hinwtsttot.Value = dr["hindiwtsttot"].ToString();
            mathconT1.Text = dr["mathcon1"].ToString();
            mathcon1.Text = dr["mathcon1"].ToString();
            mathcon2.Text = dr["mathcon2"].ToString();
            mathcontot.Value = dr["mathcontot"].ToString();
            mathactT1.Text = dr["mathact1"].ToString();
            mathact1.Text = dr["mathact1"].ToString();
            mathact2.Text = dr["mathact2"].ToString();
            mathacttot.Value = dr["mathacttot"].ToString();
            mathtabT1.Text = dr["mathtab1"].ToString();
            mathtab1.Text = dr["mathtab1"].ToString();
            mathtab2.Text = dr["mathtab2"].ToString();
            mathtabtot.Value = dr["mathtabtot"].ToString();
            mathmabT1.Text = dr["mathmab1"].ToString();
            mathmab1.Text = dr["mathmab1"].ToString();
            mathmab2.Text = dr["mathmab2"].ToString();
            mathmabtot.Value = dr["mathmabtot"].ToString();
            mathwtstT1.Text = dr["mathwtst1"].ToString();
            mathwtst1.Text = dr["mathwtst1"].ToString();
            mathwtst2.Text = dr["mathwtst2"].ToString();
            mathwtsttot.Value = dr["mathwtsttot"].ToString();
            csaptT1.Text = dr["csapt1"].ToString();
            csapt1.Text = dr["csapt1"].ToString();
            csapt2.Text = dr["csapt2"].ToString();
            csaptot.Value = dr["csaptot"].ToString();
            cswtstT1.Text = dr["cswtst1"].ToString();
            cswtst1.Text = dr["cswtst1"].ToString();
            cswtst2.Text = dr["cswtst2"].ToString();
            cswtsttot.Value = dr["cswtsttot"].ToString();
            essenT1.Text = dr["essen1"].ToString();
            essen1.Text = dr["essen1"].ToString();
            essen2.Text = dr["essen2"].ToString();
            essentot.Value = dr["essentot"].ToString();
            esprojT1.Text = dr["esproj1"].ToString();
            esproj1.Text = dr["esproj1"].ToString();
            esproj2.Text = dr["esproj2"].ToString();
            esprojtot.Value = dr["esprojtot"].ToString();
            esgdT1.Text = dr["esgd1"].ToString();
            esgd1.Text = dr["esgd1"].ToString();
            esgd2.Text = dr["esgd2"].ToString();
            esgdtot.Value = dr["esgdtot"].ToString();
            eswtstT1.Text = dr["eswtst1"].ToString();
            eswtst1.Text = dr["eswtst1"].ToString();
            eswtst2.Text = dr["eswtst2"].ToString();
            eswtsttot.Value = dr["eswtsttot"].ToString();
            gkwtstT1.Text = dr["gkwtst1"].ToString();
            gkwtst1.Text = dr["gkwtst1"].ToString();
            gkwtst2.Text = dr["gkwtst2"].ToString();
            gkwtsttot.Value = dr["gkwtsttot"].ToString();
            courtT1.Text = dr["court1"].ToString();
            court1.Text = dr["court1"].ToString();
            court2.Text = dr["court2"].ToString();
            confT1.Text = dr["confdc1"].ToString();
            conf1.Text = dr["confdc1"].ToString();
            conf2.Text = dr["confdc2"].ToString();
            carofT1.Text = dr["carof1"].ToString();
            carof1.Text = dr["carof1"].ToString();
            carof2.Text = dr["carof2"].ToString();
            neatT1.Text = dr["neat1"].ToString();
            neat1.Text = dr["neat1"].ToString();
            neat2.Text = dr["neat2"].ToString();
            rulT1.Text = dr["rul1"].ToString();
            rul1.Text = dr["rul1"].ToString();
            rul2.Text = dr["rul2"].ToString();
            initT1.Text = dr["init1"].ToString();
            init1.Text = dr["init1"].ToString();
            init2.Text = dr["init2"].ToString();
            shrT1.Text = dr["shr1"].ToString();
            shr1.Text = dr["shr1"].ToString();
            shr2.Text = dr["shr2"].ToString();
            respT1.Text = dr["resp1"].ToString();
            resp1.Text = dr["resp1"].ToString();
            resp2.Text = dr["resp2"].ToString();
            sclrespT1.Text = dr["schresp1"].ToString();
            sclresp1.Text = dr["schresp1"].ToString();
            sclresp2.Text = dr["schresp2"].ToString();
            slfconT1.Text = dr["slfcon1"].ToString();
            slfcon1.Text = dr["slfcon1"].ToString();
            slfcon2.Text = dr["slfcon2"].ToString();
            attndT1.Text = dr["attndnce1"].ToString();
            attnd1.Text = dr["attndnce1"].ToString();
            attnd2.Text = dr["attndnce2"].ToString();
            remark1.Text = dr["tearemrk"].ToString();
            remark.Text = dr["tearemrk"].ToString();
            attndT1.Text = dr["attndnce1"].ToString();
            attnd1.Text = dr["attndnce1"].ToString();
            attnd2.Text = dr["attndnce2"].ToString();
            weduT1.Text = dr["wrkedu1"].ToString();
            wedu1.Text = dr["wrkedu1"].ToString();
            wedu2.Text = dr["wrkedu2"].ToString();
            artT1.Text = dr["art1"].ToString();
            art1.Text = dr["art1"].ToString();
            art2.Text = dr["art2"].ToString();
            cftT1.Text = dr["craft1"].ToString();
            cft1.Text = dr["craft1"].ToString();
            cft2.Text = dr["craft2"].ToString();
            dncT1.Text = dr["dnc1"].ToString();
            dnc1.Text = dr["dnc1"].ToString();
            dnc2.Text = dr["dnc2"].ToString();
            musicT1.Text = dr["music1"].ToString();
            music1.Text = dr["music1"].ToString();
            music2.Text = dr["music2"].ToString();
            gamT1.Text = dr["gam1"].ToString();
            gam1.Text = dr["gam1"].ToString();
            gam2.Text = dr["gam2"].ToString();
            wtT1.Text = dr["wt1"].ToString();
            wt1.Text = dr["wt1"].ToString();
            wt2.Text = dr["wt2"].ToString();
            hytT1.Text = dr["hyt1"].ToString();
            hyt1.Text = dr["hyt1"].ToString();
            hyt2.Text = dr["hyt2"].ToString();
            
            ddlconduct.SelectedItem.Text = dr["conduct"].ToString();
            ddlconductT1.SelectedItem.Text = dr["conduct"].ToString();
            promoteclass.Value = dr["promoteclass"].ToString();

            temp = true;
        }
        if (temp == false)
        {
            string connStr1 = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con1 = new SqlConnection(connStr1);
            con1.Open();
            SqlCommand com = new SqlCommand("select * from tbl_sturegister where rollno='" + txtrollno.Text.Trim() + "' and class_nm='" + txtclass.Text + "'  and section='" + txtsection.Text + "'and sesnm='" + lblsession.Text + "'", con1);
            SqlDataReader drr = com.ExecuteReader();
            while (drr.Read())
            {
                
                txtnam.Text = drr["fullname"].ToString();
                txtfather.Text = drr["fname"].ToString();
                txtmother.Text = drr["mname"].ToString();
                txtaddrs.Text = drr["addrss"].ToString();
                txtadmsn.Text = drr["admissionno"].ToString();
                txtbloodgrp.Text = drr["bloodgrp"].ToString();
                txtdob.Text = (drr["dob"]).ToString();
                txtstupic.Text = drr["st_img"].ToString();
                temp = true;
                //con.Close();
            }
            //MessageBox.Show("not found");
            con.Close();

        }
        if (temp == false)
        {
            Response.Write("<script>alert('There Is No Such Kind Of Roll No. Exist !!!')</script>");
            //con.Close();

        }

    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.Text == "Term-I")
        {
            wrapperOne.Visible = true;
            wrapperTwo.Visible = false;
             engrd2.Enabled = false;
             engwt2.Enabled = false;
            engdic2.Enabled = false;
          enghndwt2.Enabled = false;
            engltn2.Enabled = false;
            engspk2.Enabled = false;
           engwtst2.Enabled = false;
           mathcon2.Enabled = false;
           mathact2.Enabled = false;
           mathtab2.Enabled = false;
           mathmab2.Enabled = false;
          mathwtst2.Enabled = false;
             csapt2.Enabled = false;
            cswtst2.Enabled = false;
             hinrd2.Enabled = false;
             hinwt2.Enabled = false;
            hindic2.Enabled = false;
          hinhndwt2.Enabled = false;
            hinltn2.Enabled = false;
            hinspk2.Enabled = false;
           hinwtst2.Enabled = false;
             essen2.Enabled = false;
            esproj2.Enabled = false;
              esgd2.Enabled = false;
            eswtst2.Enabled = false;
            gkwtst2.Enabled = false;
              wedu2.Enabled = false;
               art2.Enabled = false;
               cft2.Enabled = false;
               dnc2.Enabled = false;
             music2.Enabled = false;
               gam2.Enabled = false;
             attnd2.Enabled = false;
               hyt2.Enabled = false;
                wt2.Enabled = false;
             court2.Enabled = false;
              conf2.Enabled = false;
                wt2.Enabled = false;
             carof2.Enabled = false;
              neat2.Enabled = false;
               rul2.Enabled = false;
              init2.Enabled = false;
               shr2.Enabled = false;
              resp2.Enabled = false;
           sclresp2.Enabled = false;
            slfcon2.Enabled = false;
               engrd1.Enabled = true;
               engwt1.Enabled = true;
              engdic1.Enabled = true;
            enghndwt1.Enabled = true;
              engltn1.Enabled = true;
              engspk1.Enabled = true;
             engwtst1.Enabled = true;
             mathcon1.Enabled = true;
             mathact1.Enabled = true;
             mathtab1.Enabled = true;
             mathmab1.Enabled = true;
            mathwtst1.Enabled = true;
               csapt1.Enabled = true;
              cswtst1.Enabled = true;
               hinrd1.Enabled = true;
               hinwt1.Enabled = true;
              hindic1.Enabled = true;
            hinhndwt1.Enabled = true;
              hinltn1.Enabled = true;
              hinspk1.Enabled = true;
             hinwtst1.Enabled = true;
               essen1.Enabled = true;
              esproj1.Enabled = true;
                esgd1.Enabled = true;
              eswtst1.Enabled = true;
              gkwtst1.Enabled = true;
                wedu1.Enabled = true;
                 art1.Enabled = true;
                 cft1.Enabled = true;
                 dnc1.Enabled = true;
               music1.Enabled = true;
                 gam1.Enabled = true;
               attnd1.Enabled = true;
                 hyt1.Enabled = true;
                  wt1.Enabled = true;
               court1.Enabled = true;
                conf1.Enabled = true;
                  wt1.Enabled = true;
                carof1.Enabled = true;
                 neat1.Enabled = true;
                  rul1.Enabled = true;
                 init1.Enabled = true;
                  shr1.Enabled = true;
                 resp1.Enabled = true;
              sclresp1.Enabled = true;
               slfcon1.Enabled = true;
        }

        if (DropDownList1.Text == "Term-II")
        {
            wrapperTwo.Visible = true;
            wrapperOne.Visible = false;
             engrd2.Enabled = true;
             engwt2.Enabled = true;
            engdic2.Enabled = true;
          enghndwt2.Enabled = true;
            engltn2.Enabled = true;
            engspk2.Enabled = true;
           engwtst2.Enabled = true;
           mathcon2.Enabled = true;
           mathact2.Enabled = true;
           mathtab2.Enabled = true;
           mathmab2.Enabled = true;
          mathwtst2.Enabled = true;
             csapt2.Enabled = true;
            cswtst2.Enabled = true;
             hinrd2.Enabled = true;
             hinwt2.Enabled = true;
            hindic2.Enabled = true;
          hinhndwt2.Enabled = true;
            hinltn2.Enabled = true;
            hinspk2.Enabled = true;
           hinwtst2.Enabled = true;
             essen2.Enabled = true;
            esproj2.Enabled = true;
              esgd2.Enabled = true;
            eswtst2.Enabled = true;
            gkwtst2.Enabled = true;
              wedu2.Enabled = true;
               art2.Enabled = true;
               cft2.Enabled = true;
               dnc2.Enabled = true;
             music2.Enabled = true;
               gam2.Enabled = true;
             attnd2.Enabled = true;
               hyt2.Enabled = true;
                wt2.Enabled = true;
             court2.Enabled = true;
              conf2.Enabled = true;
                wt2.Enabled = true;
             carof2.Enabled = true;
              neat2.Enabled = true;
               rul2.Enabled = true;
              init2.Enabled = true;
               shr2.Enabled = true;
              resp2.Enabled = true;
           sclresp2.Enabled = true;
            slfcon2.Enabled = true;

             engrd1.Enabled = false;
             engwt1.Enabled = false;
            engdic1.Enabled = false;
          enghndwt1.Enabled = false;
            engltn1.Enabled = false;
            engspk1.Enabled = false;
           engwtst1.Enabled = false;
           mathcon1.Enabled = false;
           mathact1.Enabled = false;
           mathtab1.Enabled = false;
           mathmab1.Enabled = false;
          mathwtst1.Enabled = false;
             csapt1.Enabled = false;
            cswtst1.Enabled = false;
             hinrd1.Enabled = false;
             hinwt1.Enabled = false;
            hindic1.Enabled = false;
          hinhndwt1.Enabled = false;
            hinltn1.Enabled = false;
            hinspk1.Enabled = false;
           hinwtst1.Enabled = false;
             essen1.Enabled = false;
            esproj1.Enabled = false;
              esgd1.Enabled = false;
            eswtst1.Enabled = false;
            gkwtst1.Enabled = false;
              wedu1.Enabled = false;
               art1.Enabled = false;
               cft1.Enabled = false;
               dnc1.Enabled = false;
             music1.Enabled = false;
               gam1.Enabled = false;
             attnd1.Enabled = false;
               hyt1.Enabled = false;
                wt1.Enabled = false;
             court1.Enabled = false;
              conf1.Enabled = false;
                wt1.Enabled = false;
             carof1.Enabled = false;
              neat1.Enabled = false;
               rul1.Enabled = false;
              init1.Enabled = false;
               shr1.Enabled = false;
              resp1.Enabled = false;
           sclresp1.Enabled = false;
            slfcon1.Enabled = false;
        }

    }

}


