﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data.Sql;

public partial class login1_StudentReg : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt;
    SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["constring"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["alogin"] != null)
        {

            if (!IsPostBack)
            {



                bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
                bd.bind_dropdown(ddlses, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
                bd.bind_dropdown(ddlclass, "select * from tbl_class  order by class_value asc", "class_nm", "class_value");
                bd.bind_dropdown(ddlsection, "select * from tbl_section order by section_value asc", "section_nm", "id");

                Session["session"] = ddlsession.SelectedItem;
                string sec = ddlsection.SelectedItem.Value.ToString();
                bd.bind_grid(grd, "select * from tbl_sturegister");



            }
            else
            {
            }
        }

        else
        {

            Response.Redirect("~/index.aspx");

        } 
           
    }

    protected void search_Click(object sender, EventArgs e)
    {

        //Response.Write("<script>alert('" + ddlsession.SelectedItem.Text + "')</script>");
        //bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
        bd.bind_grid(grd, "select * from tbl_sturegister where sesnm='" + ddlses.SelectedItem.Text + "' AND (rollno LIKE '%" + TextBox1.Text + "%'  OR admissionno LIKE '%" + TextBox1.Text + "%' OR section LIKE'%" + TextBox1.Text + "%' OR class_nm LIKE'%" + TextBox1.Text + "%' OR fullname LIKE'%" + TextBox1.Text + "%')");


    }

    public void clear()
    {

        txtadmsn.Text = "";
        txtmob.Text = "";
        txtfather.Text = "";
        txtrollno.Text = "";
        txtmother.Text = "";
        txtnam.Text = "";
        ddlclass.SelectedValue = "-1";
        txtbloodgrp.Text = "";
        ddlsection.SelectedValue = "-1";
        ddlsession.SelectedValue = "-1";
        txtaddrs.Text = "";
        txtdob.Text = "";
    }
    protected void grd_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        grd.PageIndex = e.NewPageIndex;
        bd.bind_grid(grd, "select * from tbl_sturegister");


    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "edit")
        {

            SqlCommand cmd = new SqlCommand("select * from tbl_sturegister where id='" + e.CommandArgument + "'", cs.connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                //Label1.Visible = false;
               // Label7.Visible = false;
                stupic.Visible = false;
                txtadmsn.ReadOnly = true;
                //txtdob.Visible = false;
                txtnam.Text = dt.Rows[0]["fullname"].ToString();
                ddlsession.SelectedItem.Text = dt.Rows[0]["sesnm"].ToString();
                ddlclass.SelectedItem.Text = dt.Rows[0]["class_nm"].ToString();
                ddlsection.SelectedItem.Text = dt.Rows[0]["section"].ToString();
                txtfather.Text = dt.Rows[0]["fname"].ToString();
                txtmother.Text = dt.Rows[0]["mname"].ToString();
                //txtdob.Text = ((DateTime)dt.Rows[0]["dob"]).ToString("dd/MM/yyyy");
                roll.Visible = true;
                txtrollno.Text = dt.Rows[0]["rollno"].ToString();
                txtbloodgrp.Text = dt.Rows[0]["bloodgrp"].ToString();
                txtmob.Text = dt.Rows[0]["smobile"].ToString();
                txtdob.Text = dt.Rows[0]["dob"].ToString();
                txtadmsn.Text = dt.Rows[0]["admissionno"].ToString();

                //txtadhar.Text = dt.Rows[0]["adharno"].ToString();
                txtaddrs.Text = dt.Rows[0]["addrss"].ToString();

            }
            ViewState["eid"] = e.CommandArgument;
            bd.bind_grid(grd, "select * from tbl_sturegister");
            Button5.Text = "Update";

        }
        else if (e.CommandName == "delete")
        {
            cs.exec_qry("delete from tbl_sturegister where id='" + e.CommandArgument + "'");

            bd.bind_grid(grd, "select * from tbl_sturegister");

        }
        else
        {





        }
    }
    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //  bd.bind_grid(grd, "select * from tbl_sturegister");
    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void Button5_Click1(object sender, EventArgs e)
    {
        string img = "";
        if (Button5.Text == "Submit")
        {

            SqlCommand cmd2 = new SqlCommand("select count(rollno) from tbl_sturegister where sesnm = '" + ddlsession.SelectedItem.Text + "' AND class_nm = '" + ddlclass.SelectedItem.Text + "' AND Section = '" + ddlsection.SelectedItem.Text + "'", con);
            con.Open();
            int n = Convert.ToInt32(cmd2.ExecuteScalar());

            dt = bd.fill_datatable("select * from tbl_sturegister where admissionno='" + txtadmsn.Text + "' order by id desc");
            if (dt.Rows.Count>0)
            {
                Response.Write("<script>alert('This Admissionno is Allready Exict')</script>");
                return;
            }     
           
            SqlCommand cmd = new SqlCommand("sp_sturegister", cs.connect());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@fullname", txtnam.Text);
            cmd.Parameters.AddWithValue("@sesnm", ddlsession.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@class_nm", ddlclass.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@section", ddlsection.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@fname", txtfather.Text);
            cmd.Parameters.AddWithValue("@mname", txtmother.Text);
            cmd.Parameters.AddWithValue("@admissionno", txtadmsn.Text);
            cmd.Parameters.AddWithValue("@rollno", n+1);
            cmd.Parameters.AddWithValue("@smobile", txtmob.Text);
            cmd.Parameters.AddWithValue("@fmobileno", txtmob.Text);
            cmd.Parameters.AddWithValue("@bloodgrp", txtbloodgrp.Text);
          //  cmd.Parameters.AddWithValue("@st_img", img);
            //cmd.Parameters.AddWithValue("@adharno", txtadhar.Text);
            cmd.Parameters.AddWithValue("@stream", string.Empty);
            cmd.Parameters.AddWithValue("@dob", txtdob.Text);
            cmd.Parameters.AddWithValue("@addrss", txtaddrs.Text);
            cmd.ExecuteNonQuery();
            clear();
            bd.bind_grid(grd, "select * from tbl_sturegister");
        }
        else
        {

            //dt = bd.fill_datatable("select * from tbl_sturegister where admissionno='" + txtadmsn.Text + "' order by id desc");
            //if (dt.Rows.Count > 0)
            //{
            //    Response.Write("<script>alert('This Admissionno is Allready Exict yasar')</script>");
            //    return;
            //}  

            SqlCommand cmd2 = new SqlCommand("select count(rollno) from tbl_sturegister where sesnm = '" + ddlsession.SelectedItem.Text + "' AND class_nm = '" + ddlclass.SelectedItem.Text + "' AND Section = '" + ddlsection.SelectedItem.Text + "'", con);
            con.Open();
            int n = Convert.ToInt32(cmd2.ExecuteScalar());
            SqlCommand cmd3 = new SqlCommand("select count(rollno) from tbl_sturegister where sesnm = '" + ddlsession.SelectedItem.Text + "' AND class_nm = '" + ddlclass.SelectedItem.Text + "' AND Section = '" + ddlsection.SelectedItem.Text + "'", con);
            int na = Convert.ToInt32(cmd2.ExecuteScalar());

            cs.exec_qry("update tbl_sturegister set fullname='" + txtnam.Text + "',sesnm='" + ddlsession.SelectedItem.Text + "',class_nm='" + ddlclass.SelectedItem.Text + "',section='" + ddlsection.SelectedItem.Text + "',fname='" + txtfather.Text + "',mname='" + txtmother.Text + "',dob='" + txtdob.Text + "',smobile='" + txtmob.Text + "',bloodgrp='" + txtbloodgrp.Text + "', rollno='" + txtrollno.Text + "',addrss='" + txtaddrs.Text + "' where id = '" + ViewState["eid"] + "'");
            Button5.Text = "Submit";
            bd.bind_grid(grd, "select * from tbl_sturegister");

            Response.Redirect("../login1/StudentReg.aspx");


        }
    }
}