﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_TeacherRegistration : System.Web.UI.Page
{
     connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["alogin"] != null)
        {
            if (!IsPostBack)
            {

                getclass();
                bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "session_val");
                bd.bind_grid(grd, "select id,fullname,mobile,panno,clas,gender,userid,paswrd, (select session_nm from tbl_session where tbl_session.session_val = tbl_regteacher.session_id) as session_nm  from tbl_regteacher");


            }


        }
        else
        {

            Response.Redirect("~/index.aspx");

        }
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        string userid = "";
        string pass = "";
        string swclass = "";

        string alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        string small_alphabets = "abcdefghijklmnopqrstuvwxyz";
        string numbers = "1234567890";

        string characters = numbers;

        characters += alphabets + small_alphabets + numbers;

        double length = 8;
        string otp = string.Empty;
        for (double i = 0; i < length; i++)
        {
            string character = string.Empty;
            do
            {
                int index = new Random().Next(0, characters.Length);
                character = characters.ToCharArray()[index].ToString();
            } while (otp.IndexOf(character) != -1);
            otp += character;
        }
        pass = otp;

        Random r = new Random();
        int n = r.Next(111111, 999999);
        userid = "TGS" + n.ToString();

        for (int i = 0; i < cblclass.Items.Count; i++)
        {

            if (cblclass.Items[i].Selected)
            {

                swclass += cblclass.Items[i].Value + ",";

            }

        }
        swclass = swclass.TrimEnd(',');

        if (Button5.Text == "Submit")
        {
            cs.exec_qry("insert into tbl_regteacher values('" + ddlsession.SelectedValue + "','" + TextBox1.Text + "','" + TextBox3.Text + "','" + TextBox2.Text + "','" + swclass + "','" + DropDownList1.SelectedItem.Text + "','true','" + userid + "','" + pass + "')");

        }
        else
        {

            cs.exec_qry("update tbl_regteacher set session_id = '" + ddlsession.SelectedValue + "',fullname = '" + TextBox1.Text + "',mobile = '" + TextBox3.Text + "',panno = '" + TextBox2.Text + "',clas = '" + swclass + "',gender= '" + DropDownList1.SelectedItem.Text + "' where id = '" + ViewState["eid"] + "' ");

            Response.Write("<script>alert('You Have Updated Details Successfully')</script>");
            Button5.Text = "Submit";

        }



        Response.Redirect("TeacherRegistration.aspx");
    }
    public void getclass()
    {

        SqlCommand cmd = new SqlCommand("select class_nm,class_value from tbl_class order by class_value asc", cs.connect());
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            cblclass.DataSource = dt;
            cblclass.DataTextField = "class_nm";
            cblclass.DataValueField = "class_value";
            cblclass.DataBind();


        }

    }
    protected void grd_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grd.PageIndex = e.NewPageIndex;
        bd.bind_grid(grd, "select id,fullname,mobile,panno,clas,gender,userid,paswrd, (select session_nm from tbl_session where tbl_session.session_val = tbl_regteacher.session_id) as session_nm  from tbl_regteacher");

    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "edit")
        {

            SqlCommand cmd = new SqlCommand("select * from tbl_regteacher where id='" + e.CommandArgument + "'", cs.connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                ddlsession.SelectedValue = dt.Rows[0]["session_id"].ToString();
                TextBox1.Text = dt.Rows[0]["fullname"].ToString();
                TextBox3.Text = dt.Rows[0]["mobile"].ToString();
                TextBox2.Text = dt.Rows[0]["panno"].ToString();
                DropDownList1.SelectedItem.Text = dt.Rows[0]["gender"].ToString();
                string str = dt.Rows[0]["clas"].ToString();
                string[] strlist = str.Split(','); //Split into array and trim it.

                foreach (ListItem lst in cblclass.Items)
                {
                    for (int i = 0; i <= strlist.Length - 1; i++)
                    {
                        if (lst.Value == strlist[i])
                        {
                            lst.Selected = true;
                            break;
                        }
                    }
                }
                ViewState["eid"] = e.CommandArgument;
                Button5.Text = "Update";
                bd.bind_grid(grd, "select id,fullname,mobile,panno,clas,gender,userid,paswrd, (select session_nm from tbl_session where tbl_session.session_val = tbl_regteacher.session_id) as session_nm  from tbl_regteacher");


            }

        }
        else if (e.CommandName == "delete")
        {


            cs.exec_qry("delete from tbl_regteacher where id='" + e.CommandArgument + "'");
            Response.Write("<script>alert('You Have Deleted Details Successfully')</script>");
            bd.bind_grid(grd, "select id,fullname,mobile,panno,clas,gender,userid,paswrd, (select session_nm from tbl_session where tbl_session.session_val = tbl_regteacher.session_id) as session_nm  from tbl_regteacher");



        }
        else
        {



        }

    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }


   
   
}