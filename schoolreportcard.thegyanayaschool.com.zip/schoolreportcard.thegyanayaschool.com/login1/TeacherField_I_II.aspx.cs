﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_TeacherField_I_II : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblsession.Text = Request.QueryString["session"].ToString();
        if (!IsPostBack)
        {
            //divtotalmarks.Visible = false;
            // divgrade.Visible = false;
            // divattendence.Visible = false;
            //TextBox2.Text = classs + "(" + section + ")";
            t1row.Visible = true;
            t2row.Visible = true;
            englishrow.Visible = true;
            hindirow.Visible = true;
            mathsrow.Visible =  true;
            csrow.Visible = true;
            //computerrow.Visible = false;
            // evsrow.Visible = false;
            esrow.Visible = true;
            //drawrow.Visible = false;
            gkrow.Visible = true;
            scholarrow.Visible = true;
           // attendance.Visible = false;
            remrkrow.Visible = true;
            string subjects = Request.QueryString["subjects"].ToString();

            
            txtclass.Text = Session["classs"].ToString();
            txtsection.Text = Session["Sec"].ToString();

            string[] str = subjects.Split(',');
            foreach (string m in str)
            {
                if (m == "English")
                {
                    t1row.Visible = true;
                    englishrow.Visible = true;

                }
                if (m == "General Knowledge")
                {
                    t2row.Visible = true;
                   
                    gkrow.Visible = true;

                }
                if (m == "Computer")
                {
                    t1row.Visible = true;
                   
                    csrow.Visible = true;

                }
                if (m == "Environmental Science")
                {
                    t2row.Visible = true;

                    esrow.Visible = true;

                }
                if (m == "Hindi")
                {
                    t2row.Visible = true;

                    hindirow.Visible = true;


                }
                if (m == "Mathematics")
                {
                    t1row.Visible = true;
                   
                    mathsrow.Visible = true;

                }
                ////if (m == "So Science")
                //{

                //    socialscrow.Visible = true;


                //}
                //if (m == "Science")
                //{

                //    sciencerow.Visible = true;


                //}

            }

        }
    }
   
    protected void clrfld()
    {
        txtnam.Text = "";
        txtfather.Text = "";
        txtmother.Text = "";
        txtaddrs.Text = "";
        txtadmsn.Text = "";
        txtrollno.Text = "";
        //txtsection.Text = dr["sec"].ToString();
        //txtclass.Text = dr["class"].ToString();
        txtbloodgrp.Text = "";
        txtdob.Text = "";

        engrd1.Text = "";
        engrd2.Text = "";
        engrdtot.Value = "";
        engwt1.Text = "";
        engwt2.Text = "";
        engrdtot.Value = "";
        engdic1.Text = "";
        engdic2.Text = "";
        engdictot.Value = "";
        enghndwt1.Text = "";
        enghndwt2.Text = "";
        enghndtot.Value = "";
        engltn1.Text = "";
        engltn2.Text = "";
        engltntot.Value = "";
        engspk1.Text = "";
        engspk2.Text = "";
        engspktot.Value = "";
        engwtst1.Text = "";
        engwtst2.Text = "";
        engwtsttot.Value = "";
        engwttot.Value = "";
        hinrd1.Text = "";
        hinrd2.Text = "";
        hinrdtot.Value = "";
        hinwt1.Text = "";
        hinwt2.Text = "";
        hinwttot.Value = "";
        hindic1.Text = "";
        hindic2.Text = "";
        hindictot.Value = "";
        hinhndwt1.Text = "";
        hinhndwt2.Text = "";
        hinhndtot.Value = "";
        hinltn1.Text = "";
        hinltn2.Text = "";
        hinltntot.Value = "";
        hinspk1.Text = "";
        hinspk2.Text = "";
        hinspktot.Value = "";
        hinwtst1.Text = "";
        hinwtst2.Text = "";
        hinwtsttot.Value = "";

        mathcon1.Text = "";
        mathcon2.Text = "";
        mathcontot.Value = "";
        mathact1.Text = "";
        mathact2.Text = "";
        mathacttot.Value = "";
        mathtab1.Text = "";
        mathtab2.Text = "";
        mathtabtot.Value = "";
        mathmab1.Text = "";
        mathmab2.Text = "";
        mathmabtot.Value = "";
        mathwtst1.Text = "";
        mathwtst2.Text = "";
        mathwtsttot.Value = "";


        csapt1.Text = "";
        csapt2.Text = "";
        csaptot.Value = "";
        cswtst1.Text = "";
        cswtst2.Text = "";
        cswtsttot.Value = "";

        essen1.Text = "";
        essen2.Text = "";
        essentot.Value = "";
        esproj1.Text = "";
        esproj2.Text = "";
        esprojtot.Value = "";
        esgd1.Text = "";
        esgd2.Text = "";
        esgdtot.Value = "";
        eswtst1.Text = "";
        eswtst2.Text = "";
        eswtsttot.Value = "";

        gkwtst1.Text = "";
        gkwtst2.Text = "";
        gkwtsttot.Value = "";


        court1.Text = "";
        court2.Text = "";
        conf1.Text = "";
        conf2.Text = "";
        carof1.Text = "";
        carof2.Text = "";
        neat1.Text = "";
        neat2.Text = "";
        rul1.Text = "";
        rul2.Text = "";
        init1.Text = "";
        init2.Text = "";
        shr1.Text = "";
        shr2.Text = "";
        resp1.Text = "";
        resp2.Text = "";
        sclresp1.Text = "";
        sclresp2.Text = "";
        slfcon1.Text = "";
        slfcon2.Text = "";
        attnd1.Text = "";
        attnd2.Text = "";
        remark.Text = "";
        attnd1.Text = "";
        attnd2.Text = "";
        wedu1.Text = "";
        wedu2.Text = "";
        art1.Text = "";
        art2.Text = "";
        cft1.Text = "";
        cft2.Text = "";
        dnc1.Text = "";
        dnc2.Text = "";
        music1.Text = "";
        music2.Text = "";
        gam1.Text = "";
        gam2.Text = "";


        neat1.Text = "";
        neat2.Text = "";
        conf1.Text = "";
        conf2.Text = "";

        remark.Text = "";
        attnd1.Text = "";
        attnd2.Text = "";
        wt1.Text = "";
        wt2.Text = "";
        hyt1.Text = "";
        hyt2.Text = "";
        //lblsession.Text = dr["sessionss"].ToString();
        ddlconduct.SelectedIndex = -1;
        promoteclass.Value = "";


        //lblsession.Text = "";
        ddlconduct.SelectedIndex = -1;
    }


    protected void btn_save_click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand(@"Insert into CLASS_I_II(name, class, sec, rollno, admissionno, fname, mname, bloodgrp, address, engrd1, engrd2, engrdtot,engwt1, engwt2, engwttot, engdic1, engdic2, engdictot,enghnd1, enghnd2, enghndtot,engltn1, engltn2,engltntot, engspk1,engspk2, engspktot,engwtst1,engwtst2,engwtsttot ,  hindird1, hindird2, hindirdtot,hindiwt1, hindiwt2, hindiwttot, hindidic1, hindidic2, hindidictot,hindihnd1, hindihnd2, hindihndtot,hindiltn1, hindiltn2,hindiltntot, hindispk1,hindispk2, hindispktot,hindiwtst1,hindiwtst2,hindiwtsttot , mathcon1, mathcon2, mathcontot,mathact1, mathact2,mathacttot, mathtab1, mathtab2,mathtabtot, mathmab1, mathmab2,mathmabtot, mathwtst1,mathwtst2, mathwtsttot, essen1,essen2,essentot,esproj1,esproj2,esprojtot,esgd1,esgd2,esgdtot,eswtst1,eswtst2,eswtsttot,gkwtst1, gkwtst2, gkwtsttot ,csapt1,csapt2,csaptot,cswtst1,cswtst2,cswtsttot, wt1, wt2, hyt1,hyt2,art1,art2,wrkedu1,wrkedu2,craft1,craft2,dnc1,dnc2,music1,music2,gam1,gam2,court1,court2,carof1,carof2,neat1,neat2,confdc1,confdc2, rul1,rul2,init1,init2,shr1,shr2,resp1,resp2,schresp1,schresp2,slfcon1,slfcon2,sessionss,conduct,promoteclass,dob,student_pic,tearemrk,attndnce1,attndnce2) 
                  values(@name, @class, @sec, @rollno, @admissionno, @fname, @mname, @bloodgrp, @address,  @engrd1, @engrd2, @engrdtot,@engwt1, @engwt2, @engwttot, @engdic1, @engdic2, @engdictot,@enghnd1, @enghnd2, @enghndtot,@engltn1, @engltn2,@engltntot, @engspk1,@engspk2, @engspktot,@engwtst1,@engwtst2,@engwtsttot , @hindird1, @hindird2, @hindirdtot,@hindiwt1, @hindiwt2, @hindiwttot, @hindidic1, @hindidic2, @hindidictot,@hindihnd1, @hindihnd2, @hindihndtot,@hindiltn1, @hindiltn2,@hindiltntot, @hindispk1,@hindispk2, @hindispktot,@hindiwtst1,@hindiwtst2,@hindiwtsttot , @mathcon1, @mathcon2, @mathcontot,@mathact1, @mathact2,@mathacttot, @mathtab1, @mathtab2,@mathtabtot, @mathmab1, @mathmab2,@mathmabtot, @mathwtst1,@mathwtst2, @mathwtsttot,@essen1,@essen2,@essentot,@esproj1,@esproj2,@esprojtot,@esgd1,@esgd2,@esgdtot,@eswtst1,@eswtst2,@eswtsttot,@gkwtst1, @gkwtst2, @gkwtsttot ,@csapt1,@csapt2,@csaptot,@cswtst1,@cswtst2,@cswtsttot, @wt1, @wt2, @hyt1,@hyt2,@art1,@art2,@wrkedu1,@wrkedu2,@craft1,@craft2,@dnc1,@dnc2,@music1,@music2,@gam1,@gam2,@court1,@court2,@carof1,@carof2,@neat1,@neat2,@confdc1,@confdc2, @rul1,@rul2,@init1,@init2,@shr1,@shr2,@resp1,@resp2,@sclresp1,@sclresp2,@slfcon1,@slfcon2,@sessionss,@conduct,@promoteclass,@dob,@student_pic,@tearemrk,@attndnce1,@attndnce2)", cs.connect());

        //cmd = new SqlCommand("Save_reportcard", cs.Connect());
        //cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@name", txtnam.Text.ToUpper());
        cmd.Parameters.AddWithValue("@class", txtclass.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sec", txtsection.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rollno", txtrollno.Text.ToUpper());
        cmd.Parameters.AddWithValue("@admissionno", txtadmsn.Text.ToUpper());
        cmd.Parameters.AddWithValue("@fname", txtfather.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mname", txtmother.Text.ToUpper());
        cmd.Parameters.AddWithValue("@bloodgrp", txtbloodgrp.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dob", txtdob.Text.ToUpper());
        cmd.Parameters.AddWithValue("@student_pic", txtstupic.Text);
        cmd.Parameters.AddWithValue("@address", txtaddrs.Text.ToUpper());

        cmd.Parameters.AddWithValue("@engrd1", engrd1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrd2", engrd2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrdtot", engrdtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engwt1", engwt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engwt2", engwt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engwttot", engwttot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engdic1", engdic1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engdic2", engdic2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engdictot", engdictot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@enghnd1", enghndwt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@enghnd2", enghndwt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@enghndtot", enghndtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engltn1", engltn1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engltn2", engltn2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engltntot", engltntot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engspk1", engspk1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engspk2", engspk2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engspktot", engspktot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@engwtst1", engwtst1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engwtst2", engwtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engwtsttot", engwtsttot.Value.ToUpper());


        cmd.Parameters.AddWithValue("@hindird1", hinrd1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindird2", hinrd2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindirdtot", hinrdtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwt1", hinwt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwt2", hinwt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwttot", hinwttot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindidic1", hindic1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindidic2", hindic2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindidictot", hindictot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindihnd1", hinhndwt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindihnd2", hinhndwt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindihndtot", hinhndtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiltn1", hinltn1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiltn2", hinltn2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiltntot", hinltntot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindispk1", hinspk1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindispk2", hinspk2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindispktot", hinspktot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwtst1", hinwtst1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwtst2", hinwtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiwtsttot", hinwtsttot.Value.ToUpper());


        cmd.Parameters.AddWithValue("@mathcon1", mathcon1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathcon2", mathcon2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathcontot", mathcontot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathact1", mathact1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathact2", mathact2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathacttot", mathacttot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathtab1", mathtab1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathtab2", mathtab2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathtabtot", mathtabtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathmab1", mathmab1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathmab2", mathmab2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathmabtot", mathmabtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@mathwtst1", mathwtst1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathwtst2", mathwtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathwtsttot", mathwtsttot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@csapt1", csapt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@csapt2", csapt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@csaptot", csaptot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@cswtst1", cswtst1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@cswtst2", cswtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@cswtsttot", cswtsttot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@gkwtst1", gkwtst1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkwtst2", gkwtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkwtsttot", gkwtsttot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@essen1", essen1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@essen2", essen2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@essentot", essentot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@esproj1", esproj1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esproj2", esproj2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esprojtot", esprojtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@esgd1", esgd1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esgd2", esgd2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esgdtot", esgdtot.Value.ToUpper());
        cmd.Parameters.AddWithValue("@eswtst1", eswtst1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@eswtst2", eswtst2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@eswtsttot", eswtsttot.Value.ToUpper());

        cmd.Parameters.AddWithValue("@wrkedu1", wedu1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@wrkedu2", wedu2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@art1", art1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@art2", art2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@craft1", cft1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@craft2", cft2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dnc1", dnc1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dnc2", dnc2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@music1", music1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@music2", music2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gam1", gam1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gam2", gam2.Text.ToUpper());


        cmd.Parameters.AddWithValue("@court1", court1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@court2", court2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@confdc1", conf1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@confdc2", conf2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@carof1", carof1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@carof2", carof2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@neat1", neat1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@neat2", neat2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rul1", rul1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rul2", rul2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@init1", init1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@init2", init2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@shr1", shr1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@shr2", shr2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@resp1", resp1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@resp2", resp2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sclresp1", sclresp1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sclresp2", sclresp2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@slfcon1", slfcon1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@slfcon2", slfcon2.Text.ToUpper());


        cmd.Parameters.AddWithValue("@attndnce1", attnd1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@attndnce2", attnd2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@wt1", wt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@wt2", wt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hyt1", hyt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hyt2", hyt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@tearemrk", remark.Text.ToUpper());


        cmd.Parameters.AddWithValue("@sessionss", lblsession.Text);
        cmd.Parameters.AddWithValue("@conduct", ddlconduct.SelectedItem.Text.ToUpper());

        cmd.Parameters.AddWithValue("@promoteclass", promoteclass.Value.ToUpper());

        cmd.ExecuteNonQuery();

        //Response.Write("<script>alert('You Have Successfully Saved Marks !!!')</script>");



        try
        {
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cs.exec_qry("Delete from CLASS_I_II where id not in(select max(id) from CLASS_I_II group by name, class, sec, rollno, admissionno, fname, mname, bloodgrp, sessionss)");//Remove All Duplicates Entries From (this) Table 
                Response.Write("<script>alert('You Have Successfully Saved Marks !!!')</script>");
                //Session["admsnno"] = txtadmsn.Text.ToUpper();
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.success('Marks Saved Successfully of " + txtnam.Text.ToUpper() + "')", true);
                //Response.Write("<script>");
                //Response.Write("window.open('sampleresult_PreNursery.aspx?s=" + lblsession.Text + "','_blank')");
                //Response.Write("</script>");
                clrfld();

            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Something Went Wrong.. " + ex + "')", true);
        }

    }

    protected void txt_rno_TextChanged(object sender, EventArgs e)
    {

        bool temp = false;
        string connStr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        con.Open();
        SqlCommand cmd = new SqlCommand("select * from CLASS_I_II where rollno='" + txtrollno.Text.Trim() + "' and class='" + txtclass.Text + "'and sec='" + txtsection.Text + "' AND sessionss= '" + lblsession.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            txtnam.Text = dr["name"].ToString();
            txtfather.Text = dr["fname"].ToString();
            txtmother.Text = dr["mname"].ToString();
            txtaddrs.Text = dr["address"].ToString();
            txtadmsn.Text = dr["admissionno"].ToString();
            txtsection.Text = dr["sec"].ToString();
            txtclass.Text = dr["class"].ToString();
            txtbloodgrp.Text = dr["bloodgrp"].ToString();
            txtdob.Text = dr["dob"].ToString();
            txtstupic.Text = dr["student_pic"].ToString();


            engrd1.Text = dr["engrd1"].ToString();
            engrd2.Text = dr["engrd2"].ToString();
            engrdtot.Value = dr["engrdtot"].ToString();
            engwt1.Text = dr["engwt1"].ToString();
            engwt2.Text = dr["engwt2"].ToString();
            engwttot.Value = dr["engwttot"].ToString();
            engrdtot.Value = dr["engrdtot"].ToString();
            engdic1.Text = dr["engdic1"].ToString();
            engdic2.Text = dr["engdic2"].ToString();
            engdictot.Value = dr["engdictot"].ToString();
            enghndwt1.Text = dr["enghnd1"].ToString();
            enghndwt2.Text = dr["enghnd2"].ToString();
            enghndtot.Value = dr["enghndtot"].ToString();
            engltn1.Text = dr["engltn1"].ToString();
            engltn2.Text = dr["engltn2"].ToString();
            engltntot.Value = dr["engltntot"].ToString();
            engspk1.Text = dr["engspk1"].ToString();
            engspk2.Text = dr["engspk2"].ToString();
            engspktot.Value = dr["engspktot"].ToString();
            engwtst1.Text = dr["engwtst1"].ToString();
            engwtst2.Text = dr["engwtst2"].ToString();
            engwtsttot.Value = dr["engwtsttot"].ToString();

            hinrd1.Text = dr["hindird1"].ToString();
            hinrd2.Text = dr["hindird2"].ToString();
            hinrdtot.Value = dr["hindirdtot"].ToString();
            hinwt1.Text = dr["hindiwt1"].ToString();
            hinwt2.Text = dr["hindiwt2"].ToString();
            hinwttot.Value = dr["hindiwttot"].ToString();
            hindic1.Text = dr["hindidic1"].ToString();
            hindic2.Text = dr["hindidic2"].ToString();
            hindictot.Value = dr["hindidictot"].ToString();
            hinhndwt1.Text = dr["hindihnd1"].ToString();
            hinhndwt2.Text = dr["hindihnd2"].ToString();
            hinhndtot.Value = dr["hindihndtot"].ToString();
            hinltn1.Text = dr["hindiltn1"].ToString();
            hinltn2.Text = dr["hindiltn2"].ToString();
            hinltntot.Value = dr["hindiltntot"].ToString();
            hinspk1.Text = dr["hindispk1"].ToString();
            hinspk2.Text = dr["hindispk2"].ToString();
            hinspktot.Value = dr["hindispktot"].ToString();
            hinwtst1.Text = dr["hindiwtst1"].ToString();
            hinwtst2.Text = dr["hindiwtst2"].ToString();
            hinwtsttot.Value = dr["hindiwtsttot"].ToString();



            mathcon1.Text = dr["mathcon1"].ToString();
            mathcon2.Text = dr["mathcon2"].ToString();
            mathcontot.Value = dr["mathcontot"].ToString();
            mathact1.Text = dr["mathact1"].ToString();
            mathact2.Text = dr["mathact2"].ToString();
            mathacttot.Value = dr["mathacttot"].ToString();
            mathtab1.Text = dr["mathtab1"].ToString();
            mathtab2.Text = dr["mathtab2"].ToString();
            mathtabtot.Value = dr["mathtabtot"].ToString();
            mathmab1.Text = dr["mathmab1"].ToString();
            mathmab2.Text = dr["mathmab2"].ToString();
            mathmabtot.Value = dr["mathmabtot"].ToString();
            mathwtst1.Text = dr["mathwtst1"].ToString();
            mathwtst2.Text = dr["mathwtst2"].ToString();
            mathwtsttot.Value = dr["mathwtsttot"].ToString();


            csapt1.Text = dr["csapt1"].ToString();
            csapt2.Text = dr["csapt2"].ToString();
            csaptot.Value = dr["csaptot"].ToString();
            cswtst1.Text = dr["cswtst1"].ToString();
            cswtst2.Text = dr["cswtst2"].ToString();
            cswtsttot.Value = dr["cswtsttot"].ToString();

            essen1.Text = dr["essen1"].ToString();
            essen2.Text = dr["essen2"].ToString();
            essentot.Value = dr["essentot"].ToString();
            esproj1.Text = dr["esproj1"].ToString();
            esproj2.Text = dr["esproj2"].ToString();
            esprojtot.Value = dr["esprojtot"].ToString();
            esgd1.Text = dr["esgd1"].ToString();
            esgd2.Text = dr["esgd2"].ToString();
            esgdtot.Value = dr["esgdtot"].ToString();
            eswtst1.Text = dr["eswtst1"].ToString();
            eswtst2.Text = dr["eswtst2"].ToString();
            eswtsttot.Value = dr["eswtsttot"].ToString();

            gkwtst1.Text = dr["gkwtst1"].ToString();
            gkwtst2.Text = dr["gkwtst2"].ToString();
            gkwtsttot.Value = dr["gkwtsttot"].ToString();


            court1.Text = dr["court1"].ToString();
            court2.Text = dr["court2"].ToString();
            conf1.Text = dr["confdc1"].ToString();
            conf2.Text = dr["confdc2"].ToString();
            carof1.Text = dr["carof1"].ToString();
            carof2.Text = dr["carof2"].ToString();
            neat1.Text = dr["neat1"].ToString();
            neat2.Text = dr["neat2"].ToString();
            rul1.Text = dr["rul1"].ToString();
            rul2.Text = dr["rul2"].ToString();
            init1.Text = dr["init1"].ToString();
            init2.Text = dr["init2"].ToString();
            shr1.Text = dr["shr1"].ToString();
            shr2.Text = dr["shr2"].ToString();
            resp1.Text = dr["resp1"].ToString();
            resp2.Text = dr["resp2"].ToString();
            sclresp1.Text = dr["schresp1"].ToString();
            sclresp2.Text = dr["schresp2"].ToString();
            slfcon1.Text = dr["slfcon1"].ToString();
            slfcon2.Text = dr["slfcon2"].ToString();
            attnd1.Text = dr["attndnce1"].ToString();
            attnd2.Text = dr["attndnce2"].ToString();
            remark.Text = dr["tearemrk"].ToString();
            attnd1.Text = dr["attndnce1"].ToString();
            attnd2.Text = dr["attndnce2"].ToString();
            wedu1.Text = dr["wrkedu1"].ToString();
            wedu2.Text = dr["wrkedu2"].ToString();
            art1.Text = dr["art1"].ToString();
            art2.Text = dr["art2"].ToString();
            cft1.Text = dr["craft1"].ToString();
            cft2.Text = dr["craft2"].ToString();
            dnc1.Text = dr["dnc1"].ToString();
            dnc2.Text = dr["dnc2"].ToString();
            music1.Text = dr["music1"].ToString();
            music2.Text = dr["music2"].ToString();
            gam1.Text = dr["gam1"].ToString();
            gam2.Text = dr["gam2"].ToString();
            wt1.Text = dr["wt1"].ToString();
            wt2.Text = dr["wt2"].ToString();
            hyt1.Text = dr["hyt1"].ToString();
            hyt2.Text = dr["hyt2"].ToString();
            
            ddlconduct.SelectedItem.Text = dr["conduct"].ToString();
            promoteclass.Value = dr["promoteclass"].ToString();

            temp = true;
        }
        if (temp == false)
        {
            string connStr1 = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con1 = new SqlConnection(connStr1);
            con1.Open();

            SqlCommand com = new SqlCommand("select * from tbl_sturegister where rollno='" + txtrollno.Text.Trim() + "' and class_nm='" + txtclass.Text + "'  and section='" + txtsection.Text + "'", con1);
            SqlDataReader drr = com.ExecuteReader();
            while (drr.Read())
            {
               
                txtnam.Text = drr["fullname"].ToString();
                txtfather.Text = drr["fname"].ToString();
                txtmother.Text = drr["mname"].ToString();
                txtaddrs.Text = drr["addrss"].ToString();
                txtadmsn.Text = drr["admissionno"].ToString();
                txtbloodgrp.Text = drr["bloodgrp"].ToString();
                txtdob.Text = drr["dob"].ToString();
                txtstupic.Text = drr["st_img"].ToString();
                temp = true;
                //con.Close();
            }
            //MessageBox.Show("not found");
            con.Close();

        }
        if (temp == false)
        {
            Response.Write("<script>alert('There Is No Such Kind Of Roll No. Exist !!!')</script>");
            //con.Close();

        }

    }

}