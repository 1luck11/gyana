﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class login1_New_Pre_nursery_term_1 : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    DataTable dt = new DataTable();
    SqlCommand cmd = new SqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            lblsession.Text = Request.QueryString["sessions"].ToString();
            if (!IsPostBack)
            {

                string admsnno = Session["admsnno"].ToString();
                string connStr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
                SqlConnection con = new SqlConnection(connStr);

                con.Open();
                SqlCommand cmd = new SqlCommand("select top 1 * from new_Result_PNC where admissionno='" + admsnno + "' and sessionss='" + lblsession.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txtRoll.Text = dr["rollno"].ToString();
                    txtName.Text = dr["name"].ToString();
                    txtFather.Text = dr["fname"].ToString();
                    txtMother.Text = dr["mname"].ToString();
                    txtAddress.Text = dr["address"].ToString();
                    txtAdNo.Text = dr["admissionno"].ToString();
                    txtSection.Text = dr["sec"].ToString();
                    txtClass.Text = dr["class"].ToString();
                    txtBlood.Text = dr["bloodgrp"].ToString();
                    txtDob.Text = dr["dob"].ToString();
                    txtstupic.Text = dr["student_pic"].ToString();
                    hindiPt1.Text = dr["hindipt1"].ToString();
                    hindiNB1.Text = dr["hindiNB1"].ToString();
                    hindiHY1.Text = dr["hindiHy1"].ToString();
                    hindiTotal1.Text = dr["hinditotal1"].ToString();
                    hindiGrade1.Text = dr["hindiGrade1"].ToString();

                    englishPt1.Text = dr["englishpt1"].ToString();
                    englishNB1.Text = dr["englishNB1"].ToString();
                    englishHY1.Text = dr["englishHy1"].ToString();
                    englishTotal1.Text = dr["englishtotal1"].ToString();
                    englishGrade1.Text = dr["englishGrade1"].ToString();

                    mathPt1.Text = dr["mathpt1"].ToString();
                    mathNB1.Text = dr["mathNB1"].ToString();
                    mathHY1.Text = dr["mathHy1"].ToString();
                    mathTotal1.Text = dr["mathtotal1"].ToString();
                    mathGrade1.Text = dr["mathGrade1"].ToString();

                    gkPt1.Text = dr["gkpt1"].ToString();
                    gkNB1.Text = dr["gkNB1"].ToString();
                    gkHY1.Text = dr["gkHy1"].ToString();
                    gkTotal1.Text = dr["gktotal1"].ToString();
                    gkGrade1.Text = dr["gkGrade1"].ToString();

                    lbltotal1.Text = dr["toatl1"].ToString();
                    lblpercentage1.Text = dr["percentage1"].ToString();
                    attendance1.Text = dr["attendence1"].ToString();
                    height1.Text = dr["height1"].ToString();
                    weight1.Text = dr["weight1"].ToString();
                    txtRemark1.Text = dr["tearemrk"].ToString();
                    txtResult1.Text = dr["result1"].ToString();

                    artEdu.Text = dr["art_edu"].ToString();
                    conversation.Text = dr["conversation"].ToString();
                    Personality.Text = dr["personality"].ToString();
                    PhysicalEducation.Text = dr["health"].ToString();
                    Music.Text = dr["music"].ToString();
                    Dance.Text = dr["dance"].ToString();
                    Discipline.Text = dr["discipline"].ToString();
                    date.Text = Convert.ToDateTime(dr["crtd_date"].ToString()).ToString("dd MMM yyyy");



                }
            }
        }
        catch (Exception ae)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alert('" + ae.Message + "',this.open('../index.aspx'))", true);
        }
    }
}