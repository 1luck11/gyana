﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class login1_Reoprt : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
          
            bd.bind_dropdown(ddlclass, "select * from tbl_class  order by class_value asc", "class_nm", "class_value");
          
            bd.bind_dropdown(ddlsection, "select * from tbl_section order by section_value asc", "section_nm", "id");

            bd.bind_dropdown(DropDownList1, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");

            bd.bind_dropdown(DropDownList2, "select * from tbl_class  order by class_value asc", "class_nm", "class_value");


            bd.bind_dropdown(DropDownList3, "select * from tbl_section order by section_value asc", "section_nm", "id");
            DropDownList2.Items.Remove(new ListItem("Select", "-1"));
            getdata1();
            getdata();
        }

    }
    protected void grd_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        grd.PageIndex = e.NewPageIndex;
        bd.bind_grid(grd, "select * from tb_leftstudent order by 1 desc");


    }

    public void getdata()
    {
        bd.bind_grid(grd, "select * from tb_leftstudent order by 1 desc");
        bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");


    }


    public void getdata1()
    {
        if (DropDownList2.SelectedItem.Text == "I" || DropDownList2.SelectedItem.Text == "II")
            bd.bind_grid(GridView1, "select * from CLASS_I_II where class = '" + DropDownList2.SelectedItem.Text + "' order by id desc");
        else if (DropDownList2.SelectedItem.Text == "Pre Nursery" || DropDownList2.SelectedItem.Text == "Nursery" || DropDownList2.SelectedItem.Text == "K.G.")
            bd.bind_grid(GridView1, "select * from CLASS_PNC_KG where class = '" + DropDownList2.SelectedItem.Text + "' order by id desc");
        else
        {
            bd.bind_grid(GridView1, "select * from CLASS_III_V where class = '" + DropDownList2.SelectedItem.Text + "' order by id desc");
        }
        //bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");


    }

    protected void search_Click(object sender, EventArgs e)
    {

        //Response.Write("<script>alert('" + ddlsession.SelectedItem.Text + "')</script>");
        //bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");
        if(ddlsection.SelectedItem.Text!="Select"&& ddlsession.SelectedItem.Text!="Select"&&ddlclass.SelectedItem.Text!="Select")
    
            bd.bind_grid(grd, "select * from tb_leftstudent where Session='" + ddlsession.SelectedItem.Text + "' AND class='" + ddlclass.SelectedItem.Text + "' AND section='" + ddlsection.SelectedItem.Text + "'");
        else
            bd.bind_grid(grd, "select * from tb_leftstudent");


    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        string clas = "";
        if (DropDownList2.SelectedItem.Text == "I" || DropDownList2.SelectedItem.Text == "II")
            clas = "CLASS_I_II";
        else if (DropDownList2.SelectedItem.Text == "Pre Nursery" || DropDownList2.SelectedItem.Text == "Nursery" || DropDownList2.SelectedItem.Text == "K.G.")
            clas = "CLASS_PNC_KG";
        else
        {
            clas = "CLASS_III_V";
        }

        if (DropDownList1.SelectedItem.Text != "Select" && DropDownList4.SelectedItem.Text != "Select" && DropDownList3.SelectedItem.Text != "Select")
            bd.bind_grid(GridView1, "select * from " + clas + " where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct = '" + DropDownList4.SelectedItem.Text + "'");
        else
        {
            getdata1();
            Response.Write("<script>alert('Please Select All The Fields')</script>");
        }


        
        //if (DropDownList1.SelectedItem.Text == "Select" && DropDownList2.SelectedItem.Text == "Select" && DropDownList3.SelectedItem.Text == "Select")
            //bd.bind_grid(GridView1, "select * from CLASS_PNC_KG ,CLASS_I_II , CLASS_III_V ");
        //bd.bind_grid(GridView1, "select (select * from CLASS_PNC_KG where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct='" + DropDownList4.SelectedItem.Text + "'),(select * from CLASS_I_II where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct='" + DropDownList4.SelectedItem.Text + "'),(select * from CLASS_III_V where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct='" + DropDownList4.SelectedItem.Text + "')");

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bd.bind_grid(GridView1, "select * from CLASS_PNC_KG order by 1 desc");

    }
    protected void btnviewleft_Click(object sender, EventArgs e)
    {
        pnlleftstudent.Visible = true;
        pnlpassfail.Visible = false;
    }
    protected void btnviewpassfail_Click(object sender, EventArgs e)
    {
        pnlleftstudent.Visible = false;
        pnlpassfail.Visible = true;
    }
    protected void btnimportleft_Click(object sender, EventArgs e)
    {
        ExportGridToExcel();
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //required to avoid the runtime error "  
        //Control 'GridView1' of type 'GridView' must be placed inside a form tag with runat=server."  
    } 
    private void ExportGridToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.ClearContent();
        Response.ClearHeaders();
        Response.Charset = "";
        string FileName = "Vithal" + DateTime.Now + ".xls";
        StringWriter strwritter = new StringWriter();
        HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/vnd.ms-excel";
        Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
        grd.GridLines = GridLines.Both;
        grd.HeaderStyle.Font.Bold = true;
        grd.RenderControl(htmltextwrtter);
        Response.Write(strwritter.ToString());
        Response.End();

    }

}