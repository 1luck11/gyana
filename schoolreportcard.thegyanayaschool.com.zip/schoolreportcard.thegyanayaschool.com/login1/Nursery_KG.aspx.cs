﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class Nursery_KG : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblsession.Text = Request.QueryString["session"].ToString();
        if (!IsPostBack)
        {
            //divtotalmarks.Visible = false;
            // divgrade.Visible = false;
            // divattendence.Visible = false;
            //TextBox2.Text = classs + "(" + section + ")";

            englishrow.Visible = true;
            hindirow.Visible = true;
            mathsrow.Visible = true;
            //computerrow.Visible = false;
            // evsrow.Visible = false;
            esrow.Visible = true;
            drawrow.Visible = true;
            gkrow.Visible = true;
            scholarrow.Visible = true;
            attendance.Visible = true;
            remark.Visible = true;
            

            
            txtclass.Text = Session["classs"].ToString();
            txtsection.Text = Session["Sec"].ToString();

            

        }
    }
    protected void clrfld()
    {
        txtnam.Text = "";
        txtfather.Text = "";
        txtmother.Text = "";
        txtaddrs.Text = "";
        txtadmsn.Text = "";
        txtrollno.Text = "";
        //txtsection.Text = dr["sec"].ToString();
        //txtclass.Text = dr["class"].ToString();
        txtbloodgrp.Text = "";
        txtdob.Text = "";

        engread1.Text = "";
        engread2.Text = "";
        engrecit1.Text = "";
        engrecit2.Text = "";
        engcomp1.Text = "";
        engcomp2.Text = "";
        engexp1.Text = "";
        engexp2.Text = "";
        engrcz1.Text = "";
        engrcz2.Text = "";
        engprwrt1.Text = "";
        engprwrt2.Text = "";
        engcrtfmt1.Text = "";
        engcrtfmt2.Text = "";
        engrldex1.Text = "";
        engrldex2.Text = "";

        hinread1.Text = "";
        hinread2.Text = "";
        hinrecit1.Text = "";
        hinrecit2.Text = "";
        hincrtfmt1.Text = "";
        hincrtfmt2.Text = "";
        hinex1.Text = "";
        hinex2.Text = "";
        hinprwrt1.Text = "";
        hinprwrt2.Text = "";



        mathcount1.Text = "";
        mathcount2.Text = "";
        mathrcz1.Text = "";
        mathrcz2.Text = "";
        mathval1.Text = "";
        mathval2.Text = "";
        mathprno1.Text = "";
        mathprno2.Text = "";
        mathcrtfmt1.Text = "";
        mathcrtfmt2.Text = "";
        mathex1.Text = "";
        mathex2.Text = "";
        mathnocon1.Text = "";
        mathnocon2.Text = "";


        esrcz1.Text = "";
        esrcz2.Text = "";
        esans1.Text = "";
        esans2.Text = "";

        gkrcz1.Text = "";
        gkrcz2.Text = "";
        gkans1.Text = "";
        gkans2.Text = "";
        drawdw1.Text = "";
        drawdw2.Text = "";
        drawclr1.Text = "";
        drawclr2.Text = "";
        drawcrf1.Text = "";
        drawcrf2.Text = "";


        //foloinst1.Text = "";
        //foloinst2.Text = "";
        //obsrt1.Text = "";
        //obsrt2.Text = "";
        behav1.Text = "";
        behav2.Text = "";
        creatvy1.Text = "";
        creatvy2.Text = "";
        neat1.Text = "";
        neat2.Text = "";
        confdnc1.Text = "";
        confdnc2.Text = "";
        apptsng1.Text = "";
        apptsng2.Text = "";
        apptdnc1.Text = "";
        attnd1.Text = "";
        attnd2.Text = "";

        apptdnc2.Text = "";
        apptphycl1.Text = "";
        apptphycl2.Text = "";
        guidcon1.Text = "";
        guidcon2.Text = "";
        vocab1.Text = "";
        vocab2.Text = "";
        allrund1.Text = "";
        allrund2.Text = "";

        remak.Text = "";
        attnd1.Text = "";
        attnd2.Text = "";
        wt1.Text = "";
        wt2.Text = "";
        hyt1.Text = "";
        hyt2.Text = "";
        //lblsession.Text = dr["sessionss"].ToString();
        ddlconduct.SelectedIndex = -1;
        promoteclass.Value = "";


        //lblsession.Text = "";
        ddlconduct.SelectedIndex = -1;
    }

    protected void btn_save_click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand(@"Insert into CLASS_PNC_KG(name, class, sec, rollno, admissionno, fname, mname, bloodgrp, address, engread1, engread2, engrecit1, engrecit2, engcomp1, engcomp2, engexp1, engexp2, engrcz1, engrcz2, engprwt1,engprwt2, engcrtfmt1,engcrtfmt2, engrldex1,engrldex2, hindiread1, hindiread2, hindirecit1, hindirecit2, hindicrtfmt1, hindicrtfmt2,hindiprwt1,hindiprwt2, hindiex1, hindiex2, mathcount1, mathcount2, mathrcz1, mathrcz2, mathval1, mathval2, mathprno1, mathprno2,mathnocon1,mathnocon2,mathcrtfmt1, mathcrtfmt2,mathex1, mathex2,esrcz1, esrcz2, esans1 , esans2, gkrcz1, gkrcz2, gkans1 , gkans2,drawdr1,drawdr2,drawclr1,drawclr2,drawcrf1,drawcrf2, wt1, wt2, hyt1,hyt2,behav1,behav2,creatvy1,creatvy2,neat1,neat2,confdc1,confdc2,apptsng1,apptsng2,apptdnc1,apptdnc2,apptphycl1,apptphycl2,guidcon1,guidcon2,vocab1 ,vocab2,allround1,allround2, sessionss,conduct,promoteclass,dob,student_pic,tearemrk,attndnce1,attndnce2) 
                  values(@name, @class, @sec, @rollno, @admissionno, @fname, @mname, @bloodgrp, @address, @engread1, @engread2, @engrecit1, @engrecit2, @engcomp1, @engcomp2, @engexp1, @engexp2, @engrcz1, @engrcz2, @engprwt1,@engprwt2, @engcrtfmt1,@engcrtfmt2, @engrldex1,@engrldex2,@hindiread1, @hindiread2, @hindirecit1, @hindirecit2, @hindicrtfmt1, @hindicrtfmt2,@hindiprwt1,@hindiprwt2, @hindiex1, @hindiex2, @mathcount1, @mathcount2, @mathrcz1, @mathrcz2, @mathval1, @mathval2, @mathprno1, @mathprno2,@mathnocon1,@mathnocon2,@mathcrtfmt1, @mathcrtfmt2,@mathex1, @mathex2,@esrcz1, @esrcz2, @esans1 , @esans2, @gkrcz1, @gkrcz2, @gkans1 , @gkans2,@drawdr1,@drawdr2,@drawclr1,@drawclr2,@drawcrf1,@drawcrf2, @wt1, @wt2, @hyt1,@hyt2,@behav1,@behav2,@creatvy1,@creatvy2,@neat1,@neat2,@confdc1,@confdc2,@apptsng1,@apptsng2,@apptdnc1,@apptdnc2,@apptphycl1,@apptphycl2,@guidcon1,@guidcon2,@vocab1 ,@vocab2,@allround1,@allround2,@sessionss,@conduct,@promoteclass,@dob,@student_pic,@tearemrk,@attndnce1,@attndnce2)", cs.connect());

        //cmd = new SqlCommand("Save_reportcard", cs.Connect());
        //cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@name", txtnam.Text.ToUpper());
        cmd.Parameters.AddWithValue("@class", txtclass.Text.ToUpper());
        cmd.Parameters.AddWithValue("@sec", txtsection.Text.ToUpper());
        cmd.Parameters.AddWithValue("@rollno", txtrollno.Text.ToUpper());
        cmd.Parameters.AddWithValue("@admissionno", txtadmsn.Text.ToUpper());
        cmd.Parameters.AddWithValue("@fname", txtfather.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mname", txtmother.Text.ToUpper());
        cmd.Parameters.AddWithValue("@bloodgrp", txtbloodgrp.Text.ToUpper());
        cmd.Parameters.AddWithValue("@dob", txtdob.Text.ToUpper());
        cmd.Parameters.AddWithValue("@student_pic", txtstupic.Text);

        cmd.Parameters.AddWithValue("@address", txtaddrs.Text.ToUpper());

        cmd.Parameters.AddWithValue("@engread1", engread1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engread2", engread2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrecit1", engrecit1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrecit2", engrecit2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engcomp1", engcomp1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engcomp2", engcomp2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engexp1", engexp1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engexp2", engexp2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrcz1", engrcz1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrcz2", engrcz2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engprwt1", engprwrt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engprwt2", engprwrt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engcrtfmt1", engcrtfmt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engcrtfmt2", engcrtfmt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrldex1", engrldex1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@engrldex2", engrldex2.Text.ToUpper());

        cmd.Parameters.AddWithValue("@hindiread1", hinread1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiread2", hinread2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindirecit1", hinrecit1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindirecit2", hinrecit2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindicrtfmt1", hincrtfmt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindicrtfmt2", hincrtfmt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiex1", hinex1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiex2", hinex2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiprwt1", hinprwrt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hindiprwt2", hinprwrt2.Text.ToUpper());


        cmd.Parameters.AddWithValue("@mathcount1", mathcount1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathcount2", mathcount2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathrcz1", mathrcz1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathrcz2", mathrcz2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathval1", mathval1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathval2", mathval2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathprno1", mathprno1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathprno2", mathprno2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathnocon1", mathnocon1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathnocon2", mathnocon2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathcrtfmt1", mathcrtfmt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathcrtfmt2", mathcrtfmt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathex1", mathex1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@mathex2", mathex2.Text.ToUpper());

        cmd.Parameters.AddWithValue("@esrcz1", esrcz1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esrcz2", esrcz2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esans1", esans1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@esans2", esans2.Text.ToUpper());


        cmd.Parameters.AddWithValue("@gkrcz1", gkrcz1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkrcz2", gkrcz2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkans1", gkans1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@gkans2", gkans2.Text.ToUpper());

        cmd.Parameters.AddWithValue("@drawdr1", drawdw1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@drawdr2", drawdw2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@drawclr1", drawclr1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@drawclr2", drawclr2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@drawcrf1", drawcrf1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@drawcrf2", drawcrf2.Text.ToUpper());


        //cmd.Parameters.AddWithValue("@foloinst1", foloinst1.Text.ToUpper());
        //cmd.Parameters.AddWithValue("@foloinst2", foloinst2.Text.ToUpper());
        //cmd.Parameters.AddWithValue("@obsrvt1", obsrt1.Text.ToUpper());
        //cmd.Parameters.AddWithValue("@obsrvt2", obsrt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@behav1", behav1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@behav2", behav2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@creatvy1", creatvy1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@creatvy2", creatvy2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@neat1", neat1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@neat2", neat2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@confdc1", confdnc1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@confdc2", confdnc2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@apptsng1", apptsng1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@apptsng2", apptsng2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@apptdnc1", apptdnc1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@apptdnc2", apptdnc2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@apptphycl1", apptphycl1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@apptphycl2", apptphycl2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@guidcon1", guidcon1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@guidcon2", guidcon2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@vocab1", vocab1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@vocab2", vocab2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@allround1", allrund1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@allround2", allrund2.Text.ToUpper());

        cmd.Parameters.AddWithValue("@attndnce1", attnd1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@attndnce2", attnd2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@wt1", wt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@wt2", wt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hyt1", hyt1.Text.ToUpper());
        cmd.Parameters.AddWithValue("@hyt2", hyt2.Text.ToUpper());
        cmd.Parameters.AddWithValue("@tearemrk", remak.Text.ToUpper());


        cmd.Parameters.AddWithValue("@sessionss", lblsession.Text);
        cmd.Parameters.AddWithValue("@conduct", ddlconduct.SelectedItem.Text.ToUpper());

        cmd.Parameters.AddWithValue("@promoteclass", promoteclass.Value.ToUpper());

        cmd.ExecuteNonQuery();

        //Response.Write("<script>alert('You Have Successfully Saved Marks !!!')</script>");



        try
        {
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cs.exec_qry("Delete from CLASS_PNC_KG where id not in(select max(id) from CLASS_PNC_KG group by name, class, sec, rollno, admissionno, fname, mname, bloodgrp, sessionss)");//Remove All Duplicates Entries From (this) Table 
                Response.Write("<script>alert('You Have Successfully Saved Marks !!!')</script>");
                Session["admsnno"] = txtadmsn.Text.ToUpper();
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.success('Marks Saved Successfully of " + txtnam.Text.ToUpper() + "')", true);
                if (ddl_term.Text == "Term-I")
                {

                    Response.Write("<script>");
                    Response.Write("window.open('CLASSNURSERYterm1.aspx?sessions=" + lblsession.Text + "','_blank')");
                    Response.Write("</script>");
                    clrfld();
                }


                if (ddl_term.Text == "Term-II")
                {
                    Response.Write("<script>");
                    Response.Write("window.open('sampleResult_Nursery_kG.aspx?sessions=" + lblsession.Text + "','_blank')");
                    Response.Write("</script>");
                    clrfld();
                }

            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alertify.error('Something Went Wrong.. " + ex + "')", true);
        }

    }

    protected void txt_rno_TextChanged(object sender, EventArgs e)
    {

        bool temp = false;
        string connStr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        con.Open();
        SqlCommand cmd = new SqlCommand("select * from CLASS_PNC_KG where rollno='" + txtrollno.Text.Trim() + "' and class='" + txtclass.Text + "'and sec='" + txtsection.Text + "' AND sessionss= '"+lblsession.Text+"' ", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            txtnam.Text = dr["name"].ToString();
            txtfather.Text = dr["fname"].ToString();
            txtmother.Text = dr["mname"].ToString();
            txtaddrs.Text = dr["address"].ToString();
            txtadmsn.Text = dr["admissionno"].ToString();
            txtsection.Text = dr["sec"].ToString();
            txtclass.Text = dr["class"].ToString();
            txtbloodgrp.Text = dr["bloodgrp"].ToString();
            txtdob.Text = dr["dob"].ToString();
            txtstupic.Text = dr["student_pic"].ToString();


            engread1.Text = dr["engread1"].ToString();
            engread2.Text = dr["engread2"].ToString();
            engrecit1.Text = dr["engrecit1"].ToString();
            engrecit2.Text = dr["engrecit2"].ToString();
            engcomp1.Text = dr["engcomp1"].ToString();
            engcomp2.Text = dr["engcomp2"].ToString();
            engexp1.Text = dr["engexp1"].ToString();
            engexp2.Text = dr["engexp2"].ToString();
            engrcz1.Text = dr["engrcz1"].ToString();
            engrcz2.Text = dr["engrcz2"].ToString();
            engprwrt1.Text = dr["engprwt1"].ToString();
            engprwrt2.Text = dr["engprwt2"].ToString();
            engcrtfmt1.Text = dr["engcrtfmt1"].ToString();
            engcrtfmt2.Text = dr["engcrtfmt2"].ToString();
            engrldex1.Text = dr["engrldex1"].ToString();
            engrldex2.Text = dr["engrldex2"].ToString();

            hinread1.Text = dr["hindiread1"].ToString();
            hinread2.Text = dr["hindiread2"].ToString();
            hinrecit1.Text = dr["hindirecit1"].ToString();
            hinrecit2.Text = dr["hindirecit2"].ToString();
            hincrtfmt1.Text = dr["hindicrtfmt1"].ToString();
            hincrtfmt2.Text = dr["hindicrtfmt2"].ToString();
            hinex1.Text = dr["hindiex1"].ToString();
            hinex2.Text = dr["hindiex2"].ToString();
            hinprwrt1.Text = dr["hindiprwt1"].ToString();
            hinprwrt2.Text = dr["hindiprwt2"].ToString();


            mathcount1.Text = dr["mathcount1"].ToString();
            mathcount2.Text = dr["mathcount2"].ToString();
            mathrcz1.Text = dr["mathrcz1"].ToString();
            mathrcz2.Text = dr["mathrcz2"].ToString();
            mathval1.Text = dr["mathval1"].ToString();
            mathval2.Text = dr["mathval2"].ToString();
            mathprno1.Text = dr["mathprno1"].ToString();
            mathprno2.Text = dr["mathprno2"].ToString();
            mathnocon1.Text = dr["mathnocon1"].ToString();
            mathnocon2.Text = dr["mathnocon2"].ToString();
            mathcrtfmt1.Text = dr["mathcrtfmt1"].ToString();
            mathcrtfmt2.Text = dr["mathcrtfmt2"].ToString();
            mathex1.Text = dr["mathex1"].ToString();
            mathex2.Text = dr["mathex2"].ToString();


            esrcz1.Text = dr["esrcz1"].ToString();
            esrcz2.Text = dr["esrcz2"].ToString();
            esans1.Text = dr["esans1"].ToString();
            esans2.Text = dr["esans2"].ToString();

            gkrcz1.Text = dr["gkrcz1"].ToString();
            gkrcz2.Text = dr["gkrcz2"].ToString();
            gkans1.Text = dr["gkans1"].ToString();
            gkans2.Text = dr["gkans2"].ToString();
            drawdw1.Text = dr["drawdr1"].ToString();
            drawdw2.Text = dr["drawdr2"].ToString();
            drawclr1.Text = dr["drawclr1"].ToString();
            drawclr2.Text = dr["drawclr2"].ToString();
            drawcrf1.Text = dr["drawcrf1"].ToString();
            drawcrf2.Text = dr["drawcrf2"].ToString();


            //foloinst1.Text = dr["foloinst1"].ToString();
            //foloinst2.Text = dr["foloinst2"].ToString();
            //obsrt1.Text = dr["obsrvt1"].ToString();
            //obsrt2.Text = dr["obsrvt2"].ToString();
            behav1.Text = dr["behav1"].ToString();
            behav2.Text = dr["behav2"].ToString();
            creatvy1.Text = dr["creatvy1"].ToString();
            creatvy2.Text = dr["creatvy2"].ToString();
            neat1.Text = dr["neat1"].ToString();
            neat2.Text = dr["neat2"].ToString();
            confdnc1.Text = dr["confdc1"].ToString();
            confdnc2.Text = dr["confdc2"].ToString();
            apptsng1.Text = dr["apptsng1"].ToString();
            apptsng2.Text = dr["apptsng2"].ToString();
            apptdnc1.Text = dr["apptdnc1"].ToString();
            attnd1.Text = dr["attndnce1"].ToString();
            attnd2.Text = dr["attndnce2"].ToString();

            apptdnc2.Text = dr["apptdnc2"].ToString();
            apptphycl1.Text = dr["apptphycl1"].ToString();
            apptphycl2.Text = dr["apptphycl2"].ToString();
            guidcon1.Text = dr["guidcon1"].ToString();
            guidcon2.Text = dr["guidcon2"].ToString();
            vocab1.Text = dr["vocab1"].ToString();
            vocab2.Text = dr["vocab2"].ToString();
            allrund1.Text = dr["allround1"].ToString();
            allrund2.Text = dr["allround2"].ToString();

            remak.Text = dr["tearemrk"].ToString();
            attnd1.Text = dr["attndnce1"].ToString();
            attnd2.Text = dr["attndnce2"].ToString();
            wt1.Text = dr["wt1"].ToString();
            wt2.Text = dr["wt2"].ToString();
            hyt1.Text = dr["hyt1"].ToString();
            hyt2.Text = dr["hyt2"].ToString();
            
            ddlconduct.SelectedItem.Text = dr["conduct"].ToString();
            promoteclass.Value = dr["promoteclass"].ToString();

            temp = true;
        }
        if (temp == false)
        {
            string connStr1 = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con1 = new SqlConnection(connStr1);
            con1.Open();

            SqlCommand com = new SqlCommand("select * from tbl_sturegister where rollno='" + txtrollno.Text.Trim() + "' and class_nm='" + txtclass.Text + "'  and section='" + txtsection.Text + "'", con1);
            SqlDataReader drr = com.ExecuteReader();
            while (drr.Read())
            {
                
                txtnam.Text = drr["fullname"].ToString();
                txtfather.Text = drr["fname"].ToString();
                txtmother.Text = drr["mname"].ToString();
                txtaddrs.Text = drr["addrss"].ToString();
                txtadmsn.Text = drr["admissionno"].ToString();
                txtbloodgrp.Text = drr["bloodgrp"].ToString();
                txtdob.Text = (drr["dob"]).ToString();
                txtstupic.Text = drr["st_img"].ToString();
                temp = true;
                //con.Close();
            }
            //MessageBox.Show("not found");
            con.Close();

        }
        if (temp == false)
        {
            Response.Write("<script>alert('There Is No Such Kind Of Roll No. Exist !!!')</script>");
            //con.Close();

        }

    }

}