﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_adminupload : System.Web.UI.Page
{
 
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["alogin"] != null)
        {
    

            if (!IsPostBack)
            {

                bd.bind_dropdown(ddlsession, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "session_val");
                bd.bind_dropdown(ddlclass, "select * from tbl_class  order by class_value asc", "class_nm", "class_value");
                bd.bind_dropdown(ddlsection, "select * from tbl_section order by section_value asc", "section_nm", "id");
       
                 Session["session"] = ddlsession.SelectedItem;
                 string sec = ddlsection.SelectedItem.Value.ToString();
            
            }

        }
        else
        {

            Response.Redirect("~/index.aspx");

        }
    }


    protected void Button5_Click(object sender, EventArgs e)
    {

        string classs = ddlclass.SelectedItem.Text;
        if (ddlclass.SelectedItem.Text == "Pre Nursery")
        {
            Session["classs"] = ddlclass.SelectedItem.Text;
            Session["Sec"] = ddlsection.SelectedItem.Text.ToString();
            Session["Sess"] = ddlsession.SelectedItem.Text.ToString();
            //Session["class"] = classs;
            Response.Redirect("~/login1/PreNursery.aspx?session=" + ddlsession.SelectedItem.Text + "");

        }
        else if (ddlclass.SelectedItem.Text == "Nursery"|| ddlclass.SelectedItem.Text =="K.G.")
        {
            Session["classs"] = ddlclass.SelectedItem.Text;
            Session["Sec"] = ddlsection.SelectedItem.Text.ToString();
            Session["Sess"] = ddlsession.SelectedItem.Text.ToString();
            //Session["class"] = classs;
            Response.Redirect("~/login1/Nursery_KG.aspx?session=" + ddlsession.SelectedItem.Text + "");

        }
      
        else if (ddlclass.SelectedItem.Text == "I" || ddlclass.SelectedItem.Text == "II")
        {
            Session["classs"] = ddlclass.SelectedItem.Text;
            Session["Sec"] = ddlsection.SelectedItem.Text.ToString();
            Session["Sess"] = ddlsession.SelectedItem.Text.ToString();
            //Session["class"] = classs;
            Response.Redirect("~/login1/I_II.aspx?session=" + ddlsession.SelectedItem.Text + "");

        }
        else if (ddlclass.SelectedItem.Text == "III" || ddlclass.SelectedItem.Text == "IV" || ddlclass.SelectedItem.Text == "V")
        {
            Session["classs"] = ddlclass.SelectedItem.Text;
            Session["Sec"] = ddlsection.SelectedItem.Text.ToString();
            Session["Sess"] = ddlsession.SelectedItem.Text.ToString();
            //Session["class"] = classs;
            Response.Redirect("~/login1/III_to_V.aspx?session=" + ddlsession.SelectedItem.Text + "");

        }
        else
        {
            Response.Write("<script>alert('You Have Entered Wrong Details')</script>");
           
        }
    }
}