﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_PrintAdmin : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["alogin"] != null)
        {
            if (!IsPostBack)
            {
                bd.bind_dropdown(DropDownList1, "select * from tbl_session where isactive = 'true' order by session_val asc", "session_nm", "id");

                bd.bind_dropdown(DropDownList2, "select * from tbl_class  order by class_value asc", "class_nm", "class_value");

                bd.bind_dropdown(DropDownList3, "select * from tbl_section order by section_value asc", "section_nm", "id");

                Fetch_Rpt_Detail();
            }
        }
        else
        {

            Response.Redirect("~/index.aspx");

        }
    }
    public void Fetch_Rpt_Detail()
    {
        bd.bind_grid(GridView1, @"Select id,status,name,class,sec,rollno,admissionno,fname,mname,sessionss,crtd_dt from CLASS_PNC_KG  union Select id,status,name,class,sec,rollno,admissionno,fname,mname,sessionss,crtd_dt from CLASS_I_II union Select id,status,name,class,sec,rollno,admissionno,fname,mname,sessionss,crtd_dt from CLASS_III_V ");//
    }

    protected void btn_print_Click(object sender, EventArgs e)
    {
        Button btn = sender as Button;

        Session["admsnno"] = btn.CommandArgument.Split('^')[0];
        
        string ddlclass = btn.CommandArgument.Split('^')[1];
        string ddlsession = btn.CommandArgument.Split('^')[2];
        string status = btn.CommandArgument.Split('^')[3];
        string rollno = btn.CommandArgument.Split('^')[4];
        string sec = btn.CommandArgument.Split('^')[5];
        string term = DropDownList4.SelectedItem.Value;

        if (status == "OTHER" && term == "Term-II")
        {
            if (ddlclass == "PRE NURSERY")
            {
                Response.Write("<script>window.open('sampleResult_PreNursery.aspx?sessions=" + ddlsession + "','_blank')</script>");
            }
            else if (ddlclass == "NURSERY" || ddlclass == "K.G.")
            {
                Response.Write("<script>window.open('sampleResult_Nursery_kG.aspx?sessions=" + ddlsession + "','_blank')</script>");
            }
           
            else
            {
                Response.Write("<script>alert('SOMETHING WENT WRONG..! PLEASE TRY AGAIN..!')</script>");
            }
        }


        else if (status == "OTHER" && term == "Term-I")
        {
            if (ddlclass == "PRE NURSERY")
            {
                Response.Write("<script>window.open('Classprencterm1.aspx?sessions=" + ddlsession + "','_blank')</script>");
            }
            else if (ddlclass == "NURSERY" || ddlclass == "K.G.")
            {
                Response.Write("<script>window.open('CLASSNURSERYterm1.aspx?sessions=" + ddlsession + "','_blank')</script>");
            }

            else
            {
                Response.Write("<script>alert('SOMETHING WENT WRONG..! PLEASE TRY AGAIN..!')</script>");
            }
        }
        else if (status == "ANOTHER" && term == "Term-II")
        {
            if (ddlclass == "I" || ddlclass == "II")
            {
                Response.Write("<script>window.open('SampleResult_I_II.aspx?sessions=" + ddlsession + "','_blank')</script>");
            }

            else
            {
                Response.Write("<script>alert('SOMETHING WENT WRONG..! PLEASE TRY AGAIN..!')</script>");
            }
        }


        else if (status == "ANOTHER" && term == "Term-I")
        {
            if (ddlclass == "I" || ddlclass == "II")
            {
                Response.Write("<script>window.open('class1-2 term1result.aspx?sessions=" + ddlsession + "','_blank')</script>");
            }

            else
            {
                Response.Write("<script>alert('SOMETHING WENT WRONG..! PLEASE TRY AGAIN..!')</script>");
            }
        }
        else if (status == "FIVEOTHER" && term == "Term-II")
        {
            if (ddlclass == "III" || ddlclass == "IV" || ddlclass == "V")
            {
                Response.Write("<script>window.open('SampleResult_III_V.aspx?sessions=" + ddlsession + "','_blank')</script>");
            }

            else
            {
                Response.Write("<script>alert('SOMETHING WENT WRONG..! PLEASE TRY AGAIN..!')</script>");
            }
        }

        else if (status == "FIVEOTHER" && term == "Term-I")
        {
            if (ddlclass == "III" || ddlclass == "IV" || ddlclass == "V")
            {
                Response.Write("<script>window.open('class-3 term1.aspx?sessions=" + ddlsession + "','_blank')</script>");
            }

            else
            {
                Response.Write("<script>alert('SOMETHING WENT WRONG..! PLEASE TRY AGAIN..!')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('SOMETHING WENT WRONG..! PLEASE TRY AGAIN..!')</script>");

        }

        //Session["regno"] = btn.CommandArgument;
        //string url = "Registration_Print.aspx?regno=" + btn.CommandArgument + "";
        //string s = "window.open('" + url + "', '_blank', 'width=700,height=500,left=100,top=100,resizable=yes');";
        //ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Fetch_Rpt_Detail();
    }
    protected void btn_del_Click(object sender, EventArgs e)
    {
        LinkButton btn = sender as LinkButton;

        string id = btn.CommandArgument.Split('^')[0];
        string status = btn.CommandArgument.Split('^')[1];

        //string id = GridView1.DataKeys[e.RowIndex].Values["id"].ToString();
        if (status == "OTHER")
        {
            cmd = new SqlCommand("Delete from CLASS_PNC_KG where id='" + id + "'", cs.connect());
        }
        else if (status == "ANOTHER")
        {
            cmd = new SqlCommand("Delete from CLASS_I_II where id='" + id + "'", cs.connect());
        }

        else if (status == "FIVEOTHER")
        {
            cmd = new SqlCommand("Delete from CLASS_III_V where id='" + id + "'", cs.connect());
        }

        else
        {
            Response.Write("<script>alert('SOMETHING WENT WRONG..! PLEASE TRY AGAIN..!!')</script>");
        }

        int result = cmd.ExecuteNonQuery();
        if (result == 1)
        {
            //lbl.ForeColor = Color.Red;
            //lbl.Text = "Deleted Successfully";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "btnGo", "alert('Successfully Deleted')", true);
            Fetch_Rpt_Detail();
        }
        else
        {
            Response.Write("<script>alert('SOMETHING WENT WRONG..! PLEASE TRY AGAIN..!')</script>");
        }

    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {

        string clas = "";
        if (DropDownList2.SelectedItem.Text == "I" || DropDownList2.SelectedItem.Text == "II")
            clas = "CLASS_I_II";
        else if (DropDownList2.SelectedItem.Text == "Pre Nursery" || DropDownList2.SelectedItem.Text == "Nursery" || DropDownList2.SelectedItem.Text == "K.G.")
            clas = "CLASS_PNC_KG";
        else
        {
            clas = "CLASS_III_V";
        }

        if (DropDownList1.SelectedItem.Text != "Select"  && DropDownList3.SelectedItem.Text != "Select")
            bd.bind_grid(GridView1, "select * from " + clas + " where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "'");
        else
        {
            
            Response.Write("<script>alert('Please Select All The Fields')</script>");
        }



        //if (DropDownList1.SelectedItem.Text == "Select" && DropDownList2.SelectedItem.Text == "Select" && DropDownList3.SelectedItem.Text == "Select")
        //bd.bind_grid(GridView1, "select * from CLASS_PNC_KG ,CLASS_I_II , CLASS_III_V ");
        //bd.bind_grid(GridView1, "select (select * from CLASS_PNC_KG where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct='" + DropDownList4.SelectedItem.Text + "'),(select * from CLASS_I_II where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct='" + DropDownList4.SelectedItem.Text + "'),(select * from CLASS_III_V where sessionss='" + DropDownList1.SelectedItem.Text + "' AND class='" + DropDownList2.SelectedItem.Text + "' AND sec='" + DropDownList3.SelectedItem.Text + "' AND conduct='" + DropDownList4.SelectedItem.Text + "')");

    }
}