﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login1_AddClass : System.Web.UI.Page
{
    connectionclass cs = new connectionclass();
    binddropdown bd = new binddropdown();

    protected void Page_Load(object sender, EventArgs e)
    {
        getdata();
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        string clasval = DropDownList1.SelectedValue;
        string clasno = DropDownList1.SelectedItem.Text;

        SqlCommand cmd = new SqlCommand("insert into tbl_class (class_nm,class_value) values('" + clasno + "','" + clasval + "')", cs.connect());
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Class Has Been Added Successfully !!!')</script>");
        getdata();

    }
    protected void getdata()
    {//select * from tbl_class order by class_value asc
        SqlCommand com = new SqlCommand("select * from tbl_class order by class_value asc", cs.connect());
        SqlDataAdapter daa = new SqlDataAdapter(com);
        DataTable dtt = new DataTable();
        daa.Fill(dtt);
        if (dtt.Rows.Count > 0)
        {

            grd.DataSource = dtt;
            grd.DataBind();

            // TextBox4.Text = "";

        }

    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "delete")
        {

            cs.exec_qry("delete from tbl_class where id='" + e.CommandArgument + "'");
            Response.Write("<script>alert('Class Has Been Deleted Successfully !!!')</script>");
            getdata();//Response.Redirect("Addsession.aspx");
        }

    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}