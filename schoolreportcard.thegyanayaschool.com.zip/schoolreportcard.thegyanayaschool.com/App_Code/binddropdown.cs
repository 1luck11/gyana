﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


/// <summary>
/// Summary description for binddropdown
/// </summary>
public class binddropdown
{

    connectionclass cs = new connectionclass();
    SqlCommand cmd = new SqlCommand();
    public static int k_id;
    public static SqlConnection con;
   
	public binddropdown()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable fill_datatable(string qry)
    {
        DataTable dt = new DataTable();
        new SqlDataAdapter(qry, cs.connect()).Fill(dt);
        return dt;
    }
    public void bind_dropdown(DropDownList ddl,string qry,string text,string value)
    {
        DataTable dt = fill_datatable(qry);
        ddl.DataSource = dt;
        ddl.DataTextField = text;
        ddl.DataValueField = value;
        ddl.DataBind();
        ddl.Items.Insert(0, new ListItem("Select", "-1"));

    }

    public void bind_grid(GridView gvr, string qry)
    {
        DataTable dt = fill_datatable(qry);
        gvr.DataSource = dt;
        gvr.DataBind();



    }

    public void clear_controls(Control parent)
    {
        foreach (Control x in parent.Controls)
        {
            if (x.GetType() == typeof(TextBox))
                ((TextBox)(x)).Text = "";
            if (x.GetType() == typeof(DropDownList))
                ((DropDownList)(x)).SelectedIndex = 0;
            if (x.GetType() == typeof(CheckBox))
                ((CheckBox)(x)).Checked = false;
            if (x.HasControls())
                clear_controls(x);
        }
    }

    public static string single_return(string fg)
    {

        string tu = fg;
        if (k_id == 0)
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString);
        }

        if (con.State == ConnectionState.Closed) { con.Open(); }
        SqlDataAdapter dad = new SqlDataAdapter(fg, con);
        DataTable gh = new DataTable();
        dad.Fill(gh);
        if (gh.Rows.Count > 0)
        {
            tu = gh.Rows[0][0].ToString();

        }
        else
        {
            tu = "";
        }

        return tu;




    }
}