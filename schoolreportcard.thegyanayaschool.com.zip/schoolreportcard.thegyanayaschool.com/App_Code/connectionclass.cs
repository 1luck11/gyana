﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


/// <summary>
/// Summary description for connectionclass
/// </summary>
public class connectionclass
{

    public SqlConnection connect()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString);
        con.Open();
        return con;

    }

    public string exec_qry(string qry)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString);
        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd = new SqlCommand(qry, con);
        int i = cmd.ExecuteNonQuery();
        cmd.Dispose();
        if (con.State == ConnectionState.Open)
            con.Close();
        if (i > 0)
        {
            return "success";

        }
        else
        {

            return "Failed";

        }

    }

    public string exec_qry_scalar(string qry)
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString);
        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd = new SqlCommand(qry, con);
        string s = cmd.ExecuteScalar().ToString();
        cmd.Dispose();
        if (con.State == ConnectionState.Open)
            con.Close();
        return s;

    }
}